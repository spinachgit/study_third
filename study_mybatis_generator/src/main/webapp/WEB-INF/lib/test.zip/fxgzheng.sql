/*
Navicat MySQL Data Transfer

Source Server         : 175.102.24.23
Source Server Version : 50716
Source Host           : 175.102.24.23:3306
Source Database       : fxgzheng

Target Server Type    : MYSQL
Target Server Version : 50716
File Encoding         : 65001

Date: 2017-01-03 16:05:11
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for activity_info
-- ----------------------------
DROP TABLE IF EXISTS `activity_info`;
CREATE TABLE `activity_info` (
  `activityid` int(11) NOT NULL AUTO_INCREMENT COMMENT '活动编码',
  `activityname` varchar(100) DEFAULT NULL COMMENT '活动名称',
  `cityid` int(11) DEFAULT NULL COMMENT '市编码',
  `starttime` datetime DEFAULT NULL COMMENT '开始时间',
  `endtime` datetime DEFAULT NULL COMMENT '结束时间',
  `imgurl` varchar(200) DEFAULT NULL COMMENT '广告图片',
  `profile` varchar(200) DEFAULT NULL COMMENT '活动简介',
  `describes` text COMMENT '商品描述',
  `citme` datetime DEFAULT NULL COMMENT '创建时间',
  `state` int(2) DEFAULT '0' COMMENT '是否禁用(0否1是)',
  `provinceid` int(11) DEFAULT NULL COMMENT '省编码',
  PRIMARY KEY (`activityid`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COMMENT='热门活动表';

-- ----------------------------
-- Records of activity_info
-- ----------------------------

-- ----------------------------
-- Table structure for ad_info
-- ----------------------------
DROP TABLE IF EXISTS `ad_info`;
CREATE TABLE `ad_info` (
  `adid` int(11) NOT NULL AUTO_INCREMENT COMMENT '广告编码',
  `title` varchar(100) DEFAULT NULL COMMENT '标题',
  `jumptype` tinyint(3) DEFAULT '0' COMMENT '跳转方式 0静态页面1店铺2商品',
  `objid` int(11) DEFAULT NULL COMMENT '店铺或商品编码',
  `state` tinyint(3) DEFAULT '0' COMMENT '是否禁用 0否1是',
  `content` text COMMENT '静态页面详情',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  `imgurl` varchar(200) DEFAULT NULL COMMENT '广告图片',
  PRIMARY KEY (`adid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='广告表';

-- ----------------------------
-- Records of ad_info
-- ----------------------------

-- ----------------------------
-- Table structure for ad_radio_business
-- ----------------------------
DROP TABLE IF EXISTS `ad_radio_business`;
CREATE TABLE `ad_radio_business` (
  `adradiobusinessid` int(11) NOT NULL AUTO_INCREMENT,
  `businessid` int(11) DEFAULT NULL COMMENT '商户编码',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  `adradioid` int(11) DEFAULT NULL COMMENT '收银机广告编码',
  PRIMARY KEY (`adradiobusinessid`)
) ENGINE=InnoDB AUTO_INCREMENT=217 DEFAULT CHARSET=utf8 COMMENT='收银机广告商户表';

-- ----------------------------
-- Records of ad_radio_business
-- ----------------------------

-- ----------------------------
-- Table structure for ad_radio_code
-- ----------------------------
DROP TABLE IF EXISTS `ad_radio_code`;
CREATE TABLE `ad_radio_code` (
  `adradiocodeid` int(11) NOT NULL AUTO_INCREMENT COMMENT '二维码编码',
  `imgurl` varchar(200) DEFAULT NULL COMMENT '图片路径',
  PRIMARY KEY (`adradiocodeid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='收银机广告二维码';

-- ----------------------------
-- Records of ad_radio_code
-- ----------------------------

-- ----------------------------
-- Table structure for ad_radio_image
-- ----------------------------
DROP TABLE IF EXISTS `ad_radio_image`;
CREATE TABLE `ad_radio_image` (
  `adradioimageid` int(11) NOT NULL AUTO_INCREMENT COMMENT '广告图片编码',
  `adradioid` int(11) DEFAULT NULL COMMENT '收银机广告编码',
  `url` varchar(200) DEFAULT NULL COMMENT '路径',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  `type` int(11) DEFAULT NULL COMMENT '1视频2图片',
  PRIMARY KEY (`adradioimageid`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8 COMMENT='收银机广告图片';

-- ----------------------------
-- Records of ad_radio_image
-- ----------------------------

-- ----------------------------
-- Table structure for ad_radio_info
-- ----------------------------
DROP TABLE IF EXISTS `ad_radio_info`;
CREATE TABLE `ad_radio_info` (
  `adradioid` int(11) NOT NULL AUTO_INCREMENT COMMENT '收银机广告编码',
  `state` int(2) DEFAULT '0' COMMENT '是否禁用 0否1是',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  `radioname` varchar(100) DEFAULT NULL COMMENT '活动名称',
  `type` int(2) DEFAULT NULL COMMENT '类型1视频2图片',
  PRIMARY KEY (`adradioid`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8 COMMENT='收银机广告表';

-- ----------------------------
-- Records of ad_radio_info
-- ----------------------------

-- ----------------------------
-- Table structure for admin_group
-- ----------------------------
DROP TABLE IF EXISTS `admin_group`;
CREATE TABLE `admin_group` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '权限组id（角色id）',
  `group_name` varchar(20) DEFAULT NULL COMMENT '权限组名（角色名）',
  `description` text COMMENT '描述',
  `ctime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  `mtime` timestamp NULL DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COMMENT='权限组表(角色表)';

-- ----------------------------
-- Records of admin_group
-- ----------------------------
INSERT INTO `admin_group` VALUES ('1', 'Administrator', '系统管理员', '2015-11-17 15:19:33', null);
INSERT INTO `admin_group` VALUES ('12', 'Businessadmin', '商户管理员', '2016-08-15 15:14:12', null);
INSERT INTO `admin_group` VALUES ('14', '测试呀', '测试', '2016-08-08 10:56:29', null);
INSERT INTO `admin_group` VALUES ('16', '财务', '', '2016-09-06 11:18:27', null);
INSERT INTO `admin_group` VALUES ('17', '操作组', '级别-低', '2016-09-08 09:41:23', null);

-- ----------------------------
-- Table structure for admin_group_permission
-- ----------------------------
DROP TABLE IF EXISTS `admin_group_permission`;
CREATE TABLE `admin_group_permission` (
  `group_permission_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `group_id` int(11) DEFAULT NULL COMMENT '权限组id（角色id）',
  `permission_id` int(11) DEFAULT '0' COMMENT '权限id',
  PRIMARY KEY (`group_permission_id`),
  UNIQUE KEY `unique_parameter_type_permissionid_schemeid` (`group_id`,`permission_id`)
) ENGINE=InnoDB AUTO_INCREMENT=749 DEFAULT CHARSET=utf8 COMMENT='权限组权限表（角色权限表）';

-- ----------------------------
-- Records of admin_group_permission
-- ----------------------------
INSERT INTO `admin_group_permission` VALUES ('672', '1', '7');
INSERT INTO `admin_group_permission` VALUES ('673', '1', '8');
INSERT INTO `admin_group_permission` VALUES ('674', '1', '19');
INSERT INTO `admin_group_permission` VALUES ('625', '1', '25');
INSERT INTO `admin_group_permission` VALUES ('626', '1', '43');
INSERT INTO `admin_group_permission` VALUES ('676', '1', '45');
INSERT INTO `admin_group_permission` VALUES ('677', '1', '71');
INSERT INTO `admin_group_permission` VALUES ('678', '1', '72');
INSERT INTO `admin_group_permission` VALUES ('675', '1', '75');
INSERT INTO `admin_group_permission` VALUES ('639', '1', '100');
INSERT INTO `admin_group_permission` VALUES ('640', '1', '101');
INSERT INTO `admin_group_permission` VALUES ('641', '1', '102');
INSERT INTO `admin_group_permission` VALUES ('642', '1', '103');
INSERT INTO `admin_group_permission` VALUES ('643', '1', '104');
INSERT INTO `admin_group_permission` VALUES ('644', '1', '105');
INSERT INTO `admin_group_permission` VALUES ('730', '1', '107');
INSERT INTO `admin_group_permission` VALUES ('648', '1', '108');
INSERT INTO `admin_group_permission` VALUES ('652', '1', '110');
INSERT INTO `admin_group_permission` VALUES ('653', '1', '111');
INSERT INTO `admin_group_permission` VALUES ('654', '1', '112');
INSERT INTO `admin_group_permission` VALUES ('657', '1', '114');
INSERT INTO `admin_group_permission` VALUES ('658', '1', '115');
INSERT INTO `admin_group_permission` VALUES ('659', '1', '116');
INSERT INTO `admin_group_permission` VALUES ('679', '1', '117');
INSERT INTO `admin_group_permission` VALUES ('661', '1', '118');
INSERT INTO `admin_group_permission` VALUES ('662', '1', '119');
INSERT INTO `admin_group_permission` VALUES ('663', '1', '120');
INSERT INTO `admin_group_permission` VALUES ('664', '1', '121');
INSERT INTO `admin_group_permission` VALUES ('665', '1', '122');
INSERT INTO `admin_group_permission` VALUES ('666', '1', '123');
INSERT INTO `admin_group_permission` VALUES ('670', '1', '126');
INSERT INTO `admin_group_permission` VALUES ('694', '1', '128');
INSERT INTO `admin_group_permission` VALUES ('720', '1', '134');
INSERT INTO `admin_group_permission` VALUES ('729', '1', '137');
INSERT INTO `admin_group_permission` VALUES ('731', '1', '138');
INSERT INTO `admin_group_permission` VALUES ('732', '1', '139');
INSERT INTO `admin_group_permission` VALUES ('733', '1', '140');
INSERT INTO `admin_group_permission` VALUES ('206', '11', '7');
INSERT INTO `admin_group_permission` VALUES ('360', '11', '8');
INSERT INTO `admin_group_permission` VALUES ('649', '12', '103');
INSERT INTO `admin_group_permission` VALUES ('647', '12', '107');
INSERT INTO `admin_group_permission` VALUES ('651', '12', '110');
INSERT INTO `admin_group_permission` VALUES ('719', '12', '111');
INSERT INTO `admin_group_permission` VALUES ('656', '12', '113');
INSERT INTO `admin_group_permission` VALUES ('667', '12', '124');
INSERT INTO `admin_group_permission` VALUES ('669', '12', '125');
INSERT INTO `admin_group_permission` VALUES ('671', '12', '127');
INSERT INTO `admin_group_permission` VALUES ('699', '12', '132');
INSERT INTO `admin_group_permission` VALUES ('701', '12', '133');
INSERT INTO `admin_group_permission` VALUES ('680', '13', '113');
INSERT INTO `admin_group_permission` VALUES ('681', '14', '7');
INSERT INTO `admin_group_permission` VALUES ('682', '14', '8');
INSERT INTO `admin_group_permission` VALUES ('683', '14', '19');
INSERT INTO `admin_group_permission` VALUES ('685', '14', '45');
INSERT INTO `admin_group_permission` VALUES ('686', '14', '71');
INSERT INTO `admin_group_permission` VALUES ('687', '14', '72');
INSERT INTO `admin_group_permission` VALUES ('684', '14', '75');
INSERT INTO `admin_group_permission` VALUES ('691', '14', '101');
INSERT INTO `admin_group_permission` VALUES ('715', '14', '103');
INSERT INTO `admin_group_permission` VALUES ('716', '14', '115');
INSERT INTO `admin_group_permission` VALUES ('688', '14', '117');
INSERT INTO `admin_group_permission` VALUES ('692', '14', '124');
INSERT INTO `admin_group_permission` VALUES ('689', '14', '125');
INSERT INTO `admin_group_permission` VALUES ('693', '14', '126');
INSERT INTO `admin_group_permission` VALUES ('695', '15', '117');
INSERT INTO `admin_group_permission` VALUES ('698', '15', '131');
INSERT INTO `admin_group_permission` VALUES ('727', '15', '135');
INSERT INTO `admin_group_permission` VALUES ('728', '15', '136');
INSERT INTO `admin_group_permission` VALUES ('734', '15', '141');
INSERT INTO `admin_group_permission` VALUES ('702', '16', '126');
INSERT INTO `admin_group_permission` VALUES ('739', '18', '145');
INSERT INTO `admin_group_permission` VALUES ('740', '18', '146');
INSERT INTO `admin_group_permission` VALUES ('741', '18', '147');

-- ----------------------------
-- Table structure for admin_permission
-- ----------------------------
DROP TABLE IF EXISTS `admin_permission`;
CREATE TABLE `admin_permission` (
  `permission_id` int(20) NOT NULL AUTO_INCREMENT COMMENT '权限id',
  `url` varchar(255) DEFAULT NULL COMMENT '控制器url地址',
  `navigation_id` int(20) NOT NULL COMMENT '菜单id',
  `permission_name` varchar(255) DEFAULT NULL COMMENT '权限名',
  `description` text COMMENT '描述',
  `ctime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  `mtime` timestamp NULL DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`permission_id`),
  KEY `appkey` (`url`(191)),
  KEY `permission_group` (`navigation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=utf8 COMMENT='权限表';

-- ----------------------------
-- Records of admin_permission
-- ----------------------------
INSERT INTO `admin_permission` VALUES ('7', '/adminUser/index', '29', '平台用户管理', '平台用户管理', '2015-12-04 16:49:37', null);
INSERT INTO `admin_permission` VALUES ('8', '/adminGroup/index', '30', '平台角色管理', '平台角色管理', '2015-12-04 16:50:20', null);
INSERT INTO `admin_permission` VALUES ('19', '/adminPermission/assignGroup', '30', '权限授权', '平台角色——权限设置', '2015-12-04 16:50:49', null);
INSERT INTO `admin_permission` VALUES ('24', '/trend/region', '61', '地区管理', '地区管理', '2015-11-24 17:42:41', null);
INSERT INTO `admin_permission` VALUES ('25', '/version/index', '77', '查询版本管理', '版本管理', '2015-12-02 16:45:53', null);
INSERT INTO `admin_permission` VALUES ('43', '/navigation/index', '90', '菜单管理', '菜单管理', '2015-11-30 16:37:40', null);
INSERT INTO `admin_permission` VALUES ('45', '/adminPermission/index', '106', '权限数据管理', '权限数据管理', '2015-12-04 16:51:42', null);
INSERT INTO `admin_permission` VALUES ('71', '/adminPermission/add', '106', '添加授权数据', '添加授权数据', '2015-12-04 16:54:19', null);
INSERT INTO `admin_permission` VALUES ('72', '/adminPermission/edit', '106', '修改权限数据', '修改权限数据', '2015-12-04 16:54:34', null);
INSERT INTO `admin_permission` VALUES ('75', '/adminPermission/assignPermission', '30', '修改权限', '修改权限', '2015-12-04 16:51:24', null);
INSERT INTO `admin_permission` VALUES ('100', '/goodsInfo/index', '125', '自营商品管理', '自营商品管理', '2016-07-29 16:06:42', null);
INSERT INTO `admin_permission` VALUES ('101', '/textInfo/editUploadImage', '124', '富文本上传图片', '富文本上传图片', '2016-07-27 16:58:12', null);
INSERT INTO `admin_permission` VALUES ('102', '/categoryInfo/index', '126', '商品分类管理', '商品分类管理', '2016-07-28 13:41:12', null);
INSERT INTO `admin_permission` VALUES ('103', '/orderInfo/index', '128', '平台订单列表', '', '2016-07-28 15:00:25', null);
INSERT INTO `admin_permission` VALUES ('104', '/businessGoodsAudit/index', '129', '商品上架审核', '商品上架审核', '2016-07-29 09:25:33', null);
INSERT INTO `admin_permission` VALUES ('105', '/businessGoodsAudit/downindex', '130', '商家下架审核', '商家下架审核', '2016-07-29 09:25:46', null);
INSERT INTO `admin_permission` VALUES ('107', '/goodsInfo/index', '132', '商家商品管理', '商家商品管理', '2016-08-01 11:02:40', null);
INSERT INTO `admin_permission` VALUES ('108', '/businessInfo/index', '134', '商户列表', '商户列表', '2016-08-01 12:38:01', null);
INSERT INTO `admin_permission` VALUES ('110', '/goodsAppraise/index', '137', '商品评价', '商品评价', '2016-08-02 14:26:33', null);
INSERT INTO `admin_permission` VALUES ('111', '/collect/index', '139', '订单汇总', '', '2016-08-02 14:42:11', null);
INSERT INTO `admin_permission` VALUES ('112', '/adRadioInfo/index', '141', '收银机广告列表', '收银机广告列表', '2016-08-03 09:36:49', null);
INSERT INTO `admin_permission` VALUES ('113', '/sales/index', '143', '线上销售统计', '线上销售统计', '2016-09-26 09:30:13', null);
INSERT INTO `admin_permission` VALUES ('114', '/adRadioInfo/findCodePage', '144', '二维码默认图片', '二维码默认图片', '2016-09-12 15:44:27', null);
INSERT INTO `admin_permission` VALUES ('115', '/orderrefund/index', '145', '商户订单列表', '', '2016-08-03 15:41:34', null);
INSERT INTO `admin_permission` VALUES ('116', '/businessInfo/hotindex', '150', '热门商户设置', '热门商户设置', '2016-08-03 16:19:56', null);
INSERT INTO `admin_permission` VALUES ('117', '/userInfo/index', '152', '用户列表', '用户列表', '2016-08-04 08:51:27', null);
INSERT INTO `admin_permission` VALUES ('118', '/activityInfo/index', '154', '热门活动列表', '热门活动列表', '2016-08-04 09:20:32', null);
INSERT INTO `admin_permission` VALUES ('119', '/adInfo/index', '156', '轮播图列表', '轮播图列表', '2016-08-04 14:15:44', null);
INSERT INTO `admin_permission` VALUES ('120', '/feedbackInfo/index', '158', '意见反馈', '', '2016-08-04 16:11:44', null);
INSERT INTO `admin_permission` VALUES ('121', '/trendVersion/index', '160', '版本管理', '', '2016-08-04 16:44:24', null);
INSERT INTO `admin_permission` VALUES ('122', '/expressCompany/index', '162', '快递公司列表', '快递公司列表', '2016-08-04 16:47:07', null);
INSERT INTO `admin_permission` VALUES ('123', '/freightInfo/index', '164', '运费模板列表', '运费模板列表', '2016-08-05 10:42:54', null);
INSERT INTO `admin_permission` VALUES ('124', '/depositset', '166', '提现设置', '', '2016-08-05 12:43:38', null);
INSERT INTO `admin_permission` VALUES ('125', '/businessBalanceDetail', '168', '帐户余额', '', '2016-08-05 15:56:36', null);
INSERT INTO `admin_permission` VALUES ('126', '/businessBalanceDetail', '170', '提现管理', '', '2016-08-06 11:29:41', null);
INSERT INTO `admin_permission` VALUES ('127', '/businessinfo', '171', '修改密码', '', '2016-08-06 12:48:28', null);
INSERT INTO `admin_permission` VALUES ('128', '/upexcel/upExcel', '124', '批量导入商品', '', '2016-08-17 16:54:34', null);
INSERT INTO `admin_permission` VALUES ('131', '/orderInfoDk/index', '178', '现金支付刷单', '现金支付刷单', '2016-08-25 08:46:13', null);
INSERT INTO `admin_permission` VALUES ('132', '/adminUser/index', '180', '收银账号列表', '收银账号列表', '2016-09-05 10:55:00', null);
INSERT INTO `admin_permission` VALUES ('133', '/businessAdvanceSetting/index', '181', '提现设置列表', '提现设置列表', '2016-09-06 09:19:31', null);
INSERT INTO `admin_permission` VALUES ('134', '/goodsInfo/businessindex', '182', '商家商品管理', '商家商品管理', '2016-09-08 09:35:00', null);
INSERT INTO `admin_permission` VALUES ('135', '/handorder', '183', '指定商户刷单', '指定商户刷单', '2016-09-13 15:22:09', null);
INSERT INTO `admin_permission` VALUES ('136', '/yhforder', '184', '优惠付刷单', '优惠付刷单', '2016-09-13 15:22:34', null);
INSERT INTO `admin_permission` VALUES ('137', '/downexcel/downExcel', '124', '导出excel', '', '2016-10-13 10:12:37', null);
INSERT INTO `admin_permission` VALUES ('138', '/downexcel/finddownCount', '124', '导出excel', '', '2016-10-13 10:16:24', null);
INSERT INTO `admin_permission` VALUES ('139', '/platformGoods/page', '124', '列表', '', '2016-10-13 10:16:51', null);
INSERT INTO `admin_permission` VALUES ('140', '/platformGoods/index', '124', '首页', '', '2016-10-13 10:18:23', null);
INSERT INTO `admin_permission` VALUES ('141', '/platAdvanceSetting', '186', '提现设置', '提现设置', '2016-11-21 10:38:28', null);
INSERT INTO `admin_permission` VALUES ('142', '/platformBalanceDetail/index', '188', '用户余额', '用户余额', '2016-11-21 12:54:32', null);
INSERT INTO `admin_permission` VALUES ('143', '/orderInfo/statistics', '190', '商品销量统计查询', '商品销量统计查询', '2016-11-21 13:29:56', null);
INSERT INTO `admin_permission` VALUES ('144', '/platformBalanceDetail', '192', '平台提现列表', '平台提现列表', '2016-11-21 15:57:54', null);
INSERT INTO `admin_permission` VALUES ('145', '/orderInfo/orderDetail', '194', '商户订单列表', '商户订单列表', '2016-12-13 15:49:31', null);
INSERT INTO `admin_permission` VALUES ('146', '/orderInfo/businessOrderCount', '195', '商户订单汇总', '商户订单汇总', '2016-12-14 11:58:53', null);
INSERT INTO `admin_permission` VALUES ('147', '/orderInfo/selectOrderGoods', '196', '商品销售查询', '商品销售查询', '2016-12-14 16:09:58', null);
INSERT INTO `admin_permission` VALUES ('148', '/orderInfo/businessOrderGoodsInfo', '198', '线下销量表', '线下销量表', '2016-12-15 12:49:56', null);
INSERT INTO `admin_permission` VALUES ('149', '/businessInfo/orderInfoPage', '200', '商铺线下订单列表', '商铺线下订单列表', '2016-12-15 13:48:32', null);
INSERT INTO `admin_permission` VALUES ('150', '/businessBalanceDetail/cashList', '201', '商铺提现列表', '商铺提现列表', '2016-12-15 20:21:09', null);

-- ----------------------------
-- Table structure for admin_token
-- ----------------------------
DROP TABLE IF EXISTS `admin_token`;
CREATE TABLE `admin_token` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `access_secret` varchar(255) DEFAULT NULL,
  `access_token` varchar(255) DEFAULT NULL,
  `appkey` varchar(255) DEFAULT NULL,
  `callback_url` varchar(255) DEFAULT NULL,
  `ctime` datetime DEFAULT NULL,
  `etime` datetime DEFAULT NULL,
  `mtime` datetime DEFAULT NULL,
  `request_secret` varchar(255) DEFAULT NULL,
  `request_token` varchar(255) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '0' COMMENT 'TOKEN状态: 0:刚申请REQUEST TOKEN；1:被拒绝；2：已授权：-1:已过期',
  `username` varchar(50) DEFAULT NULL,
  `verifier` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `access_token` (`access_token`(191)),
  KEY `appkey` (`appkey`(191)),
  KEY `ctime` (`ctime`),
  KEY `request_token` (`request_token`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin_token
-- ----------------------------

-- ----------------------------
-- Table structure for admin_user
-- ----------------------------
DROP TABLE IF EXISTS `admin_user`;
CREATE TABLE `admin_user` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `salt` varchar(20) DEFAULT NULL COMMENT '干扰码',
  `businessid` int(11) DEFAULT '0' COMMENT '商户编码（0为平台管理员）',
  `email` varchar(100) NOT NULL COMMENT '邮箱',
  `nickname` varchar(20) DEFAULT NULL COMMENT '昵称',
  `fullname` varchar(20) NOT NULL COMMENT '全名',
  `gender` tinyint(4) DEFAULT '0' COMMENT '性别1:男，2:女，0为未知',
  `idcard` char(18) NOT NULL COMMENT '身份证',
  `domain` enum('local','ldap','cas','epass') NOT NULL DEFAULT 'local' COMMENT '用户来源：local/epass usb token',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  `mtime` datetime DEFAULT NULL COMMENT '最后一次更新时间',
  `type` int(2) NOT NULL DEFAULT '0' COMMENT '0商户管理员1商户收银员',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '用户状态：0未激活，1已激活',
  `is_online` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否在线。1：是；0：否；',
  `token` varchar(40) DEFAULT NULL,
  `issoundopen` int(2) DEFAULT '0' COMMENT '推送声音是否关闭 0否1是',
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=273 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- ----------------------------
-- Records of admin_user
-- ----------------------------
INSERT INTO `admin_user` VALUES ('1', 'admin', '2efa92fcfef9ed4d692519db90693786', 'asdzxc', '0', '182028597@qq.com', '王老师', '王炼', '1', '310109198608066668', 'local', '2015-07-06 00:00:00', '2016-08-11 11:07:33', '0', '1', '1', '1231231', '0');
INSERT INTO `admin_user` VALUES ('21', '123123', '7bbf408fffc657bed09ba46ea8e3b717', '37ca72', '2', '', '商家管理员测试用', '商家管理员测试用', '1', '', 'local', '2016-08-01 11:10:03', '2016-08-01 11:10:03', '0', '1', '1', '123456', '1');
INSERT INTO `admin_user` VALUES ('29', '芒果', 'a6e45ff7a99d7bedc52daa62d154ac3f', 'ebe66a', null, '', '芒果1', '王呈呈', '0', '220881199101161924', 'local', '2016-08-08 10:32:58', '2016-08-08 10:33:23', '0', '1', '0', null, '0');
INSERT INTO `admin_user` VALUES ('30', '张芳毓', 'e2c700206e25d38bcb4a3181202a0991', '7cc276', null, '12354545465', '张芳毓', '张芳毓', '0', '210122199206240987', 'local', '2016-08-08 10:50:48', '2016-08-08 10:50:58', '0', '1', '0', null, '0');
INSERT INTO `admin_user` VALUES ('31', 'wangchch', '071ac4002783b0c936a5f770a54a58e2', '6ef2be', '10', '', '', '王呈呈1', '0', '', 'local', '2016-08-11 10:28:30', '2016-08-15 15:44:30', '0', '1', '1', '546498413', '0');
INSERT INTO `admin_user` VALUES ('32', '123456', '7008c6b2aeee5d27a1a7b618d33aef2f', 'cb9a4c', '4', '', null, '1234561', '0', '', 'local', '2016-08-12 14:17:42', null, '0', '1', '0', null, '0');
INSERT INTO `admin_user` VALUES ('34', 'zhangfy', 'c93a940ee8086bb6b3b2eb65b9cae999', '5ae513', '2', '', null, 'zhangfangy', '0', '', 'local', '2016-08-16 09:54:51', null, '0', '0', '0', null, '0');
INSERT INTO `admin_user` VALUES ('43', '王呈呈', '16986d6d45f83e4ab1a36013e6a6f032', '2ea9eb', null, '', 'wangcc', '王呈呈', '0', '220881199101161924', 'local', '2016-08-16 11:24:41', '2016-08-16 11:24:41', '0', '1', '0', null, '0');
INSERT INTO `admin_user` VALUES ('44', 'zhengby', '09ecd2bb1d780896de2b750996faf5c8', 'a11313', '2', '', null, 'zhengboyin', null, '', 'local', '2016-08-16 11:50:03', null, '0', '1', '0', null, '0');
INSERT INTO `admin_user` VALUES ('45', 'wangcc', '1beefdd0abf47758467aa4adc69b3beb', '4c0bd3', '0', '', ' 王呈呈 ', '王呈呈 ', '0', '', 'local', '2016-08-16 12:28:58', '2016-08-16 12:57:35', '0', '1', '1', '58746567', '0');
INSERT INTO `admin_user` VALUES ('47', 'xiaoph', 'b7f4656e52219a2cd460ad939923fc73', 'a7e844', '14', '', null, '123456', null, '', 'local', '2016-08-16 12:47:09', null, '0', '1', '1', null, '0');
INSERT INTO `admin_user` VALUES ('48', 'test001', '4c59bef80a3ba4b2ee2d31744344a1c0', '69330a', '2', '', null, 'test001', null, '', 'local', '2016-08-16 13:11:27', null, '0', '1', '1', '047f528b28174892905f5c941c9596ec', '0');
INSERT INTO `admin_user` VALUES ('49', '啊三大苏打', 'a2bb245c232ad6f30fc7474628ffb29d', 'adf96a', '0', '', '', '', null, '', 'local', '2016-08-16 13:24:27', '2016-08-16 13:24:27', '0', '1', '0', null, '0');
INSERT INTO `admin_user` VALUES ('50', '5656', '3cae20774af6a19afd76d7257f73f11e', '01031d', '0', '', '', '', null, '', 'local', '2016-08-16 13:25:03', '2016-08-16 13:25:03', '0', '1', '0', null, '0');
INSERT INTO `admin_user` VALUES ('51', '123123123', '779e4b1c339e2771a953778b69b5665b', '26dd51', '0', '', '', '', null, '', 'local', '2016-08-16 13:34:38', '2016-08-16 13:34:38', '0', '1', '0', null, '0');
INSERT INTO `admin_user` VALUES ('52', '12312312312', '944acaf3f718965cf39748fe73d1a0f4', '723f40', '0', '', '', '', null, '', 'local', '2016-08-16 13:36:21', '2016-08-16 13:39:04', '0', '1', '0', null, '0');
INSERT INTO `admin_user` VALUES ('53', 'jinlei', 'df7a64415818152dd1e5fd5347c30dce', 'bb5ee5', '11', '', null, '金磊', null, '', 'local', '2016-08-16 14:19:23', null, '0', '1', '1', '3907d5c8b82b4a6aa6652a40520f7ecf', '0');
INSERT INTO `admin_user` VALUES ('54', 'hahaha', 'c0d9ba8939a1c48933694fc82996a08c', 'e0f7b5', '9', '', null, '1', null, '', 'local', '2016-08-16 14:32:43', null, '0', '1', '1', '52dcdddd50a34fac85efd4f06575edcc', '0');
INSERT INTO `admin_user` VALUES ('55', 'xiaoxuewu', '38b621ffe83a7d8753dbffb10390e52a', '385989', '15', '', null, '肖先生', null, '', 'local', '2016-08-16 20:04:32', null, '0', '1', '1', 'f9d8b97d22164820992c2912d689111a', '0');
INSERT INTO `admin_user` VALUES ('56', '1234567', 'ada84939950a7d5ea941a07e93144143', 'c416ac', '0', '', '刷单管理员', '刷单管理员', null, '', 'local', '2016-08-19 13:49:08', '2016-08-19 13:49:08', '0', '1', '1', '123456789', '0');
INSERT INTO `admin_user` VALUES ('57', 'zz1231', 'dba59662a98889864b791eb272e08d60', '46b7ed', '14', '', null, '1231311', null, '', 'local', '2016-08-22 16:27:01', null, '0', '1', '0', '2ddfa98091d84d6ea47549fd12af0d00', '0');
INSERT INTO `admin_user` VALUES ('65', 'fdgdfg', '286cb818c4f70914d886df498ef96a85', 'a8526d', '2', '', '963258741', '', null, '', 'local', '2016-09-05 16:11:04', '2016-09-05 16:18:40', '1', '1', '0', '88b4e2c644b84d2d80f65f304f8bb8f2', '0');
INSERT INTO `admin_user` VALUES ('66', 'test003', 'ed8993da35db8753f7c049216b30add2', 'cc9524', '2', '', '123456', '', null, '', 'local', '2016-09-05 16:21:05', '2016-09-05 16:21:05', '1', '1', '0', '893bfb6198664d8f9ddba4fcbf68fa31', '0');
INSERT INTO `admin_user` VALUES ('67', 'test004', 'af024a7294d30459085cceba69d652e6', '3e13a8', '2', '', '123456', '', null, '', 'local', '2016-09-05 16:25:29', '2016-09-05 16:25:29', '1', '1', '0', '91a05d9d182b4f3eb6b9ebdf4c966572', '0');
INSERT INTO `admin_user` VALUES ('68', 'test005', '35161e9ba70840c3304fabe48bb56f0b', '8808b9', '2', '', '123456', '', null, '', 'local', '2016-09-05 16:27:37', '2016-09-05 16:27:37', '1', '1', '0', '5ffc426d116d47d7a15f43776c70ac17', '0');
INSERT INTO `admin_user` VALUES ('69', 'test006', '4aed270921c1f90f68961dae9ff0b3e8', 'b68991', '2', '', '123456', 'test006', null, '', 'local', '2016-09-05 16:29:46', null, '1', '1', '0', '4b579570d3604a68823f36b438ddcef9', '0');
INSERT INTO `admin_user` VALUES ('70', '999999', '83d5c09dd2578e374d291198dce4840b', '5f279a', '2', '', 'one', '999999', null, '', 'local', '2016-09-07 08:57:07', '2016-09-07 09:13:44', '1', '1', '0', 'd6238b7daba942d69a3da48554ce7e83', '0');
INSERT INTO `admin_user` VALUES ('71', 'yecy1986', '0cec7a8506a2357b4a4e775786810efc', 'a12449', '0', '', '叶春云', '叶春云', '1', '', 'local', '2016-09-07 13:53:14', '2016-09-07 13:53:14', '0', '1', '1', null, '0');
INSERT INTO `admin_user` VALUES ('72', 'yecy86', '4b33af066852c6165130472e0ac4acb4', 'd72893', '17', '', null, '叶春云', null, '', 'local', '2016-09-07 14:15:37', null, '0', '1', '1', 'e3b7448451f046aea2d5d44c06aa0218', '0');
INSERT INTO `admin_user` VALUES ('73', '000001', 'e84cd5ba6d2db0ab489bce990b65707b', '752877', '17', '', '002', 'yecy', null, '', 'local', '2016-09-07 14:21:30', '2016-09-23 08:26:48', '1', '1', '0', 'ffdad992537a4d558d89bf5dac187455', '0');
INSERT INTO `admin_user` VALUES ('74', 'test011', 'a60e889385d4606dc2d74ea419df60ff', 'af798b', '0', '222222', '', '', '1', '111111', 'local', '2016-09-07 16:21:20', '2016-09-07 17:49:13', '0', '0', '0', null, '0');
INSERT INTO `admin_user` VALUES ('75', 'test012', 'ebb794f6403f95be30e1d391037ad1ec', '52b830', '0', '', '', '/1q!Q_', null, '', 'local', '2016-09-07 16:23:34', '2016-09-07 17:50:21', '0', '1', '1', null, '0');
INSERT INTO `admin_user` VALUES ('76', 'test013', '0e35f61afcc1beefae8a468b5f1d52e7', 'e4ac5b', '0', '嗷嗷嗷', '普京', '', '1', '啊啊啊', 'local', '2016-09-07 16:24:33', '2016-09-07 16:31:30', '0', '1', '0', null, '0');
INSERT INTO `admin_user` VALUES ('77', 'test014', '424fc5fa3f7591ea2b4d25c92923da74', '44ad02', '0', '', '', '', null, '', 'local', '2016-09-07 16:33:09', '2016-09-07 17:05:58', '0', '1', '0', null, '0');
INSERT INTO `admin_user` VALUES ('78', 'test015', '40ec22262902db14d43bb96dcc84100d', '130533', '0', '', '', '', null, '', 'local', '2016-09-07 16:53:53', '2016-09-07 17:07:07', '0', '1', '1', null, '0');
INSERT INTO `admin_user` VALUES ('79', 'test016', '1e6926c3e62bf7f4e5405d95fa6b66c8', 'a05916', '0', '', 'test016', 'test016', null, '', 'local', '2016-09-08 09:42:39', '2016-09-08 09:42:46', '0', '1', '0', null, '0');
INSERT INTO `admin_user` VALUES ('80', 'testzby', '9c89a5b0b0fbf6c9d41e360bd6e08577', '36b126', '0', '', '', '', null, '', 'local', '2016-09-09 13:30:32', '2016-09-09 13:30:32', '0', '1', '0', null, '0');
INSERT INTO `admin_user` VALUES ('81', '123456789', '2a27db767bb275d828838f5932f6c91b', '48f717', '0', '', '', '', null, '', 'local', '2016-09-09 13:42:12', '2016-09-09 13:42:12', '0', '1', '0', null, '0');
INSERT INTO `admin_user` VALUES ('82', 'test99', 'cfac08891bc6cae0cb790ef330afe238', '581d71', '0', '', '', '', null, '', 'local', '2016-09-09 13:46:30', '2016-09-09 13:46:30', '0', '1', '0', null, '0');
INSERT INTO `admin_user` VALUES ('83', 'yecy87', '4c1fa3cdc158900942474ca48a20b11b', '3689b8', '17', '', null, '叶春云', null, '', 'local', '2016-09-10 10:25:11', null, '0', '0', '1', '19002c2d127e418c99a8e68a5bf836dc', '0');
INSERT INTO `admin_user` VALUES ('84', 'yecy88', '2071e2ff2120b4b9d8c0f228a2ddc0f9', '29a505', '17', '', null, '叶春云', null, '', 'local', '2016-09-10 10:25:21', null, '0', '0', '0', 'f708a7747fc94f5fb09c01951e0d3e8f', '0');
INSERT INTO `admin_user` VALUES ('85', 'yecy89', '01936fa25a690a5b0f570660826fb138', '1afafa', '17', '', null, '叶春云', null, '', 'local', '2016-09-10 10:25:30', null, '0', '0', '0', '37a71740492a45a59236deab894a4f81', '0');
INSERT INTO `admin_user` VALUES ('86', 'yecy85', '268b5244d97a317c583529cafaeee92f', '405ce8', '18', '', null, '叶春云', null, '', 'local', '2016-09-10 10:59:50', null, '0', '1', '1', 'f60e55bb5fbc4a328c28bb62882c4c81', '0');
INSERT INTO `admin_user` VALUES ('87', 'yecy84', 'c193329a30944793ec6e63ffa0c0f7ae', '99bd0b', '19', '', null, '叶春云', null, '', 'local', '2016-09-10 11:00:19', null, '0', '1', '1', 'a9edbbacc7ba4182b85cab7feae6f8bd', '0');
INSERT INTO `admin_user` VALUES ('88', '000002', '322696279a180bfbaa45391a17577854', 'fb2e73', '19', '', 'test017', '', null, '', 'local', '2016-09-10 11:02:08', null, '1', '1', '0', '105856098c8b4f31a66366005049e583', '0');
INSERT INTO `admin_user` VALUES ('89', 'test01', '59c97e6eed43739922e12d81e921cfb8', '200d49', '0', '', '', '', null, '', 'local', '2016-09-11 14:10:59', '2016-09-12 11:10:18', '0', '1', '1', null, '0');
INSERT INTO `admin_user` VALUES ('90', 'test02', '6af84a0f0c1daff69e62089a25adc276', '9c564a', '0', '', '', '', null, '', 'local', '2016-09-12 11:28:16', '2016-09-12 11:28:16', '0', '1', '0', null, '0');
INSERT INTO `admin_user` VALUES ('91', '123123123123', '7e6b687b45c3ba3a04264f627458365b', '4bc499', '0', '', '', '', null, '', 'local', '2016-09-13 09:53:18', '2016-09-13 09:53:18', '0', '1', '0', null, '0');
INSERT INTO `admin_user` VALUES ('92', '2222222', 'ea231a604e0bdbc64a9fe2b39e6b01c6', '6451e0', '0', '', '', '', null, '', 'local', '2016-09-13 09:58:05', '2016-09-13 09:58:05', '0', '1', '0', null, '0');
INSERT INTO `admin_user` VALUES ('93', '333333', 'bb4a21fc84637afefb72ece5481ffab4', '976ed7', '0', '', '', '', null, '', 'local', '2016-09-13 09:58:18', '2016-09-13 09:58:18', '0', '1', '0', null, '0');
INSERT INTO `admin_user` VALUES ('94', '444444', '7afdf7458f0d0fdf3aba25e9a5b9d960', 'f7687d', '0', '4', '2', '1', '1', '3', 'local', '2016-09-13 10:01:20', '2016-09-13 10:01:20', '0', '1', '0', null, '0');
INSERT INTO `admin_user` VALUES ('95', '555555', 'd13a64e917b4bc778bf5224f79463bff', 'd15f2f', '0', '4', '2', '1', '0', '3', 'local', '2016-09-13 10:02:52', '2016-09-13 10:02:52', '0', '1', '0', null, '0');
INSERT INTO `admin_user` VALUES ('96', '7777777', '6db491395ba85a8a278f6f738f4c069c', 'e43047', '0', '2', '1', '123', null, '2', 'local', '2016-09-13 14:40:58', '2016-09-13 14:40:58', '0', '1', '0', null, '0');
INSERT INTO `admin_user` VALUES ('97', '1231232132', '29d5ac15118097b574a6e7dc6e1b5595', 'd34123', '0', '1', '1', '11', '0', '1', 'local', '2016-09-13 14:42:08', '2016-09-13 14:42:08', '0', '1', '0', null, '0');
INSERT INTO `admin_user` VALUES ('98', 'test03', '5835c86275490a2249b6376de7d43258', 'c83354', '0', '', '', '', null, '', 'local', '2016-09-13 15:06:27', '2016-09-13 15:06:27', '0', '1', '0', null, '0');
INSERT INTO `admin_user` VALUES ('99', '000003', '5df47b6334d7d1fc8594fc82939ba275', '97f2b9', '15', '', 'xiaoxuewu', '', null, '', 'local', '2016-09-19 10:44:18', null, '1', '1', '0', 'a613a3d68b5f46bcad519860c0cad59e', '0');
INSERT INTO `admin_user` VALUES ('100', 'zhangfangyu', 'ec1b8c69c65825926d877e2fb95d80d8', 'da5057', '20', '', null, '张芳毓', null, '', 'local', '2016-09-20 09:06:18', null, '0', '1', '1', 'ac8f0ff47bd14d9188715779a9d0d38f', '0');
INSERT INTO `admin_user` VALUES ('101', 'zzzzzz', '26c05c793fc2ccc206a6f5cc34e8f7a5', 'e28703', '20', '', 'zzzzzz', '', null, '', 'local', '2016-09-20 09:08:50', '2016-09-28 09:22:15', '1', '1', '0', '4df25b59173149e78dda0726fa15adda', '0');
INSERT INTO `admin_user` VALUES ('102', '100108', 'ab20f4b22f0b57fbef5fa5ee08eb795f', 'dfee47', '22', '', null, '收银员', null, '', 'local', '2016-09-21 13:57:43', null, '0', '1', '0', '6f949d20a7934e4193be1611ad24bcdf', '0');
INSERT INTO `admin_user` VALUES ('103', 'db000108', '626e1cd09508b5fb37876dd6fed63f86', '280206', '22', '', null, '测试员', null, '', 'local', '2016-09-21 14:07:01', null, '0', '1', '1', '82aba008303e4723b0b398beb17b1d93', '0');
INSERT INTO `admin_user` VALUES ('104', '000108', '1e67e8009b4915fd618bc76e94266cda', 'ddbbb7', '22', '', '000108', '', null, '', 'local', '2016-09-21 14:09:56', null, '1', '0', '0', '950769a55a5d40f88c2a93f6228225ae', '0');
INSERT INTO `admin_user` VALUES ('105', 'wang111', '3c57f90913b598bf1dbac6a32b1ed5b1', '0dea55', '10', '', 'wang', '', null, '', 'local', '2016-09-21 14:14:37', null, '1', '0', '0', 'd37c622efeff44ec859f243af424e06c', '0');
INSERT INTO `admin_user` VALUES ('106', '198484', 'c4efd5652edaacfd432440b0cb88c23d', 'f6f9c9', '11', '', '金磊', '', null, '', 'local', '2016-09-23 20:43:37', '2016-09-23 20:44:03', '1', '1', '0', 'fd7bd9f8101943898dbea5ff18e19f48', '0');
INSERT INTO `admin_user` VALUES ('107', 'ycy001', '091314b49f80dbd3ca8b194a8243963f', '2e2b82', '17', '', '1111', '', null, '', 'local', '2016-09-27 16:27:40', null, '1', '1', '0', 'c14dec47140f4b7f9b8cb92d239deb81', '0');
INSERT INTO `admin_user` VALUES ('108', 'SY000108', '07b28a208b2f52cdd1ee99365fa194bf', '8f0309', '22', '', 'SY000108', '', null, '', 'local', '2016-09-27 16:30:14', '2016-09-27 16:38:57', '1', '1', '0', 'f0c17412c2624d7096c0172c0fd1e9e5', '0');
INSERT INTO `admin_user` VALUES ('109', 'db000002', '9d59a218faa97d157b34c95d8617bcc2', 'b7f0e8', '24', '', null, 'db000002', null, '', 'local', '2016-09-27 16:34:30', null, '0', '1', '1', 'c91d36072df941199542e4b6e54cde7c', '0');
INSERT INTO `admin_user` VALUES ('110', 'db000003', 'de609254415d7304644b991bd9b875d5', '95dd21', '25', '', null, 'db000003', null, '', 'local', '2016-09-27 16:35:13', null, '0', '1', '1', '8fd3fc53923f4260bb8c5bf1ff3571d4', '0');
INSERT INTO `admin_user` VALUES ('111', 'db000005', 'a0b272a893ff0024c03ea6f2c9594cea', '650d8b', '26', '', null, 'db000005', null, '', 'local', '2016-09-27 16:36:03', null, '0', '1', '1', '67c598975f8b4b6ba481ca7cde617459', '0');
INSERT INTO `admin_user` VALUES ('112', 'SY000002', 'e919814ae1b9533a702a9d06e9ab9b3d', 'b5dd36', '24', '', 'SY000002', '', null, '', 'local', '2016-09-27 16:37:49', null, '1', '1', '0', '11b5b676a77b497083f2edfc277f95f1', '0');
INSERT INTO `admin_user` VALUES ('113', 'SY000003', '7a99fb5501d5dfa8fd28693ee5540ecb', '64ffcd', '25', '', 'SY000003', '', null, '', 'local', '2016-09-27 16:40:04', '2016-10-14 11:53:21', '1', '1', '0', 'eb994d44130543798f873f4a125ad7ca', '0');
INSERT INTO `admin_user` VALUES ('114', 'SY000005', 'c48cbe0902ca18630bc30deb2ceb4e6b', '17e938', '26', '', 'SY000005', '', null, '', 'local', '2016-09-27 16:41:51', '2016-10-14 11:55:55', '1', '1', '0', '812284e902d141479c89a5f22842b4da', '0');
INSERT INTO `admin_user` VALUES ('115', 'zhangfy111', '1def3f8e4d78aace6e2ee4ecde428145', 'e87e94', '0', '111', 'zhangfangyu', 'zhangfangyu', '0', '111', 'local', '2016-09-30 09:59:43', '2016-09-30 09:59:43', '0', '1', '1', null, '0');
INSERT INTO `admin_user` VALUES ('116', '098765', '9f40d4d92a203b875ce89a8bfcdb82b1', 'd5b4ff', '2', '', '111', '', null, '', 'local', '2016-09-30 15:55:59', null, '1', '1', '0', '05918e47a1514deb9b657fd597c670f3', '0');
INSERT INTO `admin_user` VALUES ('117', 'ycy002', '2b56a6bec9d83c5e45105c095ef315e6', '5491e6', '17', '', '211', '', null, '', 'local', '2016-09-30 21:49:12', null, '1', '1', '0', 'fe5b6a2221f8465da98cedd81d520b60', '0');
INSERT INTO `admin_user` VALUES ('118', 'nielei', '08b09894666be324868651afe5c1256c', '209d99', '27', '', null, '聂磊', null, '', 'local', '2016-10-08 11:35:52', null, '0', '1', '1', '2cdfde79d10c492f8ba7f9a78b6ec9f5', '0');
INSERT INTO `admin_user` VALUES ('119', '11111111', 'b1014fb99ab440a217c7462a12f744d2', '147105', '27', '', null, '内用', null, '', 'local', '2016-10-08 11:36:16', null, '0', '1', '0', 'b3c603600c094d24addfc3095c9218f0', '0');
INSERT INTO `admin_user` VALUES ('120', 'xiaoxuewu1', '661b3cef5ac7fa955820f61c5714da1c', 'a28302', '15', '', null, '1', null, '', 'local', '2016-10-08 11:39:12', null, '0', '1', '1', '5d677275f14b4d629a49ad75c40fb81f', '0');
INSERT INTO `admin_user` VALUES ('121', 'SY444444', '5607903361e1d97f0877b9c86547c3c3', '2bc599', '27', '', '聂磊', '', null, '', 'local', '2016-10-10 14:24:55', null, '1', '1', '0', 'aafe47e1f29c4bd692b5f256d76b9359', '0');
INSERT INTO `admin_user` VALUES ('122', 'syyecy85', 'cacea7472c7cd094bd37b12a796b07ae', '680d84', '18', '', '南京西路店', '', null, '', 'local', '2016-11-10 22:17:28', null, '1', '1', '0', '3dbde6d52c2d480991c603d1cfed90d9', '0');
INSERT INTO `admin_user` VALUES ('123', 'db000006', '37145a98bebb206e246ccbc3d9e9b912', '2339e5', '28', '', null, '黄凌生', null, '', 'local', '2016-11-11 16:18:38', null, '0', '1', '1', 'eced0fcec7d14669bb5efef0c62b81cc', '0');
INSERT INTO `admin_user` VALUES ('124', 'SY000006', '20dae449a590cafa12f631ca2ee1e4a9', 'b6e1e0', '28', '', '黄凌生', '', null, '', 'local', '2016-11-11 16:21:11', null, '1', '1', '0', 'b580ac5c3bc948009e4b55add43faf5a', '0');
INSERT INTO `admin_user` VALUES ('125', 'db000007', '8acabd057eceb677697c6181c172c080', 'c40c6c', '29', '', null, 'NO.7', null, '', 'local', '2016-11-14 10:49:46', null, '0', '1', '1', '67bdd5f56f99495ba5a87bb094785a38', '0');
INSERT INTO `admin_user` VALUES ('126', 'db000008', '232b8c710b8cd418b2749b90ba9e944d', '53c129', '30', '', null, 'NO.8', null, '', 'local', '2016-11-14 10:50:44', null, '0', '1', '1', '2de8be41d21e4e859423e4d26fac32f4', '0');
INSERT INTO `admin_user` VALUES ('127', 'db000009', 'd7921e5cfb8bf03aef1caa413f429f53', '7f2650', '31', '', null, 'NO.9', null, '', 'local', '2016-11-14 10:51:12', null, '0', '1', '1', '8d7ec7271804472fa51ec57bb109343b', '0');
INSERT INTO `admin_user` VALUES ('128', 'db000010', '8992e1322b1ea2b5fa422e578033b43e', '43c29b', '32', '', null, 'NO.10', null, '', 'local', '2016-11-14 10:51:45', null, '0', '1', '1', 'e25e36e421524345a268ef795d67b1df', '0');
INSERT INTO `admin_user` VALUES ('129', 'sy000007', '960948159c83f4b870ad0d0715d91620', 'c6b3ee', '29', '', '收银员NO.7', '', null, '', 'local', '2016-11-14 10:54:12', null, '1', '1', '0', '4321435caca643a8be1a09cfa8e22ae5', '0');
INSERT INTO `admin_user` VALUES ('130', 'sy000008', '18b75d5fecd0a418d066715f992c3567', 'f3f385', '30', '', '收银员NO.8', '', null, '', 'local', '2016-11-14 10:57:10', '2016-11-14 10:57:32', '1', '1', '0', '4868b7a3cc1d4cd5baaee1ef86de46a4', '0');
INSERT INTO `admin_user` VALUES ('131', 'sy000009', '9763639aaaa9ef26a146c25af29aba73', '0fcde2', '31', '', '收银员NO.9', '', null, '', 'local', '2016-11-14 10:58:56', null, '1', '1', '0', '7976cccb5ac244f6ab5e1f13a5668a8c', '0');
INSERT INTO `admin_user` VALUES ('132', 'sy000010', 'f5834a49702966aab661878e8b5e1f6a', '65d54f', '32', '', '收银员NO.10', '', null, '', 'local', '2016-11-14 11:00:18', null, '1', '1', '0', '0a52d807c05b4b0398940f6629eca49e', '0');
INSERT INTO `admin_user` VALUES ('133', 'db000011', '4bb17ccacb39d374e0a894cc522b326b', '03dfe2', '33', '', null, 'NO.11', null, '', 'local', '2016-11-17 15:38:34', null, '0', '1', '1', '788daafade504836b5ddf7bebbfd3c92', '0');
INSERT INTO `admin_user` VALUES ('134', 'db000012', 'd67e3dfe686add2640d888859c80bde4', 'e53d81', '34', '', null, 'NO.12', null, '', 'local', '2016-11-17 15:39:29', null, '0', '1', '1', 'f3439e83f76744faa70f71c81444525a', '0');
INSERT INTO `admin_user` VALUES ('135', 'db000015', 'b7557789ea705a73611a3a08d32b5a3d', 'f901e9', '35', '', null, 'NO.15', null, '', 'local', '2016-11-17 15:39:50', null, '0', '1', '1', '431bf68ba9b14d9ea2b61d632f6b6eeb', '0');
INSERT INTO `admin_user` VALUES ('136', 'db000016', '17acb7c9accf47cd081c218870093b13', 'f4edea', '36', '', null, 'NO.16', null, '', 'local', '2016-11-17 15:40:08', null, '0', '1', '1', '7801677bd4a446f49c4b257fa79d8520', '0');
INSERT INTO `admin_user` VALUES ('137', 'db000017', '4d41ef5eb91e009bf540a7cebd601055', '4f59bf', '37', '', null, 'NO.17', null, '', 'local', '2016-11-17 15:43:49', null, '0', '1', '1', 'fecc8ac91c6c4f51acd4c5a531509ed7', '0');
INSERT INTO `admin_user` VALUES ('138', 'db000018', '037fd03b73552e80357ed1bf92d369b6', '56242f', '38', '', null, 'NO.18', null, '', 'local', '2016-11-17 15:44:04', null, '0', '1', '1', '22953c1b6d714d9591dbd5fc26341bb2', '0');
INSERT INTO `admin_user` VALUES ('139', 'db000019', '3d1d8d06cbf61581f44964cc6a5439c5', 'f909eb', '39', '', null, 'NO.19', null, '', 'local', '2016-11-17 15:44:48', null, '0', '1', '1', 'df5533bec97b4c49a0119b5d7105d039', '0');
INSERT INTO `admin_user` VALUES ('140', 'db000020', '7b57a2e0eafac4261d4ae84cd4799844', '08aeed', '40', '', null, 'NO.20', null, '', 'local', '2016-11-17 15:45:11', null, '0', '1', '1', 'd32c1d1b690842feb386357c4ed198c5', '0');
INSERT INTO `admin_user` VALUES ('141', 'sy000011', '318246e628405014a49447b3ca19e576', 'b4f3e7', '33', '', '11号店', '', null, '', 'local', '2016-11-17 15:52:19', null, '1', '1', '0', '847a38a24aef492582f1ff00afe37fca', '0');
INSERT INTO `admin_user` VALUES ('142', 'sy000012', 'ccb83a874affc337a625e8cf7f759731', '61b88e', '34', '', '收银员NO.12', '', null, '', 'local', '2016-11-17 15:55:36', null, '1', '1', '0', '59fe9e6af99a41258151717ea0253a88', '0');
INSERT INTO `admin_user` VALUES ('143', 'sy000015', '2dd462e08138c45d44d74a447178889e', 'da0eea', '35', '', '收银员NO.15', '', null, '', 'local', '2016-11-17 15:57:48', null, '1', '1', '0', '818370082859471cba23e88b3a8f4364', '0');
INSERT INTO `admin_user` VALUES ('144', 'sy000016', '5018d63c0ae2494cc9cb11463038c4dc', 'f1f6d3', '36', '', '收银员NO.16', '', null, '', 'local', '2016-11-17 16:09:05', null, '1', '1', '0', '83e4789fccc74280ada30fe793e7b41b', '0');
INSERT INTO `admin_user` VALUES ('145', 'sy000017', '624e0e3e8f5cae4274adf6304fb71498', 'f5cf26', '37', '', '收银员NO.17', '', null, '', 'local', '2016-11-17 16:24:22', null, '1', '1', '0', 'a2dd0ee9e899415e84a43a0385d301ca', '0');
INSERT INTO `admin_user` VALUES ('146', 'sy000018', 'd4e17a50e8d23cb87ce7fe98c5d994ef', 'd69a26', '38', '', '收银员NO.18', '', null, '', 'local', '2016-11-17 16:26:13', null, '1', '1', '0', '62d2b81a0c37499b85e25038ccfaedb6', '0');
INSERT INTO `admin_user` VALUES ('147', 'sy000019', 'b231d9f409cc9308f7c1c25514050401', 'fd1bc4', '39', '', '收银员NO.19', '', null, '', 'local', '2016-11-17 16:27:59', null, '1', '1', '0', '6d591c84ff844c1e8df72ae2c371e288', '0');
INSERT INTO `admin_user` VALUES ('148', 'sy000020', '7eef21074869d03afab686a55dd03a7d', 'f72a1a', '40', '', '收银员NO.20', '', null, '', 'local', '2016-11-17 16:29:22', null, '1', '1', '0', 'ce447d2c75cb42ddb03969d4a3753818', '0');
INSERT INTO `admin_user` VALUES ('149', 'db000021', 'eafcdf27a45277f6a382a6a4c8daba1a', '02d458', '41', '', null, 'NO.21', null, '', 'local', '2016-11-17 17:34:29', null, '0', '1', '1', '8ea2013bcc3f4e548939d62e7be62b23', '0');
INSERT INTO `admin_user` VALUES ('150', 'db000022', 'ea70a787330720d08712ca8ead19b44a', '195497', '42', '', null, 'NO.22', null, '', 'local', '2016-11-17 17:34:54', null, '0', '1', '1', 'efc8ab3993874afb85ccabf3bef4fe9a', '0');
INSERT INTO `admin_user` VALUES ('151', 'db000023', '21eb3334e60a26a4eefcf9d9858055f9', '2856c2', '43', '', null, 'NO.23', null, '', 'local', '2016-11-17 17:36:08', null, '0', '1', '1', '6f4b0576fd6840f9b3e168f054717dd9', '0');
INSERT INTO `admin_user` VALUES ('152', 'db000025', '5acbdbbb43c0da22c2f24b558cb1cc21', 'b698e3', '45', '', null, 'NO.25', null, '', 'local', '2016-11-17 17:36:37', null, '0', '1', '1', 'fc6a09ca2acb42b38355bec6527b609c', '0');
INSERT INTO `admin_user` VALUES ('153', 'db000026', '8ea82d0c430a0db4d17d1927d0c46b6c', '663893', '46', '', null, 'NO.26', null, '', 'local', '2016-11-17 17:37:05', null, '0', '1', '1', 'e215017b7e4a4cfeaff37658186a2412', '0');
INSERT INTO `admin_user` VALUES ('154', 'db000027', '0120a921ba79c3d21dd3e7f2cd1447df', 'babf7e', '47', '', null, 'NO.27', null, '', 'local', '2016-11-17 17:37:26', null, '0', '1', '1', '9c003171f2ce4878834e861284263313', '0');
INSERT INTO `admin_user` VALUES ('155', 'db000028', 'cce7e8825de83ee28038313d47c57a6d', 'c14097', '48', '', null, 'NO.28', null, '', 'local', '2016-11-17 17:38:14', null, '0', '1', '1', 'b12db2f2b1fe46dca37d188c3f65a5bd', '0');
INSERT INTO `admin_user` VALUES ('156', 'db000029', '9cbdef78532affcc609b4201c7cd2678', '657661', '49', '', null, 'NO.29', null, '', 'local', '2016-11-17 17:38:37', null, '0', '1', '1', 'a3db378ed5204c759c8e878bc824f0ab', '0');
INSERT INTO `admin_user` VALUES ('157', 'db000030', '1e0fd4a30e574038b20f1ee676def4f4', 'ac5409', '50', '', null, 'NO.30', null, '', 'local', '2016-11-17 17:38:56', null, '0', '1', '1', 'bd2f008201014c918da782b11d7f4f48', '0');
INSERT INTO `admin_user` VALUES ('158', 'db000031', '5d57a1ee49827c7c426c012e6f3b02ef', '5573fc', '51', '', null, 'NO.31', null, '', 'local', '2016-11-17 17:39:20', null, '0', '1', '1', 'b1b731a77c5842b8b972f308f2bf7bca', '0');
INSERT INTO `admin_user` VALUES ('159', 'db000032', '7cb90c07d3220281c869824a134cb84d', '615c94', '52', '', null, 'NO.32', null, '', 'local', '2016-11-17 17:39:40', null, '0', '1', '1', '332221ee14eb4a7a9fc1aa53210e5886', '0');
INSERT INTO `admin_user` VALUES ('160', 'db000033', 'b32fc99b188dc616efabef011b62e9d8', 'b822f3', '53', '', null, 'NO.33', null, '', 'local', '2016-11-17 17:40:06', null, '0', '1', '1', '4adfe83fe2d64f819e455259826e010d', '0');
INSERT INTO `admin_user` VALUES ('161', 'sy000021', '8a2c9b716933c2da92fbed3735bb9e96', '0afd2d', '41', '', '收银员NO.21', '', null, '', 'local', '2016-11-17 17:41:55', null, '1', '1', '0', '11715eb17e77414aaf40ce0184130a24', '0');
INSERT INTO `admin_user` VALUES ('162', 'sy000022', 'dc8f145dd0d3c51fffb35ca5ce835f7d', '72ee03', '42', '', '收银员NO.22', '', null, '', 'local', '2016-11-17 17:44:14', null, '1', '1', '0', '0015c935dd5240c89d30be93d00e51ca', '0');
INSERT INTO `admin_user` VALUES ('163', 'sy000023', '59d7fed59a58a2e02488da08cba053b7', 'a7a12a', '43', '', '收银员NO.23', '', null, '', 'local', '2016-11-17 17:48:27', null, '1', '1', '0', '604e56d3c7a54fa4a2246da63a8e8fda', '0');
INSERT INTO `admin_user` VALUES ('164', 'sy000025', 'af3ea48b3792da354ea7db4fbae0e5e7', '267282', '45', '', '收银员NO.25', '', null, '', 'local', '2016-11-17 17:51:05', null, '1', '1', '0', 'f8df1ec517c145b68381fe9ed5609877', '0');
INSERT INTO `admin_user` VALUES ('165', 'sy000026', '0e14d9307754c79812ed30327ccade90', '4861f8', '46', '', '收银员NO.26', '', null, '', 'local', '2016-11-17 17:53:55', null, '1', '1', '0', '8cea4546ce7540a6a47874814853df14', '0');
INSERT INTO `admin_user` VALUES ('166', 'sy000027', '0755c89abc37bd1a9dcecdc17856a068', '360966', '47', '', '收银员NO.27', '', null, '', 'local', '2016-11-17 18:00:30', null, '1', '1', '0', '775b23ab65cb42d4932615967dfb5c8a', '0');
INSERT INTO `admin_user` VALUES ('167', 'sy000028', '1faa61fc27c21bd05b3998c385c28c2b', '40fabb', '48', '', '收银员NO.28', '', null, '', 'local', '2016-11-17 18:44:55', null, '1', '1', '0', '2929bf36d72d477a85b14b7732246ecb', '0');
INSERT INTO `admin_user` VALUES ('168', 'sy000029', '3c871f2c28ac2e8720f7425744d385ef', '945e19', '49', '', '收银员NO.29', '', null, '', 'local', '2016-11-17 18:47:02', null, '1', '1', '0', '0627f2d67f2b473c890c66ca027671ed', '0');
INSERT INTO `admin_user` VALUES ('169', 'sy000030', '900ba7a15801f701c7694d95e5b53bb8', '0ff6e4', '50', '', '收银员NO.30', '', null, '', 'local', '2016-11-17 18:48:25', null, '1', '1', '0', 'c65797e2e8784eaa8c46514b796fa4a0', '0');
INSERT INTO `admin_user` VALUES ('170', 'sy000031', '38afc84ca448d5a342cbe6306100332b', 'fa4ef3', '51', '', '收银员NO.31', '', null, '', 'local', '2016-11-17 18:50:28', null, '1', '1', '0', 'aa57b15a144c49169adaa9037de78faf', '0');
INSERT INTO `admin_user` VALUES ('171', 'sy000032', '8cacb9b1db409829bc8626c66cc5b7c7', '2d03dc', '52', '', '收银员NO.32', '', null, '', 'local', '2016-11-17 18:52:08', null, '1', '1', '0', '0701cd68fa92419e9233a3016dc9e6aa', '0');
INSERT INTO `admin_user` VALUES ('172', 'sy000033', '0760aba2427c13119f5d43d2172d8f60', 'c63b37', '53', '', '收银员NO.33', '', null, '', 'local', '2016-11-17 18:53:40', null, '1', '1', '0', '015d0268b6664029b58b5f85900321c0', '0');
INSERT INTO `admin_user` VALUES ('173', 'oa000010', '0acf3412ccfc2be60d68afb8890dd356', '05fd3b', '32', '', null, 'oa000010', null, '', 'local', '2016-11-17 20:09:36', null, '0', '1', '1', '778ed27889f6442da0b28cbc1e70f198', '0');
INSERT INTO `admin_user` VALUES ('174', 'oa000009', '5fdfb8da6dd901f23d59590069fa8ebf', '0a5178', '31', '', null, 'oa000009', null, '', 'local', '2016-11-17 20:10:48', null, '0', '1', '1', '923267cc067044e19384798c2cbbdbb7', '0');
INSERT INTO `admin_user` VALUES ('175', 'oa000008', '03a1070fe5fd1401be0a77caa7b4042d', '6aa002', '30', '', null, 'oa000008', null, '', 'local', '2016-11-17 20:11:16', null, '0', '1', '1', 'd351fb87aa694d53aee3604a3486fd9a', '0');
INSERT INTO `admin_user` VALUES ('176', 'oa000007', 'f06a6d0c9c0518497c67787c4802e8f2', 'b391d4', '29', '', null, 'oa000007', null, '', 'local', '2016-11-17 20:11:36', null, '0', '1', '1', '298d887e6a7a4b6a8e0666d4479d8071', '0');
INSERT INTO `admin_user` VALUES ('177', 'oa000006', '87825501605a88b9fa53cce65d8196b1', '3fcb84', '28', '', null, 'oa000006', null, '', 'local', '2016-11-17 20:11:53', null, '0', '1', '1', '9da3c9e118ee4db2b985a206232730cb', '0');
INSERT INTO `admin_user` VALUES ('178', 'oa000001', 'bca6fee5c8cf08e01adb7aa5d60318fa', '0e2cb6', '15', '', null, 'oa000001', null, '', 'local', '2016-11-18 13:01:36', null, '0', '1', '1', 'a10b9b96d7554bab9453b752ce07508f', '0');
INSERT INTO `admin_user` VALUES ('179', 'oa000108', '21f49e0acdb1cf054560bf61c514fcc7', '24e5fa', '22', '', null, 'oa000108', null, '', 'local', '2016-11-18 13:03:01', null, '0', '1', '0', '745400b773bf4e69aa615d300c48e56a', '0');
INSERT INTO `admin_user` VALUES ('180', 'oa000002', '2482455ab37143992d5c42fa37f32d3c', '2cea1b', '24', '', null, 'oa000002', null, '', 'local', '2016-11-18 13:03:53', null, '0', '1', '0', '45ac8c20bafa4221bca0da14e975394f', '0');
INSERT INTO `admin_user` VALUES ('181', 'oa000003', '8841e34e1331d976e2bac67d9f920850', 'adf0aa', '25', '', null, 'oa000003', null, '', 'local', '2016-11-18 13:04:29', null, '0', '1', '0', '27dc531cecd945f090755dc45d7fdba5', '0');
INSERT INTO `admin_user` VALUES ('182', 'oa000005', '111747b8e2981aeecfbcd0a12ee9ae73', '67325a', '26', '', null, 'oa000005', null, '', 'local', '2016-11-18 13:05:05', null, '0', '1', '0', '9afcef4d7f8d4152b7c908077f4e0102', '0');
INSERT INTO `admin_user` VALUES ('183', 'oa000011', 'a1b5997a77581da6219d26a29b2722b3', 'd14015', '33', '', null, 'oa000011', null, '', 'local', '2016-11-18 14:05:41', null, '0', '1', '0', '79db86809bd4461da027183eb0f3c5b6', '0');
INSERT INTO `admin_user` VALUES ('184', 'oa000012', '0f97a6846bbacb0b2e118790c5d0ebf3', 'ef79b1', '34', '', null, 'oa000012', null, '', 'local', '2016-11-18 14:06:37', null, '0', '1', '0', '1fbb372227a74a6280e902c74c43d8fd', '0');
INSERT INTO `admin_user` VALUES ('185', 'oa000015', 'c1aef2667a9674df59a70ceb3cbc04ed', '1d7dd4', '35', '', null, 'oa000015', null, '', 'local', '2016-11-18 14:07:14', null, '0', '1', '0', '3fd068d975734f228cc33fe9a1aceb02', '0');
INSERT INTO `admin_user` VALUES ('186', 'oa000016', '945a27240f8dd9b3369d370e535af5e6', 'ddb98f', '36', '', null, 'oa000016', null, '', 'local', '2016-11-18 14:07:48', null, '0', '1', '0', '08e7f8600bab4a7fa40190973727e222', '0');
INSERT INTO `admin_user` VALUES ('187', 'oa000017', '8c15cb6d3480cb0be8f6e9339dda72ed', 'ad0400', '37', '', null, 'oa000017', null, '', 'local', '2016-11-18 14:08:24', null, '0', '1', '0', 'acfc415a28ba4970b0ee5cb3737cb017', '0');
INSERT INTO `admin_user` VALUES ('188', 'oa000018', 'cb1b2d921ad75e9d7aa593adec7e0980', 'f28a75', '38', '', null, 'oa000018', null, '', 'local', '2016-11-18 14:08:50', null, '0', '1', '0', '4843f3763bb24bf2b3934a2c5d5f3947', '0');
INSERT INTO `admin_user` VALUES ('189', 'oa000019', '50c08914ff9357f8f203119658db4201', '729413', '39', '', null, 'oa000019', null, '', 'local', '2016-11-18 14:09:25', null, '0', '1', '0', 'ce73e79f8d604221b9ba0a54fea6651a', '0');
INSERT INTO `admin_user` VALUES ('190', 'oa000020', '8d8cb59285d54c296c0386ee0b2f5fb8', 'f628e5', '40', '', null, 'oa000020', null, '', 'local', '2016-11-18 14:09:48', null, '0', '1', '0', 'b516e04b179c49b2bea644811be88cb4', '0');
INSERT INTO `admin_user` VALUES ('191', 'oa000021', '821d5a1e412ffd56902c3151f21455d2', 'dda87b', '41', '', null, 'oa000021', null, '', 'local', '2016-11-18 14:10:20', null, '0', '1', '0', '3e62be6f82004a8f8ebae3c961f7e9e7', '0');
INSERT INTO `admin_user` VALUES ('192', 'oa000022', 'de7893eb18f41acc71130fd96e9673ed', '921821', '42', '', null, 'oa000022', null, '', 'local', '2016-11-18 14:10:50', null, '0', '1', '0', 'fead6e13bebc4f7483cfbdb11ccff8ae', '0');
INSERT INTO `admin_user` VALUES ('193', 'oa000023', 'd1bd57066f5acae53930fd3062048d96', '9946e0', '43', '', null, 'oa000023', null, '', 'local', '2016-11-18 14:11:18', null, '0', '1', '0', 'f872d1ba7f254653ad49cb515deb7f66', '0');
INSERT INTO `admin_user` VALUES ('194', 'oa000025', '179bcf16296fa0b2a8f6062f0c3a7230', 'b3d5ee', '45', '', null, 'oa000025', null, '', 'local', '2016-11-18 14:11:48', null, '0', '1', '0', '0d4bf615da884b9a9df0c9aa9e0b2f97', '0');
INSERT INTO `admin_user` VALUES ('195', 'oa000026', 'c06dd34820bc7e3ff945677cb29acab4', '157efe', '46', '', null, 'oa000026', null, '', 'local', '2016-11-18 14:12:14', null, '0', '1', '0', '473b4d3bee154b149a6b4f6fa67ba2ad', '0');
INSERT INTO `admin_user` VALUES ('196', 'oa000027', '0a2cd137ad37b28eb494f7a3c12acc64', '9604d9', '47', '', null, 'oa000027', null, '', 'local', '2016-11-18 14:12:42', null, '0', '1', '0', '7e6305b0d5a64c2d90b90f71407abbf7', '0');
INSERT INTO `admin_user` VALUES ('197', 'oa000028', 'e6f913ef13f175f752c2767ae8aa05ea', 'ef18dc', '48', '', null, 'oa000028', null, '', 'local', '2016-11-18 14:13:07', null, '0', '1', '0', '9a0655e37f3240a589c165ac9a2ea56b', '0');
INSERT INTO `admin_user` VALUES ('198', 'oa000029', 'e4fd35bd897b82f2cf140515a5340532', '4db7e6', '49', '', null, 'oa000029', null, '', 'local', '2016-11-18 14:13:31', null, '0', '1', '0', 'b1308dcf154c45829953def2a9e70780', '0');
INSERT INTO `admin_user` VALUES ('199', 'oa000030', '9436c52c4725ed87c76af1cddc974a97', '95daaa', '50', '', null, 'oa000030', null, '', 'local', '2016-11-18 14:13:58', null, '0', '1', '0', '208ed827016b4582b312030da09d91d9', '0');
INSERT INTO `admin_user` VALUES ('200', 'oa000031', 'f7ddad9d451d9a4c75054a8ec7c34c95', 'c00256', '51', '', null, 'oa000031', null, '', 'local', '2016-11-18 14:14:24', null, '0', '1', '0', 'dba8fb9c54b24ef98e879d25f39676b0', '0');
INSERT INTO `admin_user` VALUES ('201', 'oa000032', '0c51b8b4b95a24b880ae57ccc73ae91d', '9237ba', '52', '', null, 'oa000032', null, '', 'local', '2016-11-18 14:14:49', null, '0', '1', '0', '51433f8a9f2f4be2a30938cbba99a3d1', '0');
INSERT INTO `admin_user` VALUES ('202', 'oa000033', '743c6d81777abe449a7b3a2642751b01', 'e5b793', '53', '', null, 'oa000033', null, '', 'local', '2016-11-18 14:15:10', null, '0', '1', '0', '74220938ec8148088f494a31cd738483', '0');
INSERT INTO `admin_user` VALUES ('203', 'db000035', '95b4c7df2e3345ff8b325d60c9efbdad', 'd320d8', '54', '', null, 'NO.35', null, '', 'local', '2016-11-19 00:42:00', null, '0', '1', '1', '0e1592a410ca47ccbf450508002d7ace', '0');
INSERT INTO `admin_user` VALUES ('204', 'oa000035', '8e7d8fcfadc4c367dc5c86c244ea0238', 'c59d38', '54', '', null, 'oa000035', null, '', 'local', '2016-11-19 00:42:28', null, '0', '1', '0', '44e4ef28a9d548399117aefa216b7d30', '0');
INSERT INTO `admin_user` VALUES ('205', 'db000036', '96f0ed6b803494b49eda2ba88a731e7a', '7d8edf', '55', '', null, 'NO.36', null, '', 'local', '2016-11-19 00:42:56', null, '0', '1', '1', '413a7715ddd141b29bff9b1f4356b732', '0');
INSERT INTO `admin_user` VALUES ('206', 'oa000036', '2fdc3129df05fd547c5825f738bca47f', '7c34f3', '55', '', null, 'oa000036', null, '', 'local', '2016-11-19 00:43:08', null, '0', '1', '0', '55efe6adaf62441399d2c0724ef9932b', '0');
INSERT INTO `admin_user` VALUES ('207', 'db000037', '693f2c1b7f5cd38db2946bb783bc308c', 'e3ec81', '56', '', null, 'NO.37', null, '', 'local', '2016-11-19 00:43:41', null, '0', '1', '0', '50dcbc171c7d4d1fba925e0c68b65c6a', '0');
INSERT INTO `admin_user` VALUES ('208', 'oa000037', '11bbd0014f8c584275935d7d63649921', '6ea68b', '56', '', null, 'oa000037', null, '', 'local', '2016-11-19 00:43:57', null, '0', '1', '0', '1ee93bc921a9406daf6c9bc89df3b7ee', '0');
INSERT INTO `admin_user` VALUES ('209', 'db0000378', 'ad655db8f12282fcf8a8e8427724778a', '9585a6', '57', '', null, 'NO.38', null, '', 'local', '2016-11-19 00:44:17', null, '0', '0', '0', '927e3e95a7da4a2fbb1ec8bfc2a5f1b6', '0');
INSERT INTO `admin_user` VALUES ('210', 'oa000038', '32ac19c2b60a395f356fb544746edde4', 'a76164', '57', '', null, 'oa000038', null, '', 'local', '2016-11-19 00:44:25', null, '0', '1', '0', 'c5fcc28ce80141609bae5182284735a9', '0');
INSERT INTO `admin_user` VALUES ('211', 'db000038', 'ed4c44a6a42c4a392844c80f708be4c7', '5a62b0', '57', '', null, 'NO.38', null, '', 'local', '2016-11-19 00:45:01', null, '0', '1', '0', 'bf16c03676a541c39c340d7218a6e66f', '0');
INSERT INTO `admin_user` VALUES ('212', 'oa000039', 'a07f5bf9f71c8cc1ae7675a2634e5477', '7bf872', '58', '', null, 'oa000039', null, '', 'local', '2016-11-19 00:45:29', null, '0', '1', '0', 'b765a32b93d740b3986a2ed0138895d3', '0');
INSERT INTO `admin_user` VALUES ('213', 'db000039', '322784ead0851c0a24a758c3fd8a1e1b', '4acdb9', '58', '', null, 'NO.39', null, '', 'local', '2016-11-19 00:45:47', null, '0', '1', '0', '9e8caeabee7b44958bedf4938a32d13c', '0');
INSERT INTO `admin_user` VALUES ('214', 'db000050', 'aa08083b36b5d5d9d3daa9eb7f6243fb', '266476', '59', '', null, 'NO.50', null, '', 'local', '2016-11-19 00:46:17', null, '0', '1', '0', '7170e5f52f6541f2864c2a06a332615e', '0');
INSERT INTO `admin_user` VALUES ('215', 'oa000050', 'd81cd91dd92be7521c07e84708d1ff17', '2f7f3e', '59', '', null, 'oa000050', null, '', 'local', '2016-11-19 00:46:27', null, '0', '1', '0', '47807f08e0894045a4871698a523f9f5', '0');
INSERT INTO `admin_user` VALUES ('216', 'db000051', '4ab08226fa56d5a89b21832e85f74fec', 'ea0c92', '60', '', null, 'NO.51', null, '', 'local', '2016-11-19 00:46:45', null, '0', '1', '0', '5464233294ca4e72846565262e0930d6', '0');
INSERT INTO `admin_user` VALUES ('217', 'oa000051', '60820865ce9cb6fd65f1bbe5c683c3da', '17998d', '60', '', null, 'oa000051', null, '', 'local', '2016-11-19 00:46:55', null, '0', '1', '0', 'efca002ea2034b03b1b4f04a5c3f326e', '0');
INSERT INTO `admin_user` VALUES ('218', 'db000052', 'e12fcaff554260c9ba2ed42b47998fbd', '472f26', '61', '', null, 'NO.52', null, '', 'local', '2016-11-19 00:47:33', null, '0', '1', '0', '9c4559ac56d54fafb5bb680f17914616', '0');
INSERT INTO `admin_user` VALUES ('219', 'oa000052', '414561aa648f1e6c7ab8e61542bd5c4e', '730eed', '61', '', null, 'oa000052', null, '', 'local', '2016-11-19 00:47:48', null, '0', '1', '0', 'b7bf135c08fe48e9a238df0c38a0a6a1', '0');
INSERT INTO `admin_user` VALUES ('220', 'db000053', 'e8124ee9184e643224ae8387a510493d', '11f7db', '62', '', null, 'NO.53', null, '', 'local', '2016-11-19 00:48:06', null, '0', '1', '0', '40fbb942a5434f1cb767ca9883429d96', '0');
INSERT INTO `admin_user` VALUES ('221', 'oa000053', 'dfc1c5439bc839bac3a508020467a8d2', '3b6717', '62', '', null, 'oa000053', null, '', 'local', '2016-11-19 00:48:17', null, '0', '1', '0', '031c5a0032cf405ba65d8560843284a7', '0');
INSERT INTO `admin_user` VALUES ('222', 'db000055', 'c6dd93aae4c4cde737c85e63510a5b8f', 'edc601', '63', '', null, 'NO.55', null, '', 'local', '2016-11-19 00:48:42', null, '0', '1', '0', '8e71d5ded479455f9b36d6de8c8319a9', '0');
INSERT INTO `admin_user` VALUES ('223', 'oa000055', '92534db942b15effe5ca89241816baeb', '702603', '63', '', null, 'oa000055', null, '', 'local', '2016-11-19 00:48:55', null, '0', '1', '0', '4169f61043494e47933fbd572e0726fb', '0');
INSERT INTO `admin_user` VALUES ('224', 'db000056', '42e21bd3305ef5f21ded84e929b5e092', '3c9505', '64', '', null, 'NO.56', null, '', 'local', '2016-11-19 00:49:16', null, '0', '1', '0', 'df7250e3cb1b476eb174045687ead476', '0');
INSERT INTO `admin_user` VALUES ('225', 'oa000056', 'b65a5ec81e960ec00eb6d370191344a1', '51f9a5', '64', '', null, 'oa000056', null, '', 'local', '2016-11-19 00:49:32', null, '0', '1', '0', 'f2e115b0bfdc4a58a1d9a4f8ae4b136e', '0');
INSERT INTO `admin_user` VALUES ('226', 'db000057', '72d4f91069954b4649c72e92875c48ea', '9987a8', '65', '', null, 'NO.57', null, '', 'local', '2016-11-19 00:49:51', null, '0', '1', '0', '79847a78c01744dd9ec10d4a1169566e', '0');
INSERT INTO `admin_user` VALUES ('227', 'oa000057', '575f89c19e71776b3a0b3d7a7c500f1b', '1f88b8', '65', '', null, 'oa000057', null, '', 'local', '2016-11-19 00:50:01', null, '0', '1', '0', '7146becac7774e7f9c2bd155a0bfe59f', '0');
INSERT INTO `admin_user` VALUES ('228', 'db000058', '0145adf88fa1ccf7a4e3f691ecbb21f5', '27004d', '66', '', null, 'NO.58', null, '', 'local', '2016-11-19 00:51:00', null, '0', '1', '0', '8584856f6efd479481babc5135fff4b7', '0');
INSERT INTO `admin_user` VALUES ('229', 'oa000058', 'd23b59c7dc77e1d8bf96e2a03cd82256', 'fe87ab', '66', '', null, 'oa000058', null, '', 'local', '2016-11-19 00:51:10', null, '0', '1', '0', '13819c9204b5483896f8b39b4107880e', '0');
INSERT INTO `admin_user` VALUES ('230', 'db000059', 'da73ea0077a59c80f22a7a6ca107a68c', '1158b5', '67', '', null, 'NO.59', null, '', 'local', '2016-11-19 00:51:43', null, '0', '1', '0', '86c357f8022d4f48bd8b83556f3c866d', '0');
INSERT INTO `admin_user` VALUES ('231', 'oa000059', '7e0790173bcc6eb9b9d7561f2190852a', '274945', '67', '', null, 'oa000059', null, '', 'local', '2016-11-19 00:51:55', null, '0', '1', '0', 'f8c61d9d0e3e4e39b2322959946a875b', '0');
INSERT INTO `admin_user` VALUES ('232', 'db000060', 'ed90d66088b7806429e4e1138fa18def', '85c860', '68', '', null, 'NO.60', null, '', 'local', '2016-11-19 00:52:12', null, '0', '1', '0', '7444f8c640fa480c9290f2ebb043d6e1', '0');
INSERT INTO `admin_user` VALUES ('233', 'oa000060', '8433410f26a9834b823485da3d9cf380', '205320', '68', '', null, 'oa000060', null, '', 'local', '2016-11-19 00:52:22', null, '0', '1', '0', '9800fe29a1134fbe8d8512dec9d844e9', '0');
INSERT INTO `admin_user` VALUES ('234', 'db000061', 'c6ff82453fb8e8e3fcb3a32cb73e7466', '20183c', '69', '', null, 'NO.61', null, '', 'local', '2016-11-19 00:53:06', null, '0', '1', '0', '16c18fba2ea24d0283b1c2564e053639', '0');
INSERT INTO `admin_user` VALUES ('235', 'oa000061', 'f48ac5dfa0ed142ce97c6798e557bce1', 'dbc071', '69', '', null, 'oa000061', null, '', 'local', '2016-11-19 00:53:16', null, '0', '1', '0', '7e0601b3a2374947b52bfbf66cb5246e', '0');
INSERT INTO `admin_user` VALUES ('236', 'db000062', '27772848ccd0185ed358b32907be1027', '95638b', '70', '', null, 'NO.62', null, '', 'local', '2016-11-19 00:53:36', null, '0', '1', '0', '3a44c8c1431c430889b122d16f5849a8', '0');
INSERT INTO `admin_user` VALUES ('237', 'oa000062', 'ed7e4c6f0f5d2654582a4eb85e457797', 'c5c4fe', '70', '', null, 'oa000062', null, '', 'local', '2016-11-19 00:53:46', null, '0', '1', '0', '47e43e8a7e534f21a5ca5a03a603eaab', '0');
INSERT INTO `admin_user` VALUES ('238', 'db000063', '8ac2934989c8ed3120e4b616d44e0558', '32b7f2', '71', '', null, 'NO.63', null, '', 'local', '2016-11-19 00:54:02', null, '0', '1', '0', '77ef8453c17a4fc5b25af43ba55324fa', '0');
INSERT INTO `admin_user` VALUES ('239', 'oa000063', '927ff02b7df243b71984d8fbf2ed1231', 'c36255', '71', '', null, 'oa000063', null, '', 'local', '2016-11-19 00:54:15', null, '0', '1', '0', 'bb63cf3744da4c33a614c7b9ae888436', '0');
INSERT INTO `admin_user` VALUES ('240', 'db000065', '21858cd2654373eb218b3e924058024d', '97e42e', '72', '', null, 'NO.65', null, '', 'local', '2016-11-19 00:54:31', null, '0', '1', '0', 'ed6538ea19504613b0673e866485426a', '0');
INSERT INTO `admin_user` VALUES ('241', 'oa000065', '2d2c3a805b4ed5f655cb90489701d269', '20b0d3', '72', '', null, 'oa000065', null, '', 'local', '2016-11-19 00:54:39', null, '0', '1', '0', '205b9cb4575349a7b7499ca153cdb555', '0');
INSERT INTO `admin_user` VALUES ('242', 'db000066', 'e9c58029b978cf24248e598739ad05a7', '9c44ac', '73', '', null, 'NO.66', null, '', 'local', '2016-11-19 00:55:36', null, '0', '1', '0', '5352d84c657c4e41949dc890b252a7fe', '0');
INSERT INTO `admin_user` VALUES ('243', 'oa000066', '7f601d208953b8cd20652cf4493b2ff9', '597603', '73', '', null, 'oa000066', null, '', 'local', '2016-11-19 00:55:48', null, '0', '1', '0', '7f648252692a48ef91bc5d042e236182', '0');
INSERT INTO `admin_user` VALUES ('244', 'db000067', 'ae9559939fb2fb589ab205e89c97b1bd', 'd32a70', '74', '', null, 'NO.67', null, '', 'local', '2016-11-19 00:56:06', null, '0', '1', '0', '43010477eea14551979b67a505c15543', '0');
INSERT INTO `admin_user` VALUES ('245', 'oa000067', '74e9804b7a4b2949c98e5431acbd439c', 'da18f7', '74', '', null, 'oa000067', null, '', 'local', '2016-11-19 00:56:16', null, '0', '1', '0', 'da0aa613d889421cbfaa073d6e96f9fa', '0');
INSERT INTO `admin_user` VALUES ('246', 'db000068', '7ae9b34fbb45426e39eca140260cb7ce', 'd72265', '75', '', null, 'NO.68', null, '', 'local', '2016-11-19 00:56:39', null, '0', '1', '0', '4000728683584762b2a7acb6bfff1485', '0');
INSERT INTO `admin_user` VALUES ('247', 'oa000068', 'a93282229c7ac941870395063871645a', 'cff672', '75', '', null, 'oa000068', null, '', 'local', '2016-11-19 00:56:52', null, '0', '1', '0', '553888a46eca4f42b567570ec9373c87', '0');
INSERT INTO `admin_user` VALUES ('248', 'db000069', '2d507176e88acc732098fcb1835e615e', '67bff1', '76', '', null, 'NO.69', null, '', 'local', '2016-11-19 00:57:09', null, '0', '1', '0', '1a65cc51b98346e2bb2f4b446533c273', '0');
INSERT INTO `admin_user` VALUES ('249', 'oa000069', '51057d33c759cc35f4b8e700c898993a', '401748', '76', '', null, 'oa000069', null, '', 'local', '2016-11-19 00:57:20', null, '0', '1', '0', '136d737294ec47b5a2e58be3df71350f', '0');
INSERT INTO `admin_user` VALUES ('250', 'db000070', '2eb7ad45aa21c2284e2f37a0ee8a882f', 'a18b83', '77', '', null, 'NO.70', null, '', 'local', '2016-11-19 00:57:53', null, '0', '1', '0', '51381c0295c24922b5920c2b8408d55e', '0');
INSERT INTO `admin_user` VALUES ('251', 'oa000070', 'a1d7bba4d94d791ba497cb007a0da19f', 'c9f50c', '77', '', null, 'oa000070', null, '', 'local', '2016-11-19 00:58:05', null, '0', '1', '0', '58859d5d91a449ffbddc598e7d563451', '0');
INSERT INTO `admin_user` VALUES ('252', 'db000071', 'e1e6882ee6ab0797a3f1f696dce35eca', '202c0b', '78', '', null, 'NO.71', null, '', 'local', '2016-11-19 00:58:38', null, '0', '1', '0', 'cdf751744b014fb5a329222348bcefa7', '0');
INSERT INTO `admin_user` VALUES ('253', 'oa000071', '8512c8fd1994e7b8fffb38f41ea1678a', '95656e', '78', '', null, 'oa000071', null, '', 'local', '2016-11-19 00:58:53', null, '0', '1', '0', '41894dc6d9d24ce6a02f2b068a8121a1', '0');
INSERT INTO `admin_user` VALUES ('254', 'db000072', '1bae87dc98b23c431c672867a6e7b52d', 'e0e774', '79', '', null, 'NO.72', null, '', 'local', '2016-11-19 00:59:08', null, '0', '1', '0', '9b0ef74e16b2402ead3e8388b2418d3c', '0');
INSERT INTO `admin_user` VALUES ('255', 'oa000072', '84ed4a839925a13e8c063536af59e107', 'dd0b01', '79', '', null, 'oa000072', null, '', 'local', '2016-11-19 00:59:19', null, '0', '1', '0', 'b7952cf8cbc14895a9a6f7d009d832a5', '0');
INSERT INTO `admin_user` VALUES ('256', 'db000073', '5b69c2e4f04e963960d580660eb101b7', 'bbc1af', '80', '', null, 'NO.73', null, '', 'local', '2016-11-19 00:59:35', null, '0', '1', '0', '73dd2e476237455d8328f512ba350dbf', '0');
INSERT INTO `admin_user` VALUES ('257', 'oa000073', 'eca38d3d90794adb0bc154f90e877712', 'ca771c', '80', '', null, 'oa000073', null, '', 'local', '2016-11-19 00:59:46', null, '0', '1', '0', '178de0c90f974d8b932fe5f514d09b70', '0');
INSERT INTO `admin_user` VALUES ('258', 'db000075', '8f1cf96ba11552d9f72f9045325bc0c1', 'bb6f5e', '81', '', null, 'NO.75', null, '', 'local', '2016-11-19 01:00:10', null, '0', '1', '0', '56c2e8f4baba429e800d0e3a330392b9', '0');
INSERT INTO `admin_user` VALUES ('259', 'oa000075', '03ab3711b740552c6b335dffa22a975a', '18324f', '81', '', null, 'oa000075', null, '', 'local', '2016-11-19 01:00:24', null, '0', '1', '0', '6c3ab2eb98254a3c83fc59192867ebf0', '0');
INSERT INTO `admin_user` VALUES ('260', 'db000076', '5407a3e12eabd36cfbc0acc23f87de41', 'a809b8', '82', '', null, 'NO.76', null, '', 'local', '2016-11-19 01:00:42', null, '0', '1', '0', '9f8ba935d53a4fb883dc61c4be02583d', '0');
INSERT INTO `admin_user` VALUES ('261', 'oa000076', '802c8d59cd1f3bb29945464ef36e3d41', '06ef12', '82', '', null, 'oa000076', null, '', 'local', '2016-11-19 01:00:52', null, '0', '1', '0', '495ce605a00f4750afb0f6301ed65ab9', '0');
INSERT INTO `admin_user` VALUES ('262', 'db000077', 'db60f479d6b4c501cc88cc28e665cd8f', 'd16639', '83', '', null, 'NO.77', null, '', 'local', '2016-11-19 01:01:12', null, '0', '1', '0', 'fae30ec6a16045d68f76625c4efc3f0f', '0');
INSERT INTO `admin_user` VALUES ('263', 'oa000077', 'ba6814abe86e23dc7d5bd4422bbc7ec3', 'ae8965', '83', '', null, 'oa000077', null, '', 'local', '2016-11-19 01:01:23', null, '0', '1', '0', '814ff5cd3cc149cc93c2f86a970a013c', '0');
INSERT INTO `admin_user` VALUES ('264', 'db000078', '0494f97a76059f0c0d24ade8a8b4b116', 'c747f2', '84', '', null, 'NO.78', null, '', 'local', '2016-11-19 01:01:41', null, '0', '1', '0', '419f51e84d7a4be084111c557593e6ad', '0');
INSERT INTO `admin_user` VALUES ('265', 'oa000078', '3ed2cfd225faae0fb1903e2f573b267b', '2fa62d', '84', '', null, 'oa000078', null, '', 'local', '2016-11-19 01:01:53', null, '0', '1', '0', '0178dd6da75a47cbb4c1171b5334a311', '0');
INSERT INTO `admin_user` VALUES ('266', 'db000079', '6e6df635d4332a7904b248498e59bf05', 'd58670', '85', '', null, 'NO.79', null, '', 'local', '2016-11-19 01:02:08', null, '0', '1', '0', '1dcda8a2fef94b4baebc4bf0431508ba', '0');
INSERT INTO `admin_user` VALUES ('267', 'oa000079', '6b8239b50320a4572f9565a7d1f47c81', '60b291', '85', '', null, 'oa000079', null, '', 'local', '2016-11-19 01:02:19', null, '0', '1', '0', '121462e152ed4da19137bdf980c78e95', '0');
INSERT INTO `admin_user` VALUES ('268', 'sy000035', '1a30ca762a3db68f7382b17950ea0849', 'c86841', '54', '', '收银员NO.35', '', null, '', 'local', '2016-11-24 17:11:24', null, '1', '1', '0', 'e13471c2bb50467994ef446025346012', '0');
INSERT INTO `admin_user` VALUES ('269', 'touzi123', 'bae05e0ee79de5258644e2ab30f5fa27', 'bd7b3a', '0', '', '', '', '1', '', 'local', '2016-12-13 16:17:00', '2017-01-03 15:37:37', '0', '1', '1', null, '0');
INSERT INTO `admin_user` VALUES ('270', 'sy000036', '5c077b93a364853837a78a26b2e5e8c4', '14ff82', '55', '', 'NO.36', '', null, '', 'local', '2017-01-03 15:24:28', null, '1', '1', '0', 'a69acb2e5448426a84fd09f2494a9a55', '0');
INSERT INTO `admin_user` VALUES ('271', 'test019', '1418f1932d5c059bbbf43e8925d4ffbb', 'b2fd2f', '86', '', null, '商户管理员', null, '', 'local', '2017-01-03 15:49:08', null, '0', '1', '1', 'ab81f6f0639543c49a0778b20dcb4f5f', '0');
INSERT INTO `admin_user` VALUES ('272', 'shouyin123', '6e469e02c597ff18ade1cb661c28dcbe', '45f466', '86', '', '收银123', '', null, '', 'local', '2017-01-03 16:03:20', null, '1', '1', '0', 'cbf421a33f144c8189fd975bf7ef6381', '0');

-- ----------------------------
-- Table structure for admin_user_group
-- ----------------------------
DROP TABLE IF EXISTS `admin_user_group`;
CREATE TABLE `admin_user_group` (
  `user_group_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户id',
  `group_id` int(11) NOT NULL DEFAULT '0' COMMENT '权限组id（角色id）',
  PRIMARY KEY (`user_group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=260 DEFAULT CHARSET=utf8 COMMENT='用户权限组表（用户角色表）';

-- ----------------------------
-- Records of admin_user_group
-- ----------------------------
INSERT INTO `admin_user_group` VALUES ('54', '21', '12');
INSERT INTO `admin_user_group` VALUES ('56', '29', '1');
INSERT INTO `admin_user_group` VALUES ('58', '30', '1');
INSERT INTO `admin_user_group` VALUES ('60', '1', '1');
INSERT INTO `admin_user_group` VALUES ('61', '31', '12');
INSERT INTO `admin_user_group` VALUES ('68', '40', '1');
INSERT INTO `admin_user_group` VALUES ('69', '33', '12');
INSERT INTO `admin_user_group` VALUES ('71', '43', '14');
INSERT INTO `admin_user_group` VALUES ('72', '44', '12');
INSERT INTO `admin_user_group` VALUES ('75', '46', '12');
INSERT INTO `admin_user_group` VALUES ('76', '47', '12');
INSERT INTO `admin_user_group` VALUES ('77', '45', '14');
INSERT INTO `admin_user_group` VALUES ('78', '48', '12');
INSERT INTO `admin_user_group` VALUES ('79', '51', '14');
INSERT INTO `admin_user_group` VALUES ('81', '52', '14');
INSERT INTO `admin_user_group` VALUES ('82', '53', '12');
INSERT INTO `admin_user_group` VALUES ('83', '54', '12');
INSERT INTO `admin_user_group` VALUES ('84', '55', '12');
INSERT INTO `admin_user_group` VALUES ('85', '56', '15');
INSERT INTO `admin_user_group` VALUES ('86', '57', '12');
INSERT INTO `admin_user_group` VALUES ('87', '71', '1');
INSERT INTO `admin_user_group` VALUES ('88', '72', '12');
INSERT INTO `admin_user_group` VALUES ('94', '76', '14');
INSERT INTO `admin_user_group` VALUES ('101', '77', '1');
INSERT INTO `admin_user_group` VALUES ('103', '78', '12');
INSERT INTO `admin_user_group` VALUES ('104', '74', '14');
INSERT INTO `admin_user_group` VALUES ('105', '75', '12');
INSERT INTO `admin_user_group` VALUES ('107', '79', '17');
INSERT INTO `admin_user_group` VALUES ('108', '80', '12');
INSERT INTO `admin_user_group` VALUES ('109', '81', '12');
INSERT INTO `admin_user_group` VALUES ('110', '82', '12');
INSERT INTO `admin_user_group` VALUES ('111', '83', '12');
INSERT INTO `admin_user_group` VALUES ('112', '84', '12');
INSERT INTO `admin_user_group` VALUES ('113', '85', '12');
INSERT INTO `admin_user_group` VALUES ('114', '86', '12');
INSERT INTO `admin_user_group` VALUES ('115', '87', '12');
INSERT INTO `admin_user_group` VALUES ('117', '89', '1');
INSERT INTO `admin_user_group` VALUES ('118', '90', '1');
INSERT INTO `admin_user_group` VALUES ('119', '91', '14');
INSERT INTO `admin_user_group` VALUES ('120', '92', '14');
INSERT INTO `admin_user_group` VALUES ('121', '93', '14');
INSERT INTO `admin_user_group` VALUES ('122', '94', '14');
INSERT INTO `admin_user_group` VALUES ('123', '95', '14');
INSERT INTO `admin_user_group` VALUES ('124', '96', '14');
INSERT INTO `admin_user_group` VALUES ('125', '97', '14');
INSERT INTO `admin_user_group` VALUES ('126', '98', '1');
INSERT INTO `admin_user_group` VALUES ('127', '100', '12');
INSERT INTO `admin_user_group` VALUES ('128', '102', '12');
INSERT INTO `admin_user_group` VALUES ('129', '103', '12');
INSERT INTO `admin_user_group` VALUES ('130', '109', '12');
INSERT INTO `admin_user_group` VALUES ('131', '110', '12');
INSERT INTO `admin_user_group` VALUES ('132', '111', '12');
INSERT INTO `admin_user_group` VALUES ('133', '115', '15');
INSERT INTO `admin_user_group` VALUES ('134', '118', '12');
INSERT INTO `admin_user_group` VALUES ('135', '119', '12');
INSERT INTO `admin_user_group` VALUES ('136', '120', '12');
INSERT INTO `admin_user_group` VALUES ('137', '123', '12');
INSERT INTO `admin_user_group` VALUES ('138', '125', '12');
INSERT INTO `admin_user_group` VALUES ('139', '126', '12');
INSERT INTO `admin_user_group` VALUES ('140', '127', '12');
INSERT INTO `admin_user_group` VALUES ('141', '128', '12');
INSERT INTO `admin_user_group` VALUES ('142', '133', '12');
INSERT INTO `admin_user_group` VALUES ('143', '134', '12');
INSERT INTO `admin_user_group` VALUES ('144', '135', '12');
INSERT INTO `admin_user_group` VALUES ('145', '136', '12');
INSERT INTO `admin_user_group` VALUES ('146', '137', '12');
INSERT INTO `admin_user_group` VALUES ('147', '138', '12');
INSERT INTO `admin_user_group` VALUES ('148', '139', '12');
INSERT INTO `admin_user_group` VALUES ('149', '140', '12');
INSERT INTO `admin_user_group` VALUES ('150', '149', '12');
INSERT INTO `admin_user_group` VALUES ('151', '150', '12');
INSERT INTO `admin_user_group` VALUES ('152', '151', '12');
INSERT INTO `admin_user_group` VALUES ('153', '152', '12');
INSERT INTO `admin_user_group` VALUES ('154', '153', '12');
INSERT INTO `admin_user_group` VALUES ('155', '154', '12');
INSERT INTO `admin_user_group` VALUES ('156', '155', '12');
INSERT INTO `admin_user_group` VALUES ('157', '156', '12');
INSERT INTO `admin_user_group` VALUES ('158', '157', '12');
INSERT INTO `admin_user_group` VALUES ('159', '158', '12');
INSERT INTO `admin_user_group` VALUES ('160', '159', '12');
INSERT INTO `admin_user_group` VALUES ('161', '160', '12');
INSERT INTO `admin_user_group` VALUES ('162', '173', '12');
INSERT INTO `admin_user_group` VALUES ('163', '174', '12');
INSERT INTO `admin_user_group` VALUES ('164', '175', '12');
INSERT INTO `admin_user_group` VALUES ('165', '176', '12');
INSERT INTO `admin_user_group` VALUES ('166', '177', '12');
INSERT INTO `admin_user_group` VALUES ('167', '178', '12');
INSERT INTO `admin_user_group` VALUES ('168', '179', '12');
INSERT INTO `admin_user_group` VALUES ('169', '180', '12');
INSERT INTO `admin_user_group` VALUES ('170', '181', '12');
INSERT INTO `admin_user_group` VALUES ('171', '182', '12');
INSERT INTO `admin_user_group` VALUES ('172', '183', '12');
INSERT INTO `admin_user_group` VALUES ('173', '184', '12');
INSERT INTO `admin_user_group` VALUES ('174', '185', '12');
INSERT INTO `admin_user_group` VALUES ('175', '186', '12');
INSERT INTO `admin_user_group` VALUES ('176', '187', '12');
INSERT INTO `admin_user_group` VALUES ('177', '188', '12');
INSERT INTO `admin_user_group` VALUES ('178', '189', '12');
INSERT INTO `admin_user_group` VALUES ('179', '190', '12');
INSERT INTO `admin_user_group` VALUES ('180', '191', '12');
INSERT INTO `admin_user_group` VALUES ('181', '192', '12');
INSERT INTO `admin_user_group` VALUES ('182', '193', '12');
INSERT INTO `admin_user_group` VALUES ('183', '194', '12');
INSERT INTO `admin_user_group` VALUES ('184', '195', '12');
INSERT INTO `admin_user_group` VALUES ('185', '196', '12');
INSERT INTO `admin_user_group` VALUES ('186', '197', '12');
INSERT INTO `admin_user_group` VALUES ('187', '198', '12');
INSERT INTO `admin_user_group` VALUES ('188', '199', '12');
INSERT INTO `admin_user_group` VALUES ('189', '200', '12');
INSERT INTO `admin_user_group` VALUES ('190', '201', '12');
INSERT INTO `admin_user_group` VALUES ('191', '202', '12');
INSERT INTO `admin_user_group` VALUES ('192', '203', '12');
INSERT INTO `admin_user_group` VALUES ('193', '204', '12');
INSERT INTO `admin_user_group` VALUES ('194', '205', '12');
INSERT INTO `admin_user_group` VALUES ('195', '206', '12');
INSERT INTO `admin_user_group` VALUES ('196', '207', '12');
INSERT INTO `admin_user_group` VALUES ('197', '208', '12');
INSERT INTO `admin_user_group` VALUES ('198', '209', '12');
INSERT INTO `admin_user_group` VALUES ('199', '210', '12');
INSERT INTO `admin_user_group` VALUES ('200', '211', '12');
INSERT INTO `admin_user_group` VALUES ('201', '212', '12');
INSERT INTO `admin_user_group` VALUES ('202', '213', '12');
INSERT INTO `admin_user_group` VALUES ('203', '214', '12');
INSERT INTO `admin_user_group` VALUES ('204', '215', '12');
INSERT INTO `admin_user_group` VALUES ('205', '216', '12');
INSERT INTO `admin_user_group` VALUES ('206', '217', '12');
INSERT INTO `admin_user_group` VALUES ('207', '218', '12');
INSERT INTO `admin_user_group` VALUES ('208', '219', '12');
INSERT INTO `admin_user_group` VALUES ('209', '220', '12');
INSERT INTO `admin_user_group` VALUES ('210', '221', '12');
INSERT INTO `admin_user_group` VALUES ('211', '222', '12');
INSERT INTO `admin_user_group` VALUES ('212', '223', '12');
INSERT INTO `admin_user_group` VALUES ('213', '224', '12');
INSERT INTO `admin_user_group` VALUES ('214', '225', '12');
INSERT INTO `admin_user_group` VALUES ('215', '226', '12');
INSERT INTO `admin_user_group` VALUES ('216', '227', '12');
INSERT INTO `admin_user_group` VALUES ('217', '228', '12');
INSERT INTO `admin_user_group` VALUES ('218', '229', '12');
INSERT INTO `admin_user_group` VALUES ('219', '230', '12');
INSERT INTO `admin_user_group` VALUES ('220', '231', '12');
INSERT INTO `admin_user_group` VALUES ('221', '232', '12');
INSERT INTO `admin_user_group` VALUES ('222', '233', '12');
INSERT INTO `admin_user_group` VALUES ('223', '234', '12');
INSERT INTO `admin_user_group` VALUES ('224', '235', '12');
INSERT INTO `admin_user_group` VALUES ('225', '236', '12');
INSERT INTO `admin_user_group` VALUES ('226', '237', '12');
INSERT INTO `admin_user_group` VALUES ('227', '238', '12');
INSERT INTO `admin_user_group` VALUES ('228', '239', '12');
INSERT INTO `admin_user_group` VALUES ('229', '240', '12');
INSERT INTO `admin_user_group` VALUES ('230', '241', '12');
INSERT INTO `admin_user_group` VALUES ('231', '242', '12');
INSERT INTO `admin_user_group` VALUES ('232', '243', '12');
INSERT INTO `admin_user_group` VALUES ('233', '244', '12');
INSERT INTO `admin_user_group` VALUES ('234', '245', '12');
INSERT INTO `admin_user_group` VALUES ('235', '246', '12');
INSERT INTO `admin_user_group` VALUES ('236', '247', '12');
INSERT INTO `admin_user_group` VALUES ('237', '248', '12');
INSERT INTO `admin_user_group` VALUES ('238', '249', '12');
INSERT INTO `admin_user_group` VALUES ('239', '250', '12');
INSERT INTO `admin_user_group` VALUES ('240', '251', '12');
INSERT INTO `admin_user_group` VALUES ('241', '252', '12');
INSERT INTO `admin_user_group` VALUES ('242', '253', '12');
INSERT INTO `admin_user_group` VALUES ('243', '254', '12');
INSERT INTO `admin_user_group` VALUES ('244', '255', '12');
INSERT INTO `admin_user_group` VALUES ('245', '256', '12');
INSERT INTO `admin_user_group` VALUES ('246', '257', '12');
INSERT INTO `admin_user_group` VALUES ('247', '258', '12');
INSERT INTO `admin_user_group` VALUES ('248', '259', '12');
INSERT INTO `admin_user_group` VALUES ('249', '260', '12');
INSERT INTO `admin_user_group` VALUES ('250', '261', '12');
INSERT INTO `admin_user_group` VALUES ('251', '262', '12');
INSERT INTO `admin_user_group` VALUES ('252', '263', '12');
INSERT INTO `admin_user_group` VALUES ('253', '264', '12');
INSERT INTO `admin_user_group` VALUES ('254', '265', '12');
INSERT INTO `admin_user_group` VALUES ('255', '266', '12');
INSERT INTO `admin_user_group` VALUES ('256', '267', '12');
INSERT INTO `admin_user_group` VALUES ('258', '269', '19');
INSERT INTO `admin_user_group` VALUES ('259', '271', '12');

-- ----------------------------
-- Table structure for business_advance
-- ----------------------------
DROP TABLE IF EXISTS `business_advance`;
CREATE TABLE `business_advance` (
  `businessadvanceid` int(11) NOT NULL AUTO_INCREMENT COMMENT '商户提现编码',
  `businessid` int(11) DEFAULT NULL COMMENT '商户编码',
  `balance` decimal(10,2) DEFAULT '0.00' COMMENT '帐户余额',
  `amount` decimal(10,2) DEFAULT '0.00' COMMENT '申请提现金额',
  `cashtype` int(2) DEFAULT '0' COMMENT '提现方式 0微信1支付宝2银联',
  `cashaccount` varchar(50) DEFAULT NULL COMMENT '提现账号（包括微信、支付宝、银行卡）',
  `cashbankname` varchar(110) DEFAULT NULL COMMENT '提现银行卡开户行',
  `cashname` varchar(50) DEFAULT NULL COMMENT '提现银行卡开户名',
  `state` tinyint(3) DEFAULT '0' COMMENT '状态 0审核中1同意2拒绝',
  `ctime` datetime DEFAULT NULL COMMENT '申请时间',
  PRIMARY KEY (`businessadvanceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商户提现表';

-- ----------------------------
-- Records of business_advance
-- ----------------------------

-- ----------------------------
-- Table structure for business_advance_setting
-- ----------------------------
DROP TABLE IF EXISTS `business_advance_setting`;
CREATE TABLE `business_advance_setting` (
  `advanceid` int(11) NOT NULL AUTO_INCREMENT COMMENT '提现设置主键',
  `businessid` int(11) DEFAULT NULL COMMENT '商户编码',
  `cashtype` int(2) DEFAULT '0' COMMENT '提现方式 0微信1支付宝2银联',
  `cashaccount` varchar(50) DEFAULT NULL COMMENT '提现账号（包括微信、支付宝、银行卡）',
  `cashbankname` varchar(110) DEFAULT NULL COMMENT '提现银行卡开户行',
  `cashname` varchar(50) DEFAULT NULL COMMENT '提现银行卡开户名',
  `state` tinyint(3) DEFAULT '0' COMMENT '是否默认 0否 1是',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`advanceid`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8 COMMENT='商户提现设置表';

-- ----------------------------
-- Records of business_advance_setting
-- ----------------------------

-- ----------------------------
-- Table structure for business_balance_detail
-- ----------------------------
DROP TABLE IF EXISTS `business_balance_detail`;
CREATE TABLE `business_balance_detail` (
  `businessdetailid` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `businessid` int(11) DEFAULT '0' COMMENT '商户编码（0为自营）',
  `kind` tinyint(3) DEFAULT '0' COMMENT '类型 0订单收入1提现',
  `orderid` varchar(30) DEFAULT NULL COMMENT '订单编码',
  `price` decimal(10,2) DEFAULT '0.00' COMMENT '金额',
  `balance` decimal(10,2) DEFAULT '0.00' COMMENT '帐户余额',
  `isrefund` tinyint(3) DEFAULT '0' COMMENT '是否退款 0否1是',
  `state` tinyint(3) DEFAULT '0' COMMENT '状态 0审核中1同意2拒绝',
  `reason` varchar(100) DEFAULT NULL COMMENT '拒绝原因',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  `cashtype` int(2) DEFAULT NULL COMMENT '提现方式 0微信1支付宝2银联',
  `cashaccount` varchar(50) DEFAULT NULL COMMENT '提现账号（包括微信、支付宝、银行卡）',
  `cashbankname` varchar(110) DEFAULT NULL COMMENT '提现银行卡开户行',
  `cashname` varchar(50) DEFAULT NULL COMMENT '提现银行卡开户名',
  PRIMARY KEY (`businessdetailid`)
) ENGINE=InnoDB AUTO_INCREMENT=18505 DEFAULT CHARSET=utf8 COMMENT='商户余额明细表';

-- ----------------------------
-- Records of business_balance_detail
-- ----------------------------

-- ----------------------------
-- Table structure for business_deposit_limit
-- ----------------------------
DROP TABLE IF EXISTS `business_deposit_limit`;
CREATE TABLE `business_deposit_limit` (
  `depositlimitid` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键编码',
  `down` decimal(10,2) DEFAULT '0.00' COMMENT '提现下限',
  `up` decimal(10,2) DEFAULT '0.00' COMMENT '提现上限',
  PRIMARY KEY (`depositlimitid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='商户提现上下限钱数表';

-- ----------------------------
-- Records of business_deposit_limit
-- ----------------------------

-- ----------------------------
-- Table structure for business_goods_audit
-- ----------------------------
DROP TABLE IF EXISTS `business_goods_audit`;
CREATE TABLE `business_goods_audit` (
  `businessgoodsauditid` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `businessid` int(11) DEFAULT NULL COMMENT '商户编码',
  `goodsid` int(11) DEFAULT NULL COMMENT '商品编码',
  `kind` tinyint(3) DEFAULT '0' COMMENT '审核类型 0上架1下架',
  `state` tinyint(3) DEFAULT '0' COMMENT '审核状态 0未审核1通过2拒绝',
  `reason` varchar(50) DEFAULT NULL COMMENT '拒绝原因',
  `adminid` int(11) DEFAULT NULL COMMENT '审核人',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  `issave` int(2) DEFAULT '0' COMMENT '是否保存(0否1是)',
  PRIMARY KEY (`businessgoodsauditid`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8 COMMENT='商户商品上下架审核表';

-- ----------------------------
-- Records of business_goods_audit
-- ----------------------------

-- ----------------------------
-- Table structure for business_info
-- ----------------------------
DROP TABLE IF EXISTS `business_info`;
CREATE TABLE `business_info` (
  `businessid` int(11) NOT NULL AUTO_INCREMENT COMMENT '商户编码',
  `businessname` varchar(50) DEFAULT NULL COMMENT '商户名称',
  `name` varchar(20) DEFAULT NULL COMMENT '联系人',
  `phone` varchar(16) DEFAULT NULL COMMENT '联系电话',
  `citycode` varchar(10) DEFAULT NULL COMMENT '市区划编码',
  `address` varchar(150) DEFAULT NULL COMMENT '商户地址',
  `balance` decimal(10,2) DEFAULT '0.00' COMMENT '帐户余额',
  `state` tinyint(3) DEFAULT '0' COMMENT '是否禁用 0否1是',
  `isapp` tinyint(3) DEFAULT '0' COMMENT '是否app端销售 0否1是',
  `discount` decimal(3,2) DEFAULT '0.00' COMMENT '扫码折扣',
  `limits` decimal(10,2) DEFAULT '0.00' COMMENT '扫码折扣上限',
  `rebate` decimal(10,2) DEFAULT '0.00' COMMENT '扫码给商家返利',
  `lng` decimal(10,6) DEFAULT '0.000000' COMMENT '坐标经度',
  `lat` decimal(10,6) DEFAULT '0.000000' COMMENT '坐标纬度',
  `logo` varchar(100) DEFAULT NULL COMMENT '商户logo',
  `license` varchar(100) DEFAULT NULL COMMENT '营业执照',
  `cashtype` tinyint(3) DEFAULT '0' COMMENT ' 提现方式 0微信1支付宝2银联',
  `cashaccount` varchar(50) DEFAULT NULL COMMENT '提现账号（包括微信、支付宝、银行卡）',
  `cashbankname` varchar(110) DEFAULT NULL COMMENT '提现银行卡开户行',
  `cashname` varchar(50) DEFAULT NULL COMMENT '提现银行卡开户名',
  `ishot` tinyint(3) DEFAULT '0' COMMENT '是否热门店铺 0否1是',
  `imgurl` varchar(100) DEFAULT NULL COMMENT '热门店铺图片url',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  `hotctime` datetime DEFAULT NULL COMMENT '热门商户时间',
  `benefit` decimal(10,2) DEFAULT NULL COMMENT '优惠折扣',
  `fullbenefit` decimal(10,2) DEFAULT NULL COMMENT '满多钱优惠',
  `minbenefit` decimal(10,2) DEFAULT '0.00' COMMENT '优惠折扣下限',
  `islimits` int(2) DEFAULT '0' COMMENT '是否扫码折扣优惠(0否1是)',
  PRIMARY KEY (`businessid`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8 COMMENT='商户表';

-- ----------------------------
-- Records of business_info
-- ----------------------------
INSERT INTO `business_info` VALUES ('86', '测试商户001', '测试商户', '15648790236', '2101', '辽宁省沈阳市沈河区市府大路260号', '0.00', '0', '1', '0.00', '0.00', '0.00', '123.438973', '41.811339', null, null, null, null, null, null, '0', null, '2017-01-03 15:48:27', null, '0.00', null, '0.00', '1');

-- ----------------------------
-- Table structure for category_info
-- ----------------------------
DROP TABLE IF EXISTS `category_info`;
CREATE TABLE `category_info` (
  `categoryid` int(11) NOT NULL AUTO_INCREMENT COMMENT '分类编码',
  `categoryname` varchar(10) DEFAULT NULL COMMENT '名称',
  `img` varchar(100) DEFAULT NULL COMMENT '图片',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`categoryid`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8 COMMENT='商品分类';

-- ----------------------------
-- Records of category_info
-- ----------------------------

-- ----------------------------
-- Table structure for customer_service
-- ----------------------------
DROP TABLE IF EXISTS `customer_service`;
CREATE TABLE `customer_service` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '客服联系方式主键',
  `contact` varchar(255) DEFAULT NULL COMMENT '联系方式',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='客服联系方式';

-- ----------------------------
-- Records of customer_service
-- ----------------------------

-- ----------------------------
-- Table structure for express_company
-- ----------------------------
DROP TABLE IF EXISTS `express_company`;
CREATE TABLE `express_company` (
  `expresscompanyid` int(11) NOT NULL AUTO_INCREMENT COMMENT '快递公司编码',
  `expresscompanyname` varchar(50) DEFAULT NULL COMMENT '快递公司名称',
  `state` tinyint(3) DEFAULT '0' COMMENT '是否禁用 0否1是',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`expresscompanyid`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='快递公司表';

-- ----------------------------
-- Records of express_company
-- ----------------------------

-- ----------------------------
-- Table structure for feedback_info
-- ----------------------------
DROP TABLE IF EXISTS `feedback_info`;
CREATE TABLE `feedback_info` (
  `feedbackid` int(11) NOT NULL AUTO_INCREMENT COMMENT '意见反馈编码',
  `userid` int(11) DEFAULT NULL COMMENT '用户编码',
  `content` varchar(100) DEFAULT NULL COMMENT '反馈内容',
  `isdel` tinyint(3) DEFAULT '0' COMMENT '是否删除 0否1是',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`feedbackid`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COMMENT='意见反馈';

-- ----------------------------
-- Records of feedback_info
-- ----------------------------

-- ----------------------------
-- Table structure for freight_county
-- ----------------------------
DROP TABLE IF EXISTS `freight_county`;
CREATE TABLE `freight_county` (
  `freightcountyid` int(11) NOT NULL AUTO_INCREMENT COMMENT '运费城市编码',
  `countyid` int(11) DEFAULT NULL COMMENT '区县编码',
  `freightid` int(11) DEFAULT NULL COMMENT '运费模板编码',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  `provinceid` int(11) DEFAULT NULL COMMENT '省编码',
  `freightpriceid` int(11) DEFAULT NULL COMMENT '运费配送省区域编码',
  PRIMARY KEY (`freightcountyid`)
) ENGINE=InnoDB AUTO_INCREMENT=193 DEFAULT CHARSET=utf8 COMMENT='运费模板城市表';

-- ----------------------------
-- Records of freight_county
-- ----------------------------

-- ----------------------------
-- Table structure for freight_info
-- ----------------------------
DROP TABLE IF EXISTS `freight_info`;
CREATE TABLE `freight_info` (
  `freightid` int(11) NOT NULL AUTO_INCREMENT COMMENT '运费模板id',
  `expresscompanyid` int(11) DEFAULT NULL COMMENT '快递公司编码',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  `businessid` int(11) DEFAULT '0' COMMENT '商户编码(平台为0)',
  `state` int(11) DEFAULT '1' COMMENT '是否禁用(0否1是)',
  PRIMARY KEY (`freightid`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COMMENT='运费模板表';

-- ----------------------------
-- Records of freight_info
-- ----------------------------

-- ----------------------------
-- Table structure for freight_price
-- ----------------------------
DROP TABLE IF EXISTS `freight_price`;
CREATE TABLE `freight_price` (
  `freightpriceid` int(11) NOT NULL AUTO_INCREMENT COMMENT '运费配送省区域编码',
  `freightid` int(11) DEFAULT NULL COMMENT '运费模板编码',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  `firstheavy` int(11) DEFAULT NULL COMMENT '首重',
  `firstprice` decimal(10,2) DEFAULT NULL COMMENT '首重运费',
  `continuedheavy` int(11) DEFAULT NULL COMMENT '续重',
  `continuedprice` decimal(10,2) DEFAULT NULL COMMENT '续重运费',
  `freecount` int(11) DEFAULT NULL COMMENT '满(件)包邮',
  `countprice` decimal(10,2) DEFAULT NULL COMMENT '按件运费(元)',
  `isfree` int(11) DEFAULT '0' COMMENT '1卖家承担运费0买家承担运费',
  `type` int(2) DEFAULT '2' COMMENT '计价方式(1件数2重量)',
  `isdefault` int(2) DEFAULT '0' COMMENT '是否标准(0否1是)',
  PRIMARY KEY (`freightpriceid`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8 COMMENT='运费模板价钱表';

-- ----------------------------
-- Records of freight_price
-- ----------------------------

-- ----------------------------
-- Table structure for goods_appraise
-- ----------------------------
DROP TABLE IF EXISTS `goods_appraise`;
CREATE TABLE `goods_appraise` (
  `appraiseid` int(11) NOT NULL AUTO_INCREMENT COMMENT '评论编码',
  `goodsid` int(11) DEFAULT NULL COMMENT '商品编码',
  `oid` int(11) DEFAULT NULL COMMENT '订单主键编码',
  `userid` int(11) DEFAULT NULL COMMENT '评论人编码',
  `star` tinyint(3) DEFAULT '1' COMMENT '星等级 1--5星',
  `content` varchar(60) DEFAULT NULL COMMENT '评论内容',
  `state` tinyint(3) NOT NULL DEFAULT '0' COMMENT '是否禁用 0否1是',
  `ctime` datetime DEFAULT NULL COMMENT '评论时间',
  PRIMARY KEY (`appraiseid`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COMMENT='商品评论表';

-- ----------------------------
-- Records of goods_appraise
-- ----------------------------

-- ----------------------------
-- Table structure for goods_info
-- ----------------------------
DROP TABLE IF EXISTS `goods_info`;
CREATE TABLE `goods_info` (
  `goodsid` int(11) NOT NULL AUTO_INCREMENT COMMENT '商品编码',
  `barcode` varchar(25) DEFAULT NULL COMMENT '商品条形码',
  `goodsname` varchar(200) DEFAULT NULL COMMENT '商品名称',
  `goodsnick` varchar(200) DEFAULT NULL COMMENT '商品别名',
  `platformgoodsid` int(11) DEFAULT NULL COMMENT '平台商品编码（商家商品为0）',
  `businessid` int(11) DEFAULT '0' COMMENT '商户编码（自营为0）',
  `categoryid` int(11) DEFAULT NULL COMMENT '分类编码',
  `costprice` decimal(10,2) DEFAULT '0.00' COMMENT '成本价',
  `price` decimal(10,2) DEFAULT '0.00' COMMENT '销售价',
  `onprice` decimal(10,2) DEFAULT '0.00' COMMENT '商户app端价格',
  `offprice` decimal(10,2) DEFAULT '0.00' COMMENT '商户线下价格',
  `cash` decimal(5,2) DEFAULT '0.00' COMMENT '分享返现百分比',
  `stand` varchar(50) DEFAULT NULL COMMENT '规格',
  `unit` varchar(20) DEFAULT NULL COMMENT '单位',
  `store` int(11) DEFAULT '0' COMMENT '库存',
  `weight` int(11) DEFAULT '0' COMMENT '重量（克）',
  `isapp` tinyint(3) DEFAULT '0' COMMENT '是否app端销售 0否1是',
  `imgurl` varchar(100) DEFAULT NULL COMMENT '图片路径',
  `describes` text COMMENT '描述',
  `sales` int(11) DEFAULT '0' COMMENT '销量',
  `moods` int(11) DEFAULT '0' COMMENT '人气',
  `businessgoodsauditid` int(11) NOT NULL DEFAULT '0' COMMENT '商品上下架审核表主键',
  `statistics` tinyint(3) DEFAULT '0' COMMENT '销售统计排前面  0否1是',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`goodsid`)
) ENGINE=InnoDB AUTO_INCREMENT=19568 DEFAULT CHARSET=utf8 COMMENT='商户商品表';

-- ----------------------------
-- Records of goods_info
-- ----------------------------

-- ----------------------------
-- Table structure for goods_info1
-- ----------------------------
DROP TABLE IF EXISTS `goods_info1`;
CREATE TABLE `goods_info1` (
  `goodsid` int(11) NOT NULL AUTO_INCREMENT COMMENT '商品编码',
  `barcode` varchar(20) DEFAULT NULL COMMENT '商品条形码',
  `goodsname` varchar(200) DEFAULT NULL COMMENT '商品名称',
  `goodsnick` varchar(200) DEFAULT NULL COMMENT '商品别名',
  `platformgoodsid` int(11) DEFAULT NULL COMMENT '平台商品编码（商家商品为0）',
  `businessid` int(11) DEFAULT '0' COMMENT '商户编码（自营为0）',
  `categoryid` int(11) DEFAULT NULL COMMENT '分类编码',
  `costprice` decimal(10,2) DEFAULT '0.00' COMMENT '成本价',
  `price` decimal(10,2) DEFAULT '0.00' COMMENT '销售价',
  `onprice` decimal(10,2) DEFAULT '0.00' COMMENT '商户app端价格',
  `offprice` decimal(10,2) DEFAULT '0.00' COMMENT '商户线下价格',
  `cash` decimal(5,2) DEFAULT '0.00' COMMENT '分享返现百分比',
  `stand` varchar(50) DEFAULT NULL COMMENT '规格',
  `unit` varchar(20) DEFAULT NULL COMMENT '单位',
  `store` int(11) DEFAULT '0' COMMENT '库存',
  `weight` int(11) DEFAULT '0' COMMENT '重量（克）',
  `isapp` tinyint(3) DEFAULT '0' COMMENT '是否app端销售 0否1是',
  `imgurl` varchar(100) DEFAULT NULL COMMENT '图片路径',
  `describes` text COMMENT '描述',
  `sales` int(11) DEFAULT '0' COMMENT '销量',
  `moods` int(11) DEFAULT '0' COMMENT '人气',
  `businessgoodsauditid` int(11) NOT NULL DEFAULT '0' COMMENT '商品上下架审核表主键',
  `statistics` tinyint(3) DEFAULT '0' COMMENT '销售统计排前面  0否1是',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`goodsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商户商品表';

-- ----------------------------
-- Records of goods_info1
-- ----------------------------

-- ----------------------------
-- Table structure for message_info
-- ----------------------------
DROP TABLE IF EXISTS `message_info`;
CREATE TABLE `message_info` (
  `messageid` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `content` varchar(2000) DEFAULT NULL,
  `ctime` datetime DEFAULT NULL,
  PRIMARY KEY (`messageid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of message_info
-- ----------------------------

-- ----------------------------
-- Table structure for order_address
-- ----------------------------
DROP TABLE IF EXISTS `order_address`;
CREATE TABLE `order_address` (
  `orderaddressid` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `oid` int(11) DEFAULT NULL COMMENT '订单主键编码',
  `isgive` tinyint(3) DEFAULT '0' COMMENT '是否赠送地址 0否1是',
  `name` varchar(20) DEFAULT NULL COMMENT '收货人姓名',
  `phone` varchar(16) DEFAULT NULL COMMENT '收货人电话',
  `provincename` varchar(50) DEFAULT NULL COMMENT '省名称',
  `cityname` varchar(50) DEFAULT NULL COMMENT '市名称',
  `countryname` varchar(50) DEFAULT NULL COMMENT '区县名称',
  `address` varchar(200) DEFAULT NULL COMMENT '详细地址',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`orderaddressid`)
) ENGINE=InnoDB AUTO_INCREMENT=330 DEFAULT CHARSET=utf8 COMMENT='订单收货地址表';

-- ----------------------------
-- Records of order_address
-- ----------------------------

-- ----------------------------
-- Table structure for order_busi_info
-- ----------------------------
DROP TABLE IF EXISTS `order_busi_info`;
CREATE TABLE `order_busi_info` (
  `orderbusiid` int(11) NOT NULL AUTO_INCREMENT COMMENT '店铺订单编码',
  `money` decimal(10,2) DEFAULT NULL COMMENT '实际支付金额',
  `price` decimal(10,2) DEFAULT NULL COMMENT '支付金额',
  `benefit` decimal(10,2) DEFAULT '0.00' COMMENT '优惠金额',
  `state` int(2) DEFAULT '0' COMMENT '订单状态(0未付款1已付款)',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  `businessid` int(11) DEFAULT NULL COMMENT '店铺编码',
  `userid` int(11) DEFAULT NULL COMMENT '用户编码',
  PRIMARY KEY (`orderbusiid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='店铺订单表';

-- ----------------------------
-- Records of order_busi_info
-- ----------------------------

-- ----------------------------
-- Table structure for order_goods
-- ----------------------------
DROP TABLE IF EXISTS `order_goods`;
CREATE TABLE `order_goods` (
  `ordergoodsid` int(11) NOT NULL AUTO_INCREMENT COMMENT '订单商品编码',
  `oid` int(11) DEFAULT NULL COMMENT '订单主键编码',
  `goodsid` int(11) DEFAULT NULL COMMENT '商品编码',
  `barcode` varchar(20) DEFAULT NULL COMMENT '商品条形码',
  `goodsname` varchar(200) DEFAULT NULL COMMENT '商品名称',
  `categoryname` varchar(10) DEFAULT NULL COMMENT '分类名称',
  `costprice` decimal(10,2) DEFAULT '0.00' COMMENT '成本价',
  `price` decimal(10,2) DEFAULT '0.00' COMMENT '销售价',
  `onprice` decimal(10,2) DEFAULT '0.00' COMMENT '商户app端价格',
  `offprice` decimal(10,2) DEFAULT '0.00' COMMENT '商户线下价格',
  `stand` varchar(50) DEFAULT NULL COMMENT '规格',
  `unit` varchar(20) DEFAULT NULL COMMENT '单位',
  `weight` int(11) DEFAULT '0' COMMENT '重量（克）',
  `cash` decimal(3,2) DEFAULT '0.00' COMMENT '返现百分比',
  `num` int(11) DEFAULT '0' COMMENT '购买数量',
  `imgurl` varchar(100) DEFAULT NULL COMMENT '图片路径',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`ordergoodsid`)
) ENGINE=InnoDB AUTO_INCREMENT=52590 DEFAULT CHARSET=utf8 COMMENT='订单商品表';

-- ----------------------------
-- Records of order_goods
-- ----------------------------

-- ----------------------------
-- Table structure for order_goods_dk
-- ----------------------------
DROP TABLE IF EXISTS `order_goods_dk`;
CREATE TABLE `order_goods_dk` (
  `ordergoodsdkid` int(11) NOT NULL AUTO_INCREMENT COMMENT '刷单订单商品编码',
  `orderid` varchar(40) DEFAULT NULL COMMENT '订单编码',
  `goodsid` int(11) DEFAULT NULL COMMENT '商品编码',
  `barcode` varchar(20) DEFAULT NULL COMMENT '商品条形码',
  `goodsname` varchar(200) DEFAULT NULL COMMENT '商品名称',
  `categoryname` varchar(100) DEFAULT NULL COMMENT '分类名称',
  `costprice` decimal(10,2) DEFAULT '0.00' COMMENT '成本价',
  `price` decimal(10,2) DEFAULT '0.00' COMMENT '销售价',
  `onprice` decimal(10,2) DEFAULT '0.00' COMMENT '商户app端价格',
  `offprice` decimal(10,2) DEFAULT '0.00' COMMENT '商户线下价格',
  `stand` varchar(50) DEFAULT NULL COMMENT '规格',
  `unit` varchar(20) DEFAULT NULL COMMENT '单位',
  `weight` int(11) DEFAULT '0' COMMENT '重量（克）',
  `cash` decimal(3,2) DEFAULT '0.00' COMMENT '返现百分比',
  `num` int(11) DEFAULT '0' COMMENT '购买数量',
  `imgurl` varchar(100) DEFAULT NULL COMMENT '图片路径',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`ordergoodsdkid`)
) ENGINE=InnoDB AUTO_INCREMENT=49800 DEFAULT CHARSET=utf8 COMMENT='订单商品刷单表';

-- ----------------------------
-- Records of order_goods_dk
-- ----------------------------

-- ----------------------------
-- Table structure for order_info
-- ----------------------------
DROP TABLE IF EXISTS `order_info`;
CREATE TABLE `order_info` (
  `oid` int(11) NOT NULL AUTO_INCREMENT COMMENT '订单主键编码',
  `orderid` varchar(30) DEFAULT NULL COMMENT '订单编码',
  `userid` int(11) DEFAULT NULL COMMENT '用户编码',
  `businessid` int(11) NOT NULL DEFAULT '0' COMMENT '商户编码（0为自营）',
  `state` tinyint(3) NOT NULL DEFAULT '0' COMMENT '订单状态 -1已取消0未付款1待发货2待收货3待评价4已完成5申请退款6退款完成',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '订单总价（含运费）',
  `payprice` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '支付价格',
  `balance` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '余额支付金额',
  `freight` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '运费',
  `returnprice` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '线下扫码支付补贴金额',
  `rebate` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '扫码给商家返利',
  `paykind` tinyint(3) NOT NULL DEFAULT '0' COMMENT '支付类型 1线上2扫码3现金4优惠付',
  `paytype` tinyint(3) NOT NULL DEFAULT '0' COMMENT '支付方式 1微信2支付宝3银联4余额支付',
  `refundreason` varchar(100) DEFAULT NULL COMMENT '退款原因',
  `isaddress` tinyint(3) DEFAULT '0' COMMENT '是否有收货人 0否1是',
  `shareid` int(11) DEFAULT NULL COMMENT '分享编码，通过分享帖子进行的购买，分享帖子的分享编码，与topic_info表关联',
  `shareoid` int(11) DEFAULT NULL COMMENT '分享购买所属订单主键编码',
  `discount` decimal(3,2) NOT NULL DEFAULT '0.00' COMMENT '扫码折扣，线下扫码及app扫码，购买者享有的折扣，对商家，此部分折扣由平台补给商家',
  `express` varchar(50) DEFAULT NULL COMMENT '快递公司名称',
  `isgive` tinyint(3) NOT NULL DEFAULT '0' COMMENT '是否赠送 0否1是',
  `isuserdk` int(1) NOT NULL DEFAULT '0' COMMENT '是否用户分享返利 0否 1是',
  `isdk` tinyint(3) NOT NULL DEFAULT '0' COMMENT '商户是否返完余额 0否 1是',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`oid`),
  UNIQUE KEY `orderid` (`orderid`)
) ENGINE=InnoDB AUTO_INCREMENT=28956 DEFAULT CHARSET=utf8 COMMENT='订单表';

-- ----------------------------
-- Records of order_info
-- ----------------------------

-- ----------------------------
-- Table structure for order_info_dk
-- ----------------------------
DROP TABLE IF EXISTS `order_info_dk`;
CREATE TABLE `order_info_dk` (
  `odkid` int(11) NOT NULL AUTO_INCREMENT COMMENT '订单主键刷单编码',
  `orderid` varchar(40) DEFAULT NULL COMMENT '订单编码',
  `userid` int(11) DEFAULT NULL COMMENT '用户编码',
  `username` varchar(50) DEFAULT NULL COMMENT '用户昵称',
  `phone` varchar(13) DEFAULT NULL COMMENT '用户电话',
  `businessid` int(11) NOT NULL DEFAULT '0' COMMENT '商户编码（0为自营）',
  `state` tinyint(3) NOT NULL DEFAULT '0' COMMENT '订单状态 -1已取消0未付款1待发货2待收货3待评价4已完成5申请退款6退款完成',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '订单总价（含运费）',
  `payprice` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '支付价格',
  `balance` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '余额支付金额',
  `freight` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '运费',
  `returnprice` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '线下扫码支付补贴金额',
  `rebate` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '扫码给商家返利',
  `paykind` tinyint(3) NOT NULL DEFAULT '0' COMMENT '支付类型 1指定商家2现金3优惠付',
  `paytype` tinyint(3) NOT NULL DEFAULT '0' COMMENT '支付方式 1微信2支付宝3银联4余额支付',
  `refundreason` varchar(100) DEFAULT NULL COMMENT '退款原因',
  `discount` decimal(3,2) NOT NULL DEFAULT '0.00' COMMENT '扫码折扣',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`odkid`),
  UNIQUE KEY `orderid` (`orderid`)
) ENGINE=InnoDB AUTO_INCREMENT=26633 DEFAULT CHARSET=utf8 COMMENT='订单刷单表';

-- ----------------------------
-- Records of order_info_dk
-- ----------------------------

-- ----------------------------
-- Table structure for order_info_oid
-- ----------------------------
DROP TABLE IF EXISTS `order_info_oid`;
CREATE TABLE `order_info_oid` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `orderid` varchar(40) DEFAULT NULL COMMENT '总订单编码',
  `oid` int(11) DEFAULT NULL COMMENT '关联订单主键编码',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '订单总价',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=322 DEFAULT CHARSET=utf8 COMMENT='商户订单与拆单关系表';

-- ----------------------------
-- Records of order_info_oid
-- ----------------------------

-- ----------------------------
-- Table structure for platform_advance_setting
-- ----------------------------
DROP TABLE IF EXISTS `platform_advance_setting`;
CREATE TABLE `platform_advance_setting` (
  `advanceid` int(11) NOT NULL AUTO_INCREMENT COMMENT '提现设置主键',
  `cashtype` int(2) DEFAULT '0' COMMENT '提现方式 0微信1支付宝2银联',
  `cashaccount` varchar(50) DEFAULT NULL COMMENT '提现账号（包括微信、支付宝、银行卡）',
  `cashbankname` varchar(110) DEFAULT NULL COMMENT '提现银行卡开户行',
  `cashname` varchar(50) DEFAULT NULL COMMENT '提现银行卡开户名',
  `state` tinyint(3) DEFAULT '0' COMMENT '是否默认 0否 1是',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`advanceid`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8 COMMENT='平台提现设置表';

-- ----------------------------
-- Records of platform_advance_setting
-- ----------------------------

-- ----------------------------
-- Table structure for platform_balance_detail
-- ----------------------------
DROP TABLE IF EXISTS `platform_balance_detail`;
CREATE TABLE `platform_balance_detail` (
  `businessdetailid` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `kind` tinyint(3) DEFAULT '0' COMMENT '类型 0订单收入1提现',
  `orderid` varchar(30) DEFAULT NULL COMMENT '订单编码',
  `price` decimal(10,2) DEFAULT '0.00' COMMENT '金额',
  `balance` decimal(10,2) DEFAULT '0.00' COMMENT '帐户余额',
  `isrefund` tinyint(3) DEFAULT '0' COMMENT '是否退款 0否1是',
  `state` tinyint(3) DEFAULT '0' COMMENT '状态 0审核中1同意2拒绝',
  `reason` varchar(100) DEFAULT NULL COMMENT '拒绝原因',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  `cashtype` int(2) DEFAULT NULL COMMENT '提现方式 0微信1支付宝2银联',
  `cashaccount` varchar(50) DEFAULT NULL COMMENT '提现账号（包括微信、支付宝、银行卡）',
  `cashbankname` varchar(110) DEFAULT NULL COMMENT '提现银行卡开户行',
  `cashname` varchar(50) DEFAULT NULL COMMENT '提现银行卡开户名',
  PRIMARY KEY (`businessdetailid`)
) ENGINE=InnoDB AUTO_INCREMENT=17563 DEFAULT CHARSET=utf8 COMMENT='平台余额明细表';

-- ----------------------------
-- Records of platform_balance_detail
-- ----------------------------

-- ----------------------------
-- Table structure for platform_deposit_limit
-- ----------------------------
DROP TABLE IF EXISTS `platform_deposit_limit`;
CREATE TABLE `platform_deposit_limit` (
  `depositlimitid` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键编码',
  `down` decimal(10,2) DEFAULT '0.00' COMMENT '提现下限',
  `up` decimal(10,2) DEFAULT '0.00' COMMENT '提现上限',
  PRIMARY KEY (`depositlimitid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='平台提现上下限钱数表';

-- ----------------------------
-- Records of platform_deposit_limit
-- ----------------------------

-- ----------------------------
-- Table structure for platform_goods
-- ----------------------------
DROP TABLE IF EXISTS `platform_goods`;
CREATE TABLE `platform_goods` (
  `platformgoodsid` int(11) NOT NULL AUTO_INCREMENT COMMENT '商品编码',
  `barcode` varchar(100) DEFAULT NULL COMMENT '商品条形码',
  `goodsname` varchar(200) DEFAULT NULL COMMENT '商品名称',
  `categoryid` int(11) DEFAULT NULL COMMENT '分类编码',
  `costprice` decimal(10,2) DEFAULT '0.00' COMMENT '成本价',
  `price` decimal(10,2) DEFAULT '0.00' COMMENT '零售价',
  `state` tinyint(3) DEFAULT '0' COMMENT '是否禁用 0否1是',
  `stand` varchar(50) DEFAULT NULL COMMENT '规格',
  `unit` varchar(20) DEFAULT NULL COMMENT '单位',
  `store` int(11) DEFAULT '0' COMMENT '库存',
  `weight` int(11) DEFAULT '0' COMMENT '重量（克）',
  `imgurl` varchar(100) DEFAULT NULL COMMENT '图片路径',
  `describes` text COMMENT '描述',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`platformgoodsid`),
  UNIQUE KEY `barcode` (`barcode`)
) ENGINE=InnoDB AUTO_INCREMENT=3018367 DEFAULT CHARSET=utf8 COMMENT='平台商品表';

-- ----------------------------
-- Records of platform_goods
-- ----------------------------

-- ----------------------------
-- Table structure for system_frontend_menu
-- ----------------------------
DROP TABLE IF EXISTS `system_frontend_menu`;
CREATE TABLE `system_frontend_menu` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `pid` int(6) NOT NULL DEFAULT '0',
  `hid` varchar(255) DEFAULT NULL COMMENT 'hierarchically category id',
  `menu` varchar(50) NOT NULL DEFAULT '',
  `link_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '链接方式。1：内部链接；2：外部链接；',
  `appkey` varchar(100) DEFAULT NULL,
  `folder` varchar(100) DEFAULT NULL COMMENT '内部链接地址',
  `url` varchar(200) DEFAULT NULL COMMENT '外部链接地址',
  `if_show` int(1) NOT NULL DEFAULT '0',
  `sort_order` int(11) DEFAULT '255',
  `target` varchar(10) DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL COMMENT '菜单 icon',
  `icon_bg` varchar(50) DEFAULT NULL COMMENT '菜单 icon 背景',
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='前台导航';

-- ----------------------------
-- Records of system_frontend_menu
-- ----------------------------

-- ----------------------------
-- Table structure for system_frontend_menu_group
-- ----------------------------
DROP TABLE IF EXISTS `system_frontend_menu_group`;
CREATE TABLE `system_frontend_menu_group` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL DEFAULT '',
  `sort_order` int(11) NOT NULL DEFAULT '255',
  `moveable` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否允许被删除。1：允许；0：不允许；',
  PRIMARY KEY (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='前台导航分组';

-- ----------------------------
-- Records of system_frontend_menu_group
-- ----------------------------
INSERT INTO `system_frontend_menu_group` VALUES ('1', '商户导航菜单', '1', '0');
INSERT INTO `system_frontend_menu_group` VALUES ('2', '会员导航菜单', '2', '0');

-- ----------------------------
-- Table structure for system_navigation
-- ----------------------------
DROP TABLE IF EXISTS `system_navigation`;
CREATE TABLE `system_navigation` (
  `navigation_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT '0' COMMENT 'parent navigation_id',
  `hid` varchar(255) DEFAULT NULL COMMENT 'hierarchically category id',
  `title` varchar(255) DEFAULT NULL COMMENT 'category title',
  `link` varchar(255) DEFAULT NULL,
  `load_type` tinyint(4) DEFAULT '1' COMMENT '加载方式。1：ajax 加载；2：iframe 加载；',
  `description` text,
  `icon` varchar(50) DEFAULT NULL COMMENT '导航 icon',
  `icon_bg` varchar(50) DEFAULT NULL COMMENT '导航 icon 背景',
  `sort_order` mediumint(5) DEFAULT '255' COMMENT '序号',
  `status` tinyint(4) DEFAULT '1' COMMENT '是否启用。1：是；0：否；',
  `ctime` datetime DEFAULT NULL,
  `mtime` datetime DEFAULT NULL,
  PRIMARY KEY (`navigation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=202 DEFAULT CHARSET=utf8 COMMENT='system navigation category';

-- ----------------------------
-- Records of system_navigation
-- ----------------------------
INSERT INTO `system_navigation` VALUES ('1', '0', '0:0001', '内容', '', '1', null, '', null, '0', '1', null, '2015-12-03 16:43:30');
INSERT INTO `system_navigation` VALUES ('29', '54', '0:0001:0054:0029', '平台用户管理', '/adminUser/index', '1', null, 'fa-user', null, '1', '1', null, '2015-12-04 16:42:01');
INSERT INTO `system_navigation` VALUES ('30', '54', '0:0001:0054:0030', '平台角色管理', '/adminUserGroup/index', '1', null, 'fa-sitemap', null, '2', '1', null, '2015-12-04 17:00:12');
INSERT INTO `system_navigation` VALUES ('54', '1', '0:0001:0054', '权限管理', '', '1', null, 'fa-gavel', 'bg-danger', '11', '1', '2014-07-25 11:38:37', '2014-11-10 01:12:07');
INSERT INTO `system_navigation` VALUES ('61', '69', '0:0001:0069:0061', '地区管理', '/trend/region', '1', null, 'fa-file-text', null, '1', '1', null, '2015-10-14 17:43:25');
INSERT INTO `system_navigation` VALUES ('69', '1', '0:0001:0069', '系统设置', '', '1', null, 'fa-gear', 'bg-info', '12', '1', '2014-11-10 01:09:54', '2014-11-10 01:13:10');
INSERT INTO `system_navigation` VALUES ('90', '69', '0:0001:0069:0090', '菜单管理', '/navigation/index', '1', null, 'fa-file-text', null, '3', '1', null, '2015-11-30 16:37:03');
INSERT INTO `system_navigation` VALUES ('106', '54', '0:0001:0054:0106', '权限数据管理', '/adminPermission/index', '1', null, 'fa-gavel', null, '4', '1', null, '2015-12-04 16:48:38');
INSERT INTO `system_navigation` VALUES ('123', '0', '0:0123', '商品管理', '', '1', null, 'fa-file-text', null, '255', '1', '2016-07-27 15:24:47', '2016-07-27 15:24:47');
INSERT INTO `system_navigation` VALUES ('124', '123', '0:0123:0124', '平台录入商品', '/platformGoods/index', '1', null, 'fa-file-text', null, '255', '1', null, '2016-07-27 15:52:08');
INSERT INTO `system_navigation` VALUES ('125', '123', '0:0123:0125', '自营商品管理', '/goodsInfo/index', '1', null, 'fa-file-text', null, '255', '1', null, '2016-07-29 16:10:04');
INSERT INTO `system_navigation` VALUES ('126', '123', '0:0123:0126', '商品分类管理', '/categoryInfo/index', '1', null, 'fa-file-text', null, '255', '1', '2016-07-28 13:44:27', '2016-07-28 13:44:27');
INSERT INTO `system_navigation` VALUES ('127', '0', '0:0127', '订单管理', '', '1', null, 'fa-file-text', null, '255', '1', '2016-07-28 15:02:14', '2016-07-28 15:02:14');
INSERT INTO `system_navigation` VALUES ('128', '127', '0:0127:0128', '订单列表', '/orderInfo/index', '1', null, 'fa-file-text', 'bg-danger', '255', '1', null, '2016-07-28 15:03:39');
INSERT INTO `system_navigation` VALUES ('129', '123', '0:0123:0129', '商品上架审核', '/businessGoodsAudit/index', '1', null, 'fa-file-text', null, '255', '1', '2016-07-29 08:54:45', '2016-07-29 08:54:45');
INSERT INTO `system_navigation` VALUES ('130', '123', '0:0123:0130', '商家下架审核', '/businessGoodsAudit/downindex', '1', null, 'fa-file-text', null, '255', '1', '2016-07-29 09:28:39', '2016-07-29 09:28:39');
INSERT INTO `system_navigation` VALUES ('132', '123', '0:0123:0132', '商家商品管理', '/goodsInfo/index', '1', null, 'fa-file-text', null, '255', '1', null, '2016-08-01 11:01:42');
INSERT INTO `system_navigation` VALUES ('133', '0', '0:0133', '商户管理', '', '1', null, 'fa-file-text', null, '255', '1', '2016-08-01 12:40:45', '2016-08-01 12:40:45');
INSERT INTO `system_navigation` VALUES ('134', '133', '0:0133:0134', '商户列表', '/businessInfo/index', '1', null, 'fa-file-text', null, '255', '1', '2016-08-01 12:41:17', '2016-08-01 12:41:17');
INSERT INTO `system_navigation` VALUES ('137', '123', '0:0123:0137', '商品评价', '/goodsAppraise/index', '1', null, 'fa-file-text', null, '255', '1', '2016-08-02 14:29:56', '2016-08-02 14:29:56');
INSERT INTO `system_navigation` VALUES ('138', '0', '0:0138', '订单汇总', '', '1', null, 'fa-file-text', null, '255', '1', '2016-08-02 14:45:29', '2016-08-02 14:45:29');
INSERT INTO `system_navigation` VALUES ('139', '138', '0:0138:0139', '订单汇总', '/collect/index', '1', null, 'fa-file-text', null, '255', '1', '2016-08-02 14:45:45', '2016-08-02 14:45:45');
INSERT INTO `system_navigation` VALUES ('140', '0', '0:0140', '收银机广告设置', '', '1', null, 'fa-file-text', null, '255', '1', null, '2016-08-03 09:39:08');
INSERT INTO `system_navigation` VALUES ('141', '140', '0:0140:0141', '收银机广告列表', '/adRadioInfo/index', '1', null, 'fa-file-text', null, '255', '1', null, '2016-08-03 09:39:18');
INSERT INTO `system_navigation` VALUES ('142', '0', '0:0142', '线上销售情况', '', '1', null, 'fa-file-text', null, '255', '1', null, '2016-09-26 09:29:54');
INSERT INTO `system_navigation` VALUES ('143', '142', '0:0142:0143', '线上销售统计', '/sales/index', '1', null, 'fa-file-text', null, '255', '1', null, '2016-09-26 09:29:42');
INSERT INTO `system_navigation` VALUES ('144', '140', '0:0140:0144', '二维码默认图片', '/adRadioInfo/findCodePage', '1', null, 'fa-file-text', null, '255', '1', null, '2016-09-12 15:43:33');
INSERT INTO `system_navigation` VALUES ('145', '127', '0:0127:0145', '商户订单列表', '/orderrefund/index', '1', null, 'fa-file-text', null, '255', '1', '2016-08-03 15:45:11', '2016-08-03 15:45:11');
INSERT INTO `system_navigation` VALUES ('149', '0', '0:0149', '热门商户管理', '', '1', null, 'fa-file-text', null, '255', '1', '2016-08-03 16:22:44', '2016-08-03 16:22:44');
INSERT INTO `system_navigation` VALUES ('150', '149', '0:0149:0150', '热门商户设置', '/businessInfo/hotindex', '1', null, 'fa-file-text', null, '255', '1', '2016-08-03 16:23:33', '2016-08-03 16:23:33');
INSERT INTO `system_navigation` VALUES ('151', '0', '0:0151', '用户管理', '', '1', null, 'fa-file-text', null, '13', '1', null, '2016-08-04 08:56:51');
INSERT INTO `system_navigation` VALUES ('152', '151', '0:0151:0152', '用户列表', '/userInfo/index', '1', null, 'fa-file-text', null, '255', '1', '2016-08-04 08:55:04', '2016-08-04 08:55:04');
INSERT INTO `system_navigation` VALUES ('153', '0', '0:0153', '热门活动设置', '', '1', null, 'fa-file-text', null, '255', '1', '2016-08-04 09:23:49', '2016-08-04 09:23:49');
INSERT INTO `system_navigation` VALUES ('154', '153', '0:0153:0154', '热门活动列表', '/activityInfo/index', '1', null, 'fa-file-text', null, '255', '1', '2016-08-04 09:24:11', '2016-08-04 09:24:11');
INSERT INTO `system_navigation` VALUES ('155', '0', '0:0155', '首页轮播图管理', '', '1', null, 'fa-file-text', null, '255', '1', '2016-08-04 14:19:03', '2016-08-04 14:19:03');
INSERT INTO `system_navigation` VALUES ('156', '155', '0:0155:0156', '轮播图列表', '/adInfo/index', '1', null, 'fa-file-text', null, '255', '1', '2016-08-04 14:19:24', '2016-08-04 14:19:24');
INSERT INTO `system_navigation` VALUES ('157', '0', '0:0157', '意见反馈管理', '', '1', null, 'fa-file-text', null, '255', '1', '2016-08-04 16:01:29', '2016-08-04 16:01:29');
INSERT INTO `system_navigation` VALUES ('158', '157', '0:0157:0158', '意见反馈', '/feedbackInfo/index', '1', null, 'fa-file-text', null, '255', '1', null, '2016-08-04 16:15:26');
INSERT INTO `system_navigation` VALUES ('159', '0', '0:0159', 'APP版本管理', '', '1', null, 'fa-file-text', null, '255', '1', '2016-08-04 16:47:23', '2016-08-04 16:47:23');
INSERT INTO `system_navigation` VALUES ('160', '159', '0:0159:0160', '版本管理', '/trendVersion/index', '1', null, 'fa-file-text', null, '255', '1', '2016-08-04 16:48:04', '2016-08-04 16:48:04');
INSERT INTO `system_navigation` VALUES ('161', '0', '0:0161', '快递公司设置', '', '1', null, 'fa-file-text', null, '255', '1', '2016-08-04 16:50:25', '2016-08-04 16:50:25');
INSERT INTO `system_navigation` VALUES ('162', '161', '0:0161:0162', '快递公司列表', '/expressCompany/index', '1', null, 'fa-file-text', null, '255', '1', '2016-08-04 16:50:49', '2016-08-04 16:50:49');
INSERT INTO `system_navigation` VALUES ('163', '0', '0:0163', '运费模板设置', '', '1', null, 'fa-file-text', null, '255', '1', '2016-08-05 10:46:07', '2016-08-05 10:46:07');
INSERT INTO `system_navigation` VALUES ('164', '163', '0:0163:0164', '运费模板列表', '/freightInfo/index', '1', null, 'fa-file-text', null, '255', '1', '2016-08-05 10:46:29', '2016-08-05 10:46:29');
INSERT INTO `system_navigation` VALUES ('165', '0', '0:0165', '提现设置', '', '1', null, 'fa-file-text', null, '255', '1', '2016-08-05 12:47:02', '2016-08-05 12:47:02');
INSERT INTO `system_navigation` VALUES ('167', '0', '0:0167', '基础信息', '', '1', null, 'fa-file-text', null, '255', '1', '2016-08-05 16:00:11', '2016-08-05 16:00:11');
INSERT INTO `system_navigation` VALUES ('168', '167', '0:0167:0168', '账户余额', '/businessBalanceDetail', '1', null, 'fa-file-text', null, '255', '1', '2016-08-05 16:00:24', '2016-08-05 16:00:24');
INSERT INTO `system_navigation` VALUES ('169', '0', '0:0169', '提现管理', '', '1', null, 'fa-file-text', null, '255', '1', '2016-08-06 11:33:01', '2016-08-06 11:33:01');
INSERT INTO `system_navigation` VALUES ('170', '169', '0:0169:0170', '商户提现列表', '/businessBalanceDetail', '1', null, 'fa-file-text', null, '255', '1', null, '2016-11-21 15:53:15');
INSERT INTO `system_navigation` VALUES ('171', '167', '0:0167:0171', '修改密码', '/adminUser', '1', null, 'fa-file-text', null, '255', '1', null, '2016-08-06 13:33:19');
INSERT INTO `system_navigation` VALUES ('177', '0', '0:0177', '刷单管理', '', '1', null, 'fa-file-text', null, '255', '1', '2016-08-25 08:49:48', '2016-08-25 08:49:48');
INSERT INTO `system_navigation` VALUES ('178', '177', '0:0177:0178', '现金支付刷单', '/orderInfoDk/index', '1', null, 'fa-file-text', null, '255', '1', '2016-08-25 08:50:39', '2016-08-25 08:50:39');
INSERT INTO `system_navigation` VALUES ('179', '0', '0:0179', '收银账号管理', '', '1', null, 'fa-file-text', null, '255', '1', '2016-09-05 10:51:17', '2016-09-05 10:51:17');
INSERT INTO `system_navigation` VALUES ('180', '179', '0:0179:0180', '收银账号列表', '/adminUser/index', '1', null, 'fa-file-text', null, '255', '1', '2016-09-05 10:54:19', '2016-09-05 10:54:19');
INSERT INTO `system_navigation` VALUES ('181', '165', '0:0165:0181', '提现设置列表', '/businessAdvanceSetting/index', '1', null, 'fa-file-text', null, '255', '1', '2016-09-06 09:19:13', '2016-09-06 09:19:13');
INSERT INTO `system_navigation` VALUES ('182', '123', '0:0123:0182', '商家商品管理', '/goodsInfo/businessindex', '1', null, 'fa-file-text', null, '255', '1', '2016-09-08 09:34:31', '2016-09-08 09:34:31');
INSERT INTO `system_navigation` VALUES ('183', '177', '0:0177:0183', '指定商户刷单', '/handorder', '1', null, 'fa-file-text', null, '255', '1', '2016-09-13 15:20:11', '2016-09-13 15:20:11');
INSERT INTO `system_navigation` VALUES ('184', '177', '0:0177:0184', '优惠付订单', '/yhforder', '1', null, 'fa-file-text', null, '255', '1', '2016-09-13 15:20:54', '2016-09-13 15:20:54');
INSERT INTO `system_navigation` VALUES ('185', '0', '0:0185', '提现设置', '', '1', null, 'fa-file-text', null, '255', '1', '2016-11-21 10:37:23', '2016-11-21 10:37:23');
INSERT INTO `system_navigation` VALUES ('186', '185', '0:0185:0186', '提现设置', '/platAdvanceSetting/index', '1', null, 'fa-file-text', null, '255', '1', null, '2016-11-21 10:41:54');
INSERT INTO `system_navigation` VALUES ('187', '0', '0:0187', '用户余额', '', '1', null, 'fa-file-text', null, '255', '1', '2016-11-21 12:53:15', '2016-11-21 12:53:15');
INSERT INTO `system_navigation` VALUES ('188', '187', '0:0187:0188', '用户余额', '/platformBalanceDetail/index', '1', null, 'fa-file-text', null, '255', '1', '2016-11-21 12:54:17', '2016-11-21 12:54:17');
INSERT INTO `system_navigation` VALUES ('189', '0', '0:0189', '商品销量统计查询', '', '1', null, 'fa-file-text', null, '255', '1', '2016-11-21 13:25:47', '2016-11-21 13:25:47');
INSERT INTO `system_navigation` VALUES ('190', '189', '0:0189:0190', '商品销量统计查询', '/orderInfo/statistics', '1', null, 'fa-file-text', null, '255', '1', '2016-11-21 13:29:40', '2016-11-21 13:29:40');
INSERT INTO `system_navigation` VALUES ('192', '169', '0:0169:0192', '平台提现列表', '/platformBalanceDetail', '1', null, 'fa-file-text', null, '255', '1', '2016-11-21 15:56:19', '2016-11-21 15:56:19');
INSERT INTO `system_navigation` VALUES ('193', '0', '0:0193', '订单明细', '', '1', null, 'fa-file-text', null, '255', '1', '2016-12-13 15:49:16', '2016-12-13 15:49:16');
INSERT INTO `system_navigation` VALUES ('194', '193', '0:0193:0194', '商户订单列表', '/orderInfo/orderDetail', '1', null, 'fa-file-text', null, '255', '1', '2016-12-13 15:49:43', '2016-12-13 15:49:43');
INSERT INTO `system_navigation` VALUES ('195', '193', '0:0193:0195', '商户订单汇总', '/orderInfo/businessOrderCount', '1', null, 'fa-file-text', null, '255', '1', '2016-12-14 11:59:47', '2016-12-14 11:59:47');
INSERT INTO `system_navigation` VALUES ('196', '193', '0:0193:0196', '商品销售查询', '/orderInfo/selectOrderGoods', '1', null, 'fa-file-text', null, '255', '1', '2016-12-14 16:11:01', '2016-12-14 16:11:01');
INSERT INTO `system_navigation` VALUES ('197', '0', '0:0197', '报表系统', '', '1', null, 'fa-file-text', null, '255', '1', '2016-12-15 12:50:12', '2016-12-15 12:50:12');
INSERT INTO `system_navigation` VALUES ('198', '197', '0:0197:0198', '线下销量表', '/orderInfo/businessOrderGoodsInfo', '1', null, 'fa-file-text', null, '255', '1', '2016-12-15 12:50:53', '2016-12-15 12:50:53');
INSERT INTO `system_navigation` VALUES ('200', '197', '0:0197:0200', '店铺线下订单列表', '/businessInfo/orderInfoPage', '1', null, 'fa-file-text', null, '255', '1', '2016-12-15 13:49:30', '2016-12-15 13:49:30');
INSERT INTO `system_navigation` VALUES ('201', '197', '0:0197:0201', '店铺提现列表', '/businessBalanceDetail/cashList', '1', null, 'fa-file-text', null, '255', '1', null, '2016-12-15 20:22:03');

-- ----------------------------
-- Table structure for system_navigation_extend
-- ----------------------------
DROP TABLE IF EXISTS `system_navigation_extend`;
CREATE TABLE `system_navigation_extend` (
  `extend_id` int(11) NOT NULL AUTO_INCREMENT,
  `navigation_id` int(11) DEFAULT NULL,
  `from_navid` int(11) NOT NULL COMMENT '继承的导航 ID',
  `title` varchar(255) DEFAULT NULL COMMENT 'category title',
  `link` varchar(255) DEFAULT NULL,
  `is_ajaxload` tinyint(1) DEFAULT NULL COMMENT '链接来源，1为内部链接，0为外部链接',
  `description` text,
  `ctime` datetime DEFAULT NULL,
  `mtime` datetime DEFAULT NULL,
  `sort_order` int(11) DEFAULT '0' COMMENT '序号',
  PRIMARY KEY (`extend_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='system quick navigation';

-- ----------------------------
-- Records of system_navigation_extend
-- ----------------------------

-- ----------------------------
-- Table structure for system_navigation_user
-- ----------------------------
DROP TABLE IF EXISTS `system_navigation_user`;
CREATE TABLE `system_navigation_user` (
  `navigation_id` int(11) NOT NULL DEFAULT '0',
  `sort_order` int(11) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  PRIMARY KEY (`username`,`navigation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户收藏导航列表';

-- ----------------------------
-- Records of system_navigation_user
-- ----------------------------
INSERT INTO `system_navigation_user` VALUES ('11', '6', 'admin');
INSERT INTO `system_navigation_user` VALUES ('18', '1', 'admin');
INSERT INTO `system_navigation_user` VALUES ('22', '2', 'admin');
INSERT INTO `system_navigation_user` VALUES ('23', '3', 'admin');
INSERT INTO `system_navigation_user` VALUES ('24', '4', 'admin');
INSERT INTO `system_navigation_user` VALUES ('25', '5', 'admin');
INSERT INTO `system_navigation_user` VALUES ('28', '7', 'admin');

-- ----------------------------
-- Table structure for topic_appraise
-- ----------------------------
DROP TABLE IF EXISTS `topic_appraise`;
CREATE TABLE `topic_appraise` (
  `topicappraiseid` int(11) NOT NULL AUTO_INCREMENT COMMENT '评论编码',
  `topicid` int(11) DEFAULT NULL COMMENT '帖子编码',
  `userid` int(11) DEFAULT NULL COMMENT '评论人编码',
  `content` varchar(200) DEFAULT NULL COMMENT '评论内容',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`topicappraiseid`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COMMENT='帖子评论表';

-- ----------------------------
-- Records of topic_appraise
-- ----------------------------

-- ----------------------------
-- Table structure for topic_info
-- ----------------------------
DROP TABLE IF EXISTS `topic_info`;
CREATE TABLE `topic_info` (
  `topicid` int(11) NOT NULL AUTO_INCREMENT COMMENT '帖子编码',
  `userid` int(11) DEFAULT NULL COMMENT '发帖人编码',
  `title` varchar(100) DEFAULT NULL COMMENT '标题',
  `content` varchar(500) DEFAULT NULL COMMENT '内容',
  `oid` int(11) DEFAULT NULL COMMENT '订单id',
  `state` tinyint(3) NOT NULL DEFAULT '0' COMMENT '是否禁用 0否1是',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  `type` int(2) DEFAULT NULL COMMENT '0小订单1大订单',
  `rebatemoney` decimal(10,2) DEFAULT NULL COMMENT '返利金额',
  `orderid` varchar(40) DEFAULT NULL COMMENT '总订单编码',
  PRIMARY KEY (`topicid`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COMMENT='帖子表';

-- ----------------------------
-- Records of topic_info
-- ----------------------------

-- ----------------------------
-- Table structure for trend_region
-- ----------------------------
DROP TABLE IF EXISTS `trend_region`;
CREATE TABLE `trend_region` (
  `region_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pack` varchar(20) NOT NULL DEFAULT '',
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `hid` varchar(255) DEFAULT NULL,
  `grade` mediumint(8) unsigned DEFAULT NULL,
  `region_code` varchar(10) DEFAULT NULL COMMENT '区划编码',
  `region_name` varchar(50) NOT NULL DEFAULT '',
  `en_name` varchar(50) DEFAULT NULL,
  `p_1` varchar(50) DEFAULT NULL,
  `p_2` varchar(50) DEFAULT NULL,
  `sort_order` mediumint(8) unsigned DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1' COMMENT '是否启用。1：是；0：否；',
  PRIMARY KEY (`region_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3775 DEFAULT CHARSET=utf8 COMMENT='地区表';

-- ----------------------------
-- Records of trend_region
-- ----------------------------
INSERT INTO `trend_region` VALUES ('1', 'mainland', '3743', '0:003743:000001', '2', null, '北京', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2', 'mainland', '1', '0:003743:000001:000002', '3', '2', '北京市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3', 'mainland', '2', '0:003743:000001:000002:000003', '4', null, '东城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('4', 'mainland', '2', '0:003743:000001:000002:000004', '4', null, '西城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('5', 'mainland', '2', '0:003743:000001:000002:000005', '4', null, '崇文区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('6', 'mainland', '2', '0:003743:000001:000002:000006', '4', null, '宣武区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('7', 'mainland', '2', '0:003743:000001:000002:000007', '4', null, '朝阳区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('8', 'mainland', '2', '0:003743:000001:000002:000008', '4', null, '丰台区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('9', 'mainland', '2', '0:003743:000001:000002:000009', '4', null, '石景山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('10', 'mainland', '2', '0:003743:000001:000002:000010', '4', null, '海淀区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('11', 'mainland', '2', '0:003743:000001:000002:000011', '4', null, '门头沟区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('12', 'mainland', '2', '0:003743:000001:000002:000012', '4', null, '房山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('13', 'mainland', '2', '0:003743:000001:000002:000013', '4', null, '通州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('14', 'mainland', '2', '0:003743:000001:000002:000014', '4', null, '顺义区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('15', 'mainland', '2', '0:003743:000001:000002:000015', '4', null, '昌平区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('16', 'mainland', '2', '0:003743:000001:000002:000016', '4', null, '大兴区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('17', 'mainland', '2', '0:003743:000001:000002:000017', '4', null, '怀柔区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('18', 'mainland', '2', '0:003743:000001:000002:000018', '4', null, '平谷区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('19', 'mainland', '2', '0:003743:000001:000002:000019', '4', null, '密云县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('20', 'mainland', '2', '0:003743:000001:000002:000020', '4', null, '延庆县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('21', 'mainland', '2', '0:003743:000001:000002:000021', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('22', 'mainland', '3743', '0:003743:000022', '2', null, '天津', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('23', 'mainland', '22', '0:003743:000022:000023', '3', '23', '天津市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('24', 'mainland', '23', '0:003743:000022:000023:000024', '4', null, '和平区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('25', 'mainland', '23', '0:003743:000022:000023:000025', '4', null, '河东区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('26', 'mainland', '23', '0:003743:000022:000023:000026', '4', null, '河西区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('27', 'mainland', '23', '0:003743:000022:000023:000027', '4', null, '南开区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('28', 'mainland', '23', '0:003743:000022:000023:000028', '4', null, '河北区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('29', 'mainland', '23', '0:003743:000022:000023:000029', '4', null, '红桥区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('30', 'mainland', '23', '0:003743:000022:000023:000030', '4', null, '塘沽区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('31', 'mainland', '23', '0:003743:000022:000023:000031', '4', null, '汉沽区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('32', 'mainland', '23', '0:003743:000022:000023:000032', '4', null, '大港区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('33', 'mainland', '23', '0:003743:000022:000023:000033', '4', null, '东丽区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('34', 'mainland', '23', '0:003743:000022:000023:000034', '4', null, '西青区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('35', 'mainland', '23', '0:003743:000022:000023:000035', '4', null, '津南区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('36', 'mainland', '23', '0:003743:000022:000023:000036', '4', null, '北辰区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('37', 'mainland', '23', '0:003743:000022:000023:000037', '4', null, '武清区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('38', 'mainland', '23', '0:003743:000022:000023:000038', '4', null, '宝坻区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('39', 'mainland', '23', '0:003743:000022:000023:000039', '4', null, '滨海新区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('40', 'mainland', '23', '0:003743:000022:000023:000040', '4', null, '宁河县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('41', 'mainland', '23', '0:003743:000022:000023:000041', '4', null, '静海县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('42', 'mainland', '23', '0:003743:000022:000023:000042', '4', null, '蓟县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('43', 'mainland', '23', '0:003743:000022:000023:000043', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('44', 'mainland', '3743', '0:003743:000044', '2', null, '河北省', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('45', 'mainland', '44', '0:003743:000044:000045', '3', '1301', '石家庄市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('46', 'mainland', '45', '0:003743:000044:000045:000046', '4', null, '长安区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('47', 'mainland', '45', '0:003743:000044:000045:000047', '4', null, '桥东区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('48', 'mainland', '45', '0:003743:000044:000045:000048', '4', null, '桥西区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('49', 'mainland', '45', '0:003743:000044:000045:000049', '4', null, '新华区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('50', 'mainland', '45', '0:003743:000044:000045:000050', '4', null, '井陉矿区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('51', 'mainland', '45', '0:003743:000044:000045:000051', '4', null, '裕华区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('52', 'mainland', '45', '0:003743:000044:000045:000052', '4', null, '井陉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('53', 'mainland', '45', '0:003743:000044:000045:000053', '4', null, '正定县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('54', 'mainland', '45', '0:003743:000044:000045:000054', '4', null, '栾城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('55', 'mainland', '45', '0:003743:000044:000045:000055', '4', null, '行唐县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('56', 'mainland', '45', '0:003743:000044:000045:000056', '4', null, '灵寿县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('57', 'mainland', '45', '0:003743:000044:000045:000057', '4', null, '高邑县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('58', 'mainland', '45', '0:003743:000044:000045:000058', '4', null, '深泽县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('59', 'mainland', '45', '0:003743:000044:000045:000059', '4', null, '赞皇县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('60', 'mainland', '45', '0:003743:000044:000045:000060', '4', null, '无极县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('61', 'mainland', '45', '0:003743:000044:000045:000061', '4', null, '平山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('62', 'mainland', '45', '0:003743:000044:000045:000062', '4', null, '元氏县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('63', 'mainland', '45', '0:003743:000044:000045:000063', '4', null, '赵县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('64', 'mainland', '45', '0:003743:000044:000045:000064', '4', null, '辛集市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('65', 'mainland', '45', '0:003743:000044:000045:000065', '4', null, '藁城市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('66', 'mainland', '45', '0:003743:000044:000045:000066', '4', null, '晋州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('67', 'mainland', '45', '0:003743:000044:000045:000067', '4', null, '新乐市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('68', 'mainland', '45', '0:003743:000044:000045:000068', '4', null, '鹿泉市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('69', 'mainland', '45', '0:003743:000044:000045:000069', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('70', 'mainland', '44', '0:003743:000044:000070', '3', '1302', '唐山市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('71', 'mainland', '70', '0:003743:000044:000070:000071', '4', null, '路南区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('72', 'mainland', '70', '0:003743:000044:000070:000072', '4', null, '路北区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('73', 'mainland', '70', '0:003743:000044:000070:000073', '4', null, '古冶区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('74', 'mainland', '70', '0:003743:000044:000070:000074', '4', null, '开平区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('75', 'mainland', '70', '0:003743:000044:000070:000075', '4', null, '丰南区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('76', 'mainland', '70', '0:003743:000044:000070:000076', '4', null, '丰润区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('77', 'mainland', '70', '0:003743:000044:000070:000077', '4', null, '滦县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('78', 'mainland', '70', '0:003743:000044:000070:000078', '4', null, '滦南县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('79', 'mainland', '70', '0:003743:000044:000070:000079', '4', null, '乐亭县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('80', 'mainland', '70', '0:003743:000044:000070:000080', '4', null, '迁西县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('81', 'mainland', '70', '0:003743:000044:000070:000081', '4', null, '玉田县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('82', 'mainland', '70', '0:003743:000044:000070:000082', '4', null, '唐海县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('83', 'mainland', '70', '0:003743:000044:000070:000083', '4', null, '遵化市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('84', 'mainland', '70', '0:003743:000044:000070:000084', '4', null, '迁安市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('85', 'mainland', '70', '0:003743:000044:000070:000085', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('86', 'mainland', '44', '0:003743:000044:000086', '3', '1303', '秦皇岛市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('87', 'mainland', '86', '0:003743:000044:000086:000087', '4', null, '海港区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('88', 'mainland', '86', '0:003743:000044:000086:000088', '4', null, '山海关区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('89', 'mainland', '86', '0:003743:000044:000086:000089', '4', null, '北戴河区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('90', 'mainland', '86', '0:003743:000044:000086:000090', '4', null, '青龙满族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('91', 'mainland', '86', '0:003743:000044:000086:000091', '4', null, '昌黎县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('92', 'mainland', '86', '0:003743:000044:000086:000092', '4', null, '抚宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('93', 'mainland', '86', '0:003743:000044:000086:000093', '4', null, '卢龙县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('94', 'mainland', '86', '0:003743:000044:000086:000094', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('95', 'mainland', '86', '0:003743:000044:000086:000095', '4', null, '经济技术开发区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('96', 'mainland', '44', '0:003743:000044:000096', '3', '1304', '邯郸市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('97', 'mainland', '96', '0:003743:000044:000096:000097', '4', null, '邯山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('98', 'mainland', '96', '0:003743:000044:000096:000098', '4', null, '丛台区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('99', 'mainland', '96', '0:003743:000044:000096:000099', '4', null, '复兴区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('100', 'mainland', '96', '0:003743:000044:000096:000100', '4', null, '峰峰矿区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('101', 'mainland', '96', '0:003743:000044:000096:000101', '4', null, '邯郸县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('102', 'mainland', '96', '0:003743:000044:000096:000102', '4', null, '临漳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('103', 'mainland', '96', '0:003743:000044:000096:000103', '4', null, '成安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('104', 'mainland', '96', '0:003743:000044:000096:000104', '4', null, '大名县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('105', 'mainland', '96', '0:003743:000044:000096:000105', '4', null, '涉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('106', 'mainland', '96', '0:003743:000044:000096:000106', '4', null, '磁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('107', 'mainland', '96', '0:003743:000044:000096:000107', '4', null, '肥乡县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('108', 'mainland', '96', '0:003743:000044:000096:000108', '4', null, '永年县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('109', 'mainland', '96', '0:003743:000044:000096:000109', '4', null, '邱县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('110', 'mainland', '96', '0:003743:000044:000096:000110', '4', null, '鸡泽县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('111', 'mainland', '96', '0:003743:000044:000096:000111', '4', null, '广平县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('112', 'mainland', '96', '0:003743:000044:000096:000112', '4', null, '馆陶县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('113', 'mainland', '96', '0:003743:000044:000096:000113', '4', null, '魏县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('114', 'mainland', '96', '0:003743:000044:000096:000114', '4', null, '曲周县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('115', 'mainland', '96', '0:003743:000044:000096:000115', '4', null, '武安市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('116', 'mainland', '96', '0:003743:000044:000096:000116', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('117', 'mainland', '44', '0:003743:000044:000117', '3', '1305', '邢台市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('118', 'mainland', '117', '0:003743:000044:000117:000118', '4', null, '桥东区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('119', 'mainland', '117', '0:003743:000044:000117:000119', '4', null, '桥西区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('120', 'mainland', '117', '0:003743:000044:000117:000120', '4', null, '邢台县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('121', 'mainland', '117', '0:003743:000044:000117:000121', '4', null, '临城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('122', 'mainland', '117', '0:003743:000044:000117:000122', '4', null, '内丘县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('123', 'mainland', '117', '0:003743:000044:000117:000123', '4', null, '柏乡县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('124', 'mainland', '117', '0:003743:000044:000117:000124', '4', null, '隆尧县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('125', 'mainland', '117', '0:003743:000044:000117:000125', '4', null, '任县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('126', 'mainland', '117', '0:003743:000044:000117:000126', '4', null, '南和县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('127', 'mainland', '117', '0:003743:000044:000117:000127', '4', null, '宁晋县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('128', 'mainland', '117', '0:003743:000044:000117:000128', '4', null, '巨鹿县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('129', 'mainland', '117', '0:003743:000044:000117:000129', '4', null, '新河县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('130', 'mainland', '117', '0:003743:000044:000117:000130', '4', null, '广宗县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('131', 'mainland', '117', '0:003743:000044:000117:000131', '4', null, '平乡县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('132', 'mainland', '117', '0:003743:000044:000117:000132', '4', null, '威县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('133', 'mainland', '117', '0:003743:000044:000117:000133', '4', null, '清河县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('134', 'mainland', '117', '0:003743:000044:000117:000134', '4', null, '临西县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('135', 'mainland', '117', '0:003743:000044:000117:000135', '4', null, '南宫市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('136', 'mainland', '117', '0:003743:000044:000117:000136', '4', null, '沙河市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('137', 'mainland', '117', '0:003743:000044:000117:000137', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('138', 'mainland', '44', '0:003743:000044:000138', '3', '1306', '保定市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('139', 'mainland', '138', '0:003743:000044:000138:000139', '4', null, '新市区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('140', 'mainland', '138', '0:003743:000044:000138:000140', '4', null, '北市区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('141', 'mainland', '138', '0:003743:000044:000138:000141', '4', null, '南市区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('142', 'mainland', '138', '0:003743:000044:000138:000142', '4', null, '满城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('143', 'mainland', '138', '0:003743:000044:000138:000143', '4', null, '清苑县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('144', 'mainland', '138', '0:003743:000044:000138:000144', '4', null, '涞水县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('145', 'mainland', '138', '0:003743:000044:000138:000145', '4', null, '阜平县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('146', 'mainland', '138', '0:003743:000044:000138:000146', '4', null, '徐水县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('147', 'mainland', '138', '0:003743:000044:000138:000147', '4', null, '定兴县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('148', 'mainland', '138', '0:003743:000044:000138:000148', '4', null, '唐县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('149', 'mainland', '138', '0:003743:000044:000138:000149', '4', null, '高阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('150', 'mainland', '138', '0:003743:000044:000138:000150', '4', null, '容城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('151', 'mainland', '138', '0:003743:000044:000138:000151', '4', null, '涞源县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('152', 'mainland', '138', '0:003743:000044:000138:000152', '4', null, '望都县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('153', 'mainland', '138', '0:003743:000044:000138:000153', '4', null, '安新县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('154', 'mainland', '138', '0:003743:000044:000138:000154', '4', null, '易县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('155', 'mainland', '138', '0:003743:000044:000138:000155', '4', null, '曲阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('156', 'mainland', '138', '0:003743:000044:000138:000156', '4', null, '蠡县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('157', 'mainland', '138', '0:003743:000044:000138:000157', '4', null, '顺平县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('158', 'mainland', '138', '0:003743:000044:000138:000158', '4', null, '博野县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('159', 'mainland', '138', '0:003743:000044:000138:000159', '4', null, '雄县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('160', 'mainland', '138', '0:003743:000044:000138:000160', '4', null, '涿州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('161', 'mainland', '138', '0:003743:000044:000138:000161', '4', null, '定州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('162', 'mainland', '138', '0:003743:000044:000138:000162', '4', null, '安国市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('163', 'mainland', '138', '0:003743:000044:000138:000163', '4', null, '高碑店市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('164', 'mainland', '138', '0:003743:000044:000138:000164', '4', null, '高开区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('165', 'mainland', '138', '0:003743:000044:000138:000165', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('166', 'mainland', '44', '0:003743:000044:000166', '3', '1307', '张家口市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('167', 'mainland', '166', '0:003743:000044:000166:000167', '4', null, '桥东区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('168', 'mainland', '166', '0:003743:000044:000166:000168', '4', null, '桥西区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('169', 'mainland', '166', '0:003743:000044:000166:000169', '4', null, '宣化区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('170', 'mainland', '166', '0:003743:000044:000166:000170', '4', null, '下花园区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('171', 'mainland', '166', '0:003743:000044:000166:000171', '4', null, '宣化县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('172', 'mainland', '166', '0:003743:000044:000166:000172', '4', null, '张北县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('173', 'mainland', '166', '0:003743:000044:000166:000173', '4', null, '康保县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('174', 'mainland', '166', '0:003743:000044:000166:000174', '4', null, '沽源县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('175', 'mainland', '166', '0:003743:000044:000166:000175', '4', null, '尚义县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('176', 'mainland', '166', '0:003743:000044:000166:000176', '4', null, '蔚县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('177', 'mainland', '166', '0:003743:000044:000166:000177', '4', null, '阳原县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('178', 'mainland', '166', '0:003743:000044:000166:000178', '4', null, '怀安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('179', 'mainland', '166', '0:003743:000044:000166:000179', '4', null, '万全县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('180', 'mainland', '166', '0:003743:000044:000166:000180', '4', null, '怀来县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('181', 'mainland', '166', '0:003743:000044:000166:000181', '4', null, '涿鹿县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('182', 'mainland', '166', '0:003743:000044:000166:000182', '4', null, '赤城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('183', 'mainland', '166', '0:003743:000044:000166:000183', '4', null, '崇礼县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('184', 'mainland', '166', '0:003743:000044:000166:000184', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('185', 'mainland', '44', '0:003743:000044:000185', '3', '1308', '承德市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('186', 'mainland', '185', '0:003743:000044:000185:000186', '4', null, '双桥区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('187', 'mainland', '185', '0:003743:000044:000185:000187', '4', null, '双滦区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('188', 'mainland', '185', '0:003743:000044:000185:000188', '4', null, '鹰手营子矿区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('189', 'mainland', '185', '0:003743:000044:000185:000189', '4', null, '承德县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('190', 'mainland', '185', '0:003743:000044:000185:000190', '4', null, '兴隆县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('191', 'mainland', '185', '0:003743:000044:000185:000191', '4', null, '平泉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('192', 'mainland', '185', '0:003743:000044:000185:000192', '4', null, '滦平县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('193', 'mainland', '185', '0:003743:000044:000185:000193', '4', null, '隆化县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('194', 'mainland', '185', '0:003743:000044:000185:000194', '4', null, '丰宁满族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('195', 'mainland', '185', '0:003743:000044:000185:000195', '4', null, '宽城满族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('196', 'mainland', '185', '0:003743:000044:000185:000196', '4', null, '围场满族蒙古族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('197', 'mainland', '185', '0:003743:000044:000185:000197', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('198', 'mainland', '44', '0:003743:000044:000198', '3', '1309', '沧州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('199', 'mainland', '198', '0:003743:000044:000198:000199', '4', null, '新华区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('200', 'mainland', '198', '0:003743:000044:000198:000200', '4', null, '运河区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('201', 'mainland', '198', '0:003743:000044:000198:000201', '4', null, '沧县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('202', 'mainland', '198', '0:003743:000044:000198:000202', '4', null, '青县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('203', 'mainland', '198', '0:003743:000044:000198:000203', '4', null, '东光县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('204', 'mainland', '198', '0:003743:000044:000198:000204', '4', null, '海兴县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('205', 'mainland', '198', '0:003743:000044:000198:000205', '4', null, '盐山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('206', 'mainland', '198', '0:003743:000044:000198:000206', '4', null, '肃宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('207', 'mainland', '198', '0:003743:000044:000198:000207', '4', null, '南皮县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('208', 'mainland', '198', '0:003743:000044:000198:000208', '4', null, '吴桥县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('209', 'mainland', '198', '0:003743:000044:000198:000209', '4', null, '献县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('210', 'mainland', '198', '0:003743:000044:000198:000210', '4', null, '孟村回族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('211', 'mainland', '198', '0:003743:000044:000198:000211', '4', null, '泊头市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('212', 'mainland', '198', '0:003743:000044:000198:000212', '4', null, '任丘市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('213', 'mainland', '198', '0:003743:000044:000198:000213', '4', null, '黄骅市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('214', 'mainland', '198', '0:003743:000044:000198:000214', '4', null, '河间市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('215', 'mainland', '198', '0:003743:000044:000198:000215', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('216', 'mainland', '44', '0:003743:000044:000216', '3', '216', '廊坊市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('217', 'mainland', '216', '0:003743:000044:000216:000217', '4', null, '安次区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('218', 'mainland', '216', '0:003743:000044:000216:000218', '4', null, '广阳区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('219', 'mainland', '216', '0:003743:000044:000216:000219', '4', null, '固安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('220', 'mainland', '216', '0:003743:000044:000216:000220', '4', null, '永清县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('221', 'mainland', '216', '0:003743:000044:000216:000221', '4', null, '香河县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('222', 'mainland', '216', '0:003743:000044:000216:000222', '4', null, '大城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('223', 'mainland', '216', '0:003743:000044:000216:000223', '4', null, '文安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('224', 'mainland', '216', '0:003743:000044:000216:000224', '4', null, '大厂回族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('225', 'mainland', '216', '0:003743:000044:000216:000225', '4', null, '开发区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('226', 'mainland', '216', '0:003743:000044:000216:000226', '4', null, '燕郊经济技术开发区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('227', 'mainland', '216', '0:003743:000044:000216:000227', '4', null, '霸州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('228', 'mainland', '216', '0:003743:000044:000216:000228', '4', null, '三河市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('229', 'mainland', '216', '0:003743:000044:000216:000229', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('230', 'mainland', '44', '0:003743:000044:000230', '3', '1311', '衡水市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('231', 'mainland', '230', '0:003743:000044:000230:000231', '4', null, '桃城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('232', 'mainland', '230', '0:003743:000044:000230:000232', '4', null, '枣强县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('233', 'mainland', '230', '0:003743:000044:000230:000233', '4', null, '武邑县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('234', 'mainland', '230', '0:003743:000044:000230:000234', '4', null, '武强县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('235', 'mainland', '230', '0:003743:000044:000230:000235', '4', null, '饶阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('236', 'mainland', '230', '0:003743:000044:000230:000236', '4', null, '安平县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('237', 'mainland', '230', '0:003743:000044:000230:000237', '4', null, '故城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('238', 'mainland', '230', '0:003743:000044:000230:000238', '4', null, '景县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('239', 'mainland', '230', '0:003743:000044:000230:000239', '4', null, '阜城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('240', 'mainland', '230', '0:003743:000044:000230:000240', '4', null, '冀州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('241', 'mainland', '230', '0:003743:000044:000230:000241', '4', null, '深州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('242', 'mainland', '230', '0:003743:000044:000230:000242', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('243', 'mainland', '3743', '0:003743:000243', '2', null, '山西省', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('244', 'mainland', '243', '0:003743:000243:000244', '3', '1401', '太原市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('245', 'mainland', '244', '0:003743:000243:000244:000245', '4', null, '小店区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('246', 'mainland', '244', '0:003743:000243:000244:000246', '4', null, '迎泽区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('247', 'mainland', '244', '0:003743:000243:000244:000247', '4', null, '杏花岭区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('248', 'mainland', '244', '0:003743:000243:000244:000248', '4', null, '尖草坪区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('249', 'mainland', '244', '0:003743:000243:000244:000249', '4', null, '万柏林区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('250', 'mainland', '244', '0:003743:000243:000244:000250', '4', null, '晋源区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('251', 'mainland', '244', '0:003743:000243:000244:000251', '4', null, '清徐县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('252', 'mainland', '244', '0:003743:000243:000244:000252', '4', null, '阳曲县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('253', 'mainland', '244', '0:003743:000243:000244:000253', '4', null, '娄烦县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('254', 'mainland', '244', '0:003743:000243:000244:000254', '4', null, '古交市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('255', 'mainland', '244', '0:003743:000243:000244:000255', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('256', 'mainland', '243', '0:003743:000243:000256', '3', '1402', '大同市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('257', 'mainland', '256', '0:003743:000243:000256:000257', '4', null, '城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('258', 'mainland', '256', '0:003743:000243:000256:000258', '4', null, '矿区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('259', 'mainland', '256', '0:003743:000243:000256:000259', '4', null, '南郊区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('260', 'mainland', '256', '0:003743:000243:000256:000260', '4', null, '新荣区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('261', 'mainland', '256', '0:003743:000243:000256:000261', '4', null, '阳高县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('262', 'mainland', '256', '0:003743:000243:000256:000262', '4', null, '天镇县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('263', 'mainland', '256', '0:003743:000243:000256:000263', '4', null, '广灵县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('264', 'mainland', '256', '0:003743:000243:000256:000264', '4', null, '灵丘县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('265', 'mainland', '256', '0:003743:000243:000256:000265', '4', null, '浑源县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('266', 'mainland', '256', '0:003743:000243:000256:000266', '4', null, '左云县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('267', 'mainland', '256', '0:003743:000243:000256:000267', '4', null, '大同县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('268', 'mainland', '256', '0:003743:000243:000256:000268', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('269', 'mainland', '243', '0:003743:000243:000269', '3', '1403', '阳泉市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('270', 'mainland', '269', '0:003743:000243:000269:000270', '4', null, '城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('271', 'mainland', '269', '0:003743:000243:000269:000271', '4', null, '矿区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('272', 'mainland', '269', '0:003743:000243:000269:000272', '4', null, '郊区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('273', 'mainland', '269', '0:003743:000243:000269:000273', '4', null, '平定县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('274', 'mainland', '269', '0:003743:000243:000269:000274', '4', null, '盂县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('275', 'mainland', '269', '0:003743:000243:000269:000275', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('276', 'mainland', '243', '0:003743:000243:000276', '3', '1404', '长治市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('277', 'mainland', '276', '0:003743:000243:000276:000277', '4', null, '长治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('278', 'mainland', '276', '0:003743:000243:000276:000278', '4', null, '襄垣县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('279', 'mainland', '276', '0:003743:000243:000276:000279', '4', null, '屯留县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('280', 'mainland', '276', '0:003743:000243:000276:000280', '4', null, '平顺县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('281', 'mainland', '276', '0:003743:000243:000276:000281', '4', null, '黎城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('282', 'mainland', '276', '0:003743:000243:000276:000282', '4', null, '壶关县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('283', 'mainland', '276', '0:003743:000243:000276:000283', '4', null, '长子县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('284', 'mainland', '276', '0:003743:000243:000276:000284', '4', null, '武乡县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('285', 'mainland', '276', '0:003743:000243:000276:000285', '4', null, '沁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('286', 'mainland', '276', '0:003743:000243:000276:000286', '4', null, '沁源县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('287', 'mainland', '276', '0:003743:000243:000276:000287', '4', null, '潞城市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('288', 'mainland', '276', '0:003743:000243:000276:000288', '4', null, '城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('289', 'mainland', '276', '0:003743:000243:000276:000289', '4', null, '郊区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('290', 'mainland', '276', '0:003743:000243:000276:000290', '4', null, '高新区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('291', 'mainland', '276', '0:003743:000243:000276:000291', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('292', 'mainland', '243', '0:003743:000243:000292', '3', '1405', '晋城市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('293', 'mainland', '292', '0:003743:000243:000292:000293', '4', null, '城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('294', 'mainland', '292', '0:003743:000243:000292:000294', '4', null, '沁水县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('295', 'mainland', '292', '0:003743:000243:000292:000295', '4', null, '阳城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('296', 'mainland', '292', '0:003743:000243:000292:000296', '4', null, '陵川县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('297', 'mainland', '292', '0:003743:000243:000292:000297', '4', null, '泽州县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('298', 'mainland', '292', '0:003743:000243:000292:000298', '4', null, '高平市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('299', 'mainland', '292', '0:003743:000243:000292:000299', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('300', 'mainland', '243', '0:003743:000243:000300', '3', '1406', '朔州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('301', 'mainland', '300', '0:003743:000243:000300:000301', '4', null, '朔城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('302', 'mainland', '300', '0:003743:000243:000300:000302', '4', null, '平鲁区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('303', 'mainland', '300', '0:003743:000243:000300:000303', '4', null, '山阴县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('304', 'mainland', '300', '0:003743:000243:000300:000304', '4', null, '应县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('305', 'mainland', '300', '0:003743:000243:000300:000305', '4', null, '右玉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('306', 'mainland', '300', '0:003743:000243:000300:000306', '4', null, '怀仁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('307', 'mainland', '300', '0:003743:000243:000300:000307', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('308', 'mainland', '243', '0:003743:000243:000308', '3', '1407', '晋中市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('309', 'mainland', '308', '0:003743:000243:000308:000309', '4', null, '榆次区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('310', 'mainland', '308', '0:003743:000243:000308:000310', '4', null, '榆社县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('311', 'mainland', '308', '0:003743:000243:000308:000311', '4', null, '左权县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('312', 'mainland', '308', '0:003743:000243:000308:000312', '4', null, '和顺县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('313', 'mainland', '308', '0:003743:000243:000308:000313', '4', null, '昔阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('314', 'mainland', '308', '0:003743:000243:000308:000314', '4', null, '寿阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('315', 'mainland', '308', '0:003743:000243:000308:000315', '4', null, '太谷县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('316', 'mainland', '308', '0:003743:000243:000308:000316', '4', null, '祁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('317', 'mainland', '308', '0:003743:000243:000308:000317', '4', null, '平遥县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('318', 'mainland', '308', '0:003743:000243:000308:000318', '4', null, '灵石县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('319', 'mainland', '308', '0:003743:000243:000308:000319', '4', null, '介休市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('320', 'mainland', '308', '0:003743:000243:000308:000320', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('321', 'mainland', '243', '0:003743:000243:000321', '3', '1408', '运城市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('322', 'mainland', '321', '0:003743:000243:000321:000322', '4', null, '盐湖区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('323', 'mainland', '321', '0:003743:000243:000321:000323', '4', null, '临猗县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('324', 'mainland', '321', '0:003743:000243:000321:000324', '4', null, '万荣县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('325', 'mainland', '321', '0:003743:000243:000321:000325', '4', null, '闻喜县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('326', 'mainland', '321', '0:003743:000243:000321:000326', '4', null, '稷山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('327', 'mainland', '321', '0:003743:000243:000321:000327', '4', null, '新绛县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('328', 'mainland', '321', '0:003743:000243:000321:000328', '4', null, '绛县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('329', 'mainland', '321', '0:003743:000243:000321:000329', '4', null, '垣曲县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('330', 'mainland', '321', '0:003743:000243:000321:000330', '4', null, '夏县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('331', 'mainland', '321', '0:003743:000243:000321:000331', '4', null, '平陆县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('332', 'mainland', '321', '0:003743:000243:000321:000332', '4', null, '芮城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('333', 'mainland', '321', '0:003743:000243:000321:000333', '4', null, '永济市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('334', 'mainland', '321', '0:003743:000243:000321:000334', '4', null, '河津市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('335', 'mainland', '321', '0:003743:000243:000321:000335', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('336', 'mainland', '243', '0:003743:000243:000336', '3', '1409', '忻州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('337', 'mainland', '336', '0:003743:000243:000336:000337', '4', null, '忻府区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('338', 'mainland', '336', '0:003743:000243:000336:000338', '4', null, '定襄县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('339', 'mainland', '336', '0:003743:000243:000336:000339', '4', null, '五台县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('340', 'mainland', '336', '0:003743:000243:000336:000340', '4', null, '代县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('341', 'mainland', '336', '0:003743:000243:000336:000341', '4', null, '繁峙县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('342', 'mainland', '336', '0:003743:000243:000336:000342', '4', null, '宁武县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('343', 'mainland', '336', '0:003743:000243:000336:000343', '4', null, '静乐县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('344', 'mainland', '336', '0:003743:000243:000336:000344', '4', null, '神池县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('345', 'mainland', '336', '0:003743:000243:000336:000345', '4', null, '五寨县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('346', 'mainland', '336', '0:003743:000243:000336:000346', '4', null, '岢岚县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('347', 'mainland', '336', '0:003743:000243:000336:000347', '4', null, '河曲县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('348', 'mainland', '336', '0:003743:000243:000336:000348', '4', null, '保德县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('349', 'mainland', '336', '0:003743:000243:000336:000349', '4', null, '偏关县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('350', 'mainland', '336', '0:003743:000243:000336:000350', '4', null, '原平市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('351', 'mainland', '336', '0:003743:000243:000336:000351', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('352', 'mainland', '243', '0:003743:000243:000352', '3', '352', '临汾市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('353', 'mainland', '352', '0:003743:000243:000352:000353', '4', null, '尧都区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('354', 'mainland', '352', '0:003743:000243:000352:000354', '4', null, '曲沃县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('355', 'mainland', '352', '0:003743:000243:000352:000355', '4', null, '翼城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('356', 'mainland', '352', '0:003743:000243:000352:000356', '4', null, '襄汾县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('357', 'mainland', '352', '0:003743:000243:000352:000357', '4', null, '洪洞县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('358', 'mainland', '352', '0:003743:000243:000352:000358', '4', null, '古县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('359', 'mainland', '352', '0:003743:000243:000352:000359', '4', null, '安泽县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('360', 'mainland', '352', '0:003743:000243:000352:000360', '4', null, '浮山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('361', 'mainland', '352', '0:003743:000243:000352:000361', '4', null, '吉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('362', 'mainland', '352', '0:003743:000243:000352:000362', '4', null, '乡宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('363', 'mainland', '352', '0:003743:000243:000352:000363', '4', null, '大宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('364', 'mainland', '352', '0:003743:000243:000352:000364', '4', null, '隰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('365', 'mainland', '352', '0:003743:000243:000352:000365', '4', null, '永和县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('366', 'mainland', '352', '0:003743:000243:000352:000366', '4', null, '蒲县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('367', 'mainland', '352', '0:003743:000243:000352:000367', '4', null, '汾西县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('368', 'mainland', '352', '0:003743:000243:000352:000368', '4', null, '侯马市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('369', 'mainland', '352', '0:003743:000243:000352:000369', '4', null, '霍州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('370', 'mainland', '352', '0:003743:000243:000352:000370', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('371', 'mainland', '243', '0:003743:000243:000371', '3', '1411', '吕梁市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('372', 'mainland', '371', '0:003743:000243:000371:000372', '4', null, '离石区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('373', 'mainland', '371', '0:003743:000243:000371:000373', '4', null, '文水县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('374', 'mainland', '371', '0:003743:000243:000371:000374', '4', null, '交城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('375', 'mainland', '371', '0:003743:000243:000371:000375', '4', null, '兴县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('376', 'mainland', '371', '0:003743:000243:000371:000376', '4', null, '临县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('377', 'mainland', '371', '0:003743:000243:000371:000377', '4', null, '柳林县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('378', 'mainland', '371', '0:003743:000243:000371:000378', '4', null, '石楼县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('379', 'mainland', '371', '0:003743:000243:000371:000379', '4', null, '岚县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('380', 'mainland', '371', '0:003743:000243:000371:000380', '4', null, '方山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('381', 'mainland', '371', '0:003743:000243:000371:000381', '4', null, '中阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('382', 'mainland', '371', '0:003743:000243:000371:000382', '4', null, '交口县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('383', 'mainland', '371', '0:003743:000243:000371:000383', '4', null, '孝义市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('384', 'mainland', '371', '0:003743:000243:000371:000384', '4', null, '汾阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('385', 'mainland', '371', '0:003743:000243:000371:000385', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('386', 'mainland', '3743', '0:003743:000386', '2', null, '内蒙古自治区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('387', 'mainland', '386', '0:003743:000386:000387', '3', '1501', '呼和浩特市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('388', 'mainland', '387', '0:003743:000386:000387:000388', '4', null, '新城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('389', 'mainland', '387', '0:003743:000386:000387:000389', '4', null, '回民区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('390', 'mainland', '387', '0:003743:000386:000387:000390', '4', null, '玉泉区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('391', 'mainland', '387', '0:003743:000386:000387:000391', '4', null, '赛罕区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('392', 'mainland', '387', '0:003743:000386:000387:000392', '4', null, '土默特左旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('393', 'mainland', '387', '0:003743:000386:000387:000393', '4', null, '托克托县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('394', 'mainland', '387', '0:003743:000386:000387:000394', '4', null, '和林格尔县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('395', 'mainland', '387', '0:003743:000386:000387:000395', '4', null, '清水河县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('396', 'mainland', '387', '0:003743:000386:000387:000396', '4', null, '武川县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('397', 'mainland', '387', '0:003743:000386:000387:000397', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('398', 'mainland', '386', '0:003743:000386:000398', '3', '1502', '包头市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('399', 'mainland', '398', '0:003743:000386:000398:000399', '4', null, '东河区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('400', 'mainland', '398', '0:003743:000386:000398:000400', '4', null, '昆都仑区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('401', 'mainland', '398', '0:003743:000386:000398:000401', '4', null, '青山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('402', 'mainland', '398', '0:003743:000386:000398:000402', '4', null, '石拐区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('403', 'mainland', '398', '0:003743:000386:000398:000403', '4', null, '白云矿区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('404', 'mainland', '398', '0:003743:000386:000398:000404', '4', null, '九原区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('405', 'mainland', '398', '0:003743:000386:000398:000405', '4', null, '土默特右旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('406', 'mainland', '398', '0:003743:000386:000398:000406', '4', null, '固阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('407', 'mainland', '398', '0:003743:000386:000398:000407', '4', null, '达尔罕茂明安联合旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('408', 'mainland', '398', '0:003743:000386:000398:000408', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('409', 'mainland', '386', '0:003743:000386:000409', '3', '1503', '乌海市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('410', 'mainland', '409', '0:003743:000386:000409:000410', '4', null, '海勃湾区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('411', 'mainland', '409', '0:003743:000386:000409:000411', '4', null, '海南区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('412', 'mainland', '409', '0:003743:000386:000409:000412', '4', null, '乌达区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('413', 'mainland', '409', '0:003743:000386:000409:000413', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('414', 'mainland', '386', '0:003743:000386:000414', '3', '1504', '赤峰市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('415', 'mainland', '414', '0:003743:000386:000414:000415', '4', null, '红山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('416', 'mainland', '414', '0:003743:000386:000414:000416', '4', null, '元宝山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('417', 'mainland', '414', '0:003743:000386:000414:000417', '4', null, '松山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('418', 'mainland', '414', '0:003743:000386:000414:000418', '4', null, '阿鲁科尔沁旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('419', 'mainland', '414', '0:003743:000386:000414:000419', '4', null, '巴林左旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('420', 'mainland', '414', '0:003743:000386:000414:000420', '4', null, '巴林右旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('421', 'mainland', '414', '0:003743:000386:000414:000421', '4', null, '林西县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('422', 'mainland', '414', '0:003743:000386:000414:000422', '4', null, '克什克腾旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('423', 'mainland', '414', '0:003743:000386:000414:000423', '4', null, '翁牛特旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('424', 'mainland', '414', '0:003743:000386:000414:000424', '4', null, '喀喇沁旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('425', 'mainland', '414', '0:003743:000386:000414:000425', '4', null, '宁城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('426', 'mainland', '414', '0:003743:000386:000414:000426', '4', null, '敖汉旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('427', 'mainland', '414', '0:003743:000386:000414:000427', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('428', 'mainland', '386', '0:003743:000386:000428', '3', '1505', '通辽市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('429', 'mainland', '428', '0:003743:000386:000428:000429', '4', null, '科尔沁区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('430', 'mainland', '428', '0:003743:000386:000428:000430', '4', null, '科尔沁左翼中旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('431', 'mainland', '428', '0:003743:000386:000428:000431', '4', null, '科尔沁左翼后旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('432', 'mainland', '428', '0:003743:000386:000428:000432', '4', null, '开鲁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('433', 'mainland', '428', '0:003743:000386:000428:000433', '4', null, '库伦旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('434', 'mainland', '428', '0:003743:000386:000428:000434', '4', null, '奈曼旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('435', 'mainland', '428', '0:003743:000386:000428:000435', '4', null, '扎鲁特旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('436', 'mainland', '428', '0:003743:000386:000428:000436', '4', null, '霍林郭勒市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('437', 'mainland', '428', '0:003743:000386:000428:000437', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('438', 'mainland', '386', '0:003743:000386:000438', '3', '1506', '鄂尔多斯市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('439', 'mainland', '438', '0:003743:000386:000438:000439', '4', null, '东胜区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('440', 'mainland', '438', '0:003743:000386:000438:000440', '4', null, '达拉特旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('441', 'mainland', '438', '0:003743:000386:000438:000441', '4', null, '准格尔旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('442', 'mainland', '438', '0:003743:000386:000438:000442', '4', null, '鄂托克前旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('443', 'mainland', '438', '0:003743:000386:000438:000443', '4', null, '鄂托克旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('444', 'mainland', '438', '0:003743:000386:000438:000444', '4', null, '杭锦旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('445', 'mainland', '438', '0:003743:000386:000438:000445', '4', null, '乌审旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('446', 'mainland', '438', '0:003743:000386:000438:000446', '4', null, '伊金霍洛旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('447', 'mainland', '438', '0:003743:000386:000438:000447', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('448', 'mainland', '386', '0:003743:000386:000448', '3', '1507', '呼伦贝尔市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('449', 'mainland', '448', '0:003743:000386:000448:000449', '4', null, '海拉尔区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('450', 'mainland', '448', '0:003743:000386:000448:000450', '4', null, '阿荣旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('451', 'mainland', '448', '0:003743:000386:000448:000451', '4', null, '莫力达瓦达斡尔族自治旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('452', 'mainland', '448', '0:003743:000386:000448:000452', '4', null, '鄂伦春自治旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('453', 'mainland', '448', '0:003743:000386:000448:000453', '4', null, '鄂温克族自治旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('454', 'mainland', '448', '0:003743:000386:000448:000454', '4', null, '陈巴尔虎旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('455', 'mainland', '448', '0:003743:000386:000448:000455', '4', null, '新巴尔虎左旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('456', 'mainland', '448', '0:003743:000386:000448:000456', '4', null, '新巴尔虎右旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('457', 'mainland', '448', '0:003743:000386:000448:000457', '4', null, '满洲里市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('458', 'mainland', '448', '0:003743:000386:000448:000458', '4', null, '牙克石市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('459', 'mainland', '448', '0:003743:000386:000448:000459', '4', null, '扎兰屯市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('460', 'mainland', '448', '0:003743:000386:000448:000460', '4', null, '额尔古纳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('461', 'mainland', '448', '0:003743:000386:000448:000461', '4', null, '根河市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('462', 'mainland', '448', '0:003743:000386:000448:000462', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('463', 'mainland', '386', '0:003743:000386:000463', '3', '1508', '巴彦淖尔市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('464', 'mainland', '463', '0:003743:000386:000463:000464', '4', null, '临河区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('465', 'mainland', '463', '0:003743:000386:000463:000465', '4', null, '五原县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('466', 'mainland', '463', '0:003743:000386:000463:000466', '4', null, '磴口县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('467', 'mainland', '463', '0:003743:000386:000463:000467', '4', null, '乌拉特前旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('468', 'mainland', '463', '0:003743:000386:000463:000468', '4', null, '乌拉特中旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('469', 'mainland', '463', '0:003743:000386:000463:000469', '4', null, '乌拉特后旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('470', 'mainland', '463', '0:003743:000386:000463:000470', '4', null, '杭锦后旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('471', 'mainland', '463', '0:003743:000386:000463:000471', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('472', 'mainland', '386', '0:003743:000386:000472', '3', '1509', '乌兰察布市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('473', 'mainland', '472', '0:003743:000386:000472:000473', '4', null, '集宁区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('474', 'mainland', '472', '0:003743:000386:000472:000474', '4', null, '卓资县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('475', 'mainland', '472', '0:003743:000386:000472:000475', '4', null, '化德县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('476', 'mainland', '472', '0:003743:000386:000472:000476', '4', null, '商都县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('477', 'mainland', '472', '0:003743:000386:000472:000477', '4', null, '兴和县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('478', 'mainland', '472', '0:003743:000386:000472:000478', '4', null, '凉城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('479', 'mainland', '472', '0:003743:000386:000472:000479', '4', null, '察哈尔右翼前旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('480', 'mainland', '472', '0:003743:000386:000472:000480', '4', null, '察哈尔右翼中旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('481', 'mainland', '472', '0:003743:000386:000472:000481', '4', null, '察哈尔右翼后旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('482', 'mainland', '472', '0:003743:000386:000472:000482', '4', null, '四子王旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('483', 'mainland', '472', '0:003743:000386:000472:000483', '4', null, '丰镇市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('484', 'mainland', '472', '0:003743:000386:000472:000484', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('485', 'mainland', '386', '0:003743:000386:000485', '3', '1522', '兴安盟', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('486', 'mainland', '485', '0:003743:000386:000485:000486', '4', null, '乌兰浩特市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('487', 'mainland', '485', '0:003743:000386:000485:000487', '4', null, '阿尔山市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('488', 'mainland', '485', '0:003743:000386:000485:000488', '4', null, '科尔沁右翼前旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('489', 'mainland', '485', '0:003743:000386:000485:000489', '4', null, '科尔沁右翼中旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('490', 'mainland', '485', '0:003743:000386:000485:000490', '4', null, '扎赉特旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('491', 'mainland', '485', '0:003743:000386:000485:000491', '4', null, '突泉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('492', 'mainland', '485', '0:003743:000386:000485:000492', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('493', 'mainland', '386', '0:003743:000386:000493', '3', '493', '锡林郭勒盟', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('494', 'mainland', '493', '0:003743:000386:000493:000494', '4', null, '二连浩特市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('495', 'mainland', '493', '0:003743:000386:000493:000495', '4', null, '锡林浩特市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('496', 'mainland', '493', '0:003743:000386:000493:000496', '4', null, '阿巴嘎旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('497', 'mainland', '493', '0:003743:000386:000493:000497', '4', null, '苏尼特左旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('498', 'mainland', '493', '0:003743:000386:000493:000498', '4', null, '苏尼特右旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('499', 'mainland', '493', '0:003743:000386:000493:000499', '4', null, '东乌珠穆沁旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('500', 'mainland', '493', '0:003743:000386:000493:000500', '4', null, '西乌珠穆沁旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('501', 'mainland', '493', '0:003743:000386:000493:000501', '4', null, '太仆寺旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('502', 'mainland', '493', '0:003743:000386:000493:000502', '4', null, '镶黄旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('503', 'mainland', '493', '0:003743:000386:000493:000503', '4', null, '正镶白旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('504', 'mainland', '493', '0:003743:000386:000493:000504', '4', null, '正蓝旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('505', 'mainland', '493', '0:003743:000386:000493:000505', '4', null, '多伦县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('506', 'mainland', '493', '0:003743:000386:000493:000506', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('507', 'mainland', '386', '0:003743:000386:000507', '3', '1529', '阿拉善盟', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('508', 'mainland', '507', '0:003743:000386:000507:000508', '4', null, '阿拉善左旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('509', 'mainland', '507', '0:003743:000386:000507:000509', '4', null, '阿拉善右旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('510', 'mainland', '507', '0:003743:000386:000507:000510', '4', null, '额济纳旗', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('511', 'mainland', '507', '0:003743:000386:000507:000511', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('512', 'mainland', '3743', '0:003743:000512', '2', null, '辽宁省', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('513', 'mainland', '512', '0:003743:000512:000513', '3', '2101', '沈阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('514', 'mainland', '513', '0:003743:000512:000513:000514', '4', null, '和平区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('515', 'mainland', '513', '0:003743:000512:000513:000515', '4', null, '沈河区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('516', 'mainland', '513', '0:003743:000512:000513:000516', '4', null, '大东区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('517', 'mainland', '513', '0:003743:000512:000513:000517', '4', null, '皇姑区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('518', 'mainland', '513', '0:003743:000512:000513:000518', '4', null, '铁西区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('519', 'mainland', '513', '0:003743:000512:000513:000519', '4', null, '苏家屯区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('520', 'mainland', '513', '0:003743:000512:000513:000520', '4', null, '东陵区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('521', 'mainland', '513', '0:003743:000512:000513:000521', '4', null, '新城子区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('522', 'mainland', '513', '0:003743:000512:000513:000522', '4', null, '于洪区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('523', 'mainland', '513', '0:003743:000512:000513:000523', '4', null, '辽中县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('524', 'mainland', '513', '0:003743:000512:000513:000524', '4', null, '康平县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('525', 'mainland', '513', '0:003743:000512:000513:000525', '4', null, '法库县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('526', 'mainland', '513', '0:003743:000512:000513:000526', '4', null, '新民市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('527', 'mainland', '513', '0:003743:000512:000513:000527', '4', null, '浑南新区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('528', 'mainland', '513', '0:003743:000512:000513:000528', '4', null, '张士开发区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('529', 'mainland', '513', '0:003743:000512:000513:000529', '4', null, '沈北新区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('530', 'mainland', '513', '0:003743:000512:000513:000530', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('531', 'mainland', '512', '0:003743:000512:000531', '3', '2102', '大连市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('532', 'mainland', '531', '0:003743:000512:000531:000532', '4', null, '中山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('533', 'mainland', '531', '0:003743:000512:000531:000533', '4', null, '西岗区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('534', 'mainland', '531', '0:003743:000512:000531:000534', '4', null, '沙河口区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('535', 'mainland', '531', '0:003743:000512:000531:000535', '4', null, '甘井子区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('536', 'mainland', '531', '0:003743:000512:000531:000536', '4', null, '旅顺口区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('537', 'mainland', '531', '0:003743:000512:000531:000537', '4', null, '金州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('538', 'mainland', '531', '0:003743:000512:000531:000538', '4', null, '长海县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('539', 'mainland', '531', '0:003743:000512:000531:000539', '4', null, '开发区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('540', 'mainland', '531', '0:003743:000512:000531:000540', '4', null, '瓦房店市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('541', 'mainland', '531', '0:003743:000512:000531:000541', '4', null, '普兰店市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('542', 'mainland', '531', '0:003743:000512:000531:000542', '4', null, '庄河市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('543', 'mainland', '531', '0:003743:000512:000531:000543', '4', null, '岭前区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('544', 'mainland', '531', '0:003743:000512:000531:000544', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('545', 'mainland', '512', '0:003743:000512:000545', '3', '2103', '鞍山市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('546', 'mainland', '545', '0:003743:000512:000545:000546', '4', null, '铁东区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('547', 'mainland', '545', '0:003743:000512:000545:000547', '4', null, '铁西区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('548', 'mainland', '545', '0:003743:000512:000545:000548', '4', null, '立山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('549', 'mainland', '545', '0:003743:000512:000545:000549', '4', null, '千山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('550', 'mainland', '545', '0:003743:000512:000545:000550', '4', null, '台安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('551', 'mainland', '545', '0:003743:000512:000545:000551', '4', null, '岫岩满族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('552', 'mainland', '545', '0:003743:000512:000545:000552', '4', null, '高新区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('553', 'mainland', '545', '0:003743:000512:000545:000553', '4', null, '海城市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('554', 'mainland', '545', '0:003743:000512:000545:000554', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('555', 'mainland', '512', '0:003743:000512:000555', '3', '2104', '抚顺市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('556', 'mainland', '555', '0:003743:000512:000555:000556', '4', null, '新抚区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('557', 'mainland', '555', '0:003743:000512:000555:000557', '4', null, '东洲区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('558', 'mainland', '555', '0:003743:000512:000555:000558', '4', null, '望花区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('559', 'mainland', '555', '0:003743:000512:000555:000559', '4', null, '顺城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('560', 'mainland', '555', '0:003743:000512:000555:000560', '4', null, '抚顺县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('561', 'mainland', '555', '0:003743:000512:000555:000561', '4', null, '新宾满族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('562', 'mainland', '555', '0:003743:000512:000555:000562', '4', null, '清原满族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('563', 'mainland', '555', '0:003743:000512:000555:000563', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('564', 'mainland', '512', '0:003743:000512:000564', '3', '2105', '本溪市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('565', 'mainland', '564', '0:003743:000512:000564:000565', '4', null, '平山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('566', 'mainland', '564', '0:003743:000512:000564:000566', '4', null, '溪湖区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('567', 'mainland', '564', '0:003743:000512:000564:000567', '4', null, '明山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('568', 'mainland', '564', '0:003743:000512:000564:000568', '4', null, '南芬区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('569', 'mainland', '564', '0:003743:000512:000564:000569', '4', null, '本溪满族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('570', 'mainland', '564', '0:003743:000512:000564:000570', '4', null, '桓仁满族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('571', 'mainland', '564', '0:003743:000512:000564:000571', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('572', 'mainland', '512', '0:003743:000512:000572', '3', '2106', '丹东市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('573', 'mainland', '572', '0:003743:000512:000572:000573', '4', null, '元宝区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('574', 'mainland', '572', '0:003743:000512:000572:000574', '4', null, '振兴区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('575', 'mainland', '572', '0:003743:000512:000572:000575', '4', null, '振安区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('576', 'mainland', '572', '0:003743:000512:000572:000576', '4', null, '宽甸满族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('577', 'mainland', '572', '0:003743:000512:000572:000577', '4', null, '东港市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('578', 'mainland', '572', '0:003743:000512:000572:000578', '4', null, '凤城市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('579', 'mainland', '572', '0:003743:000512:000572:000579', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('580', 'mainland', '512', '0:003743:000512:000580', '3', '2107', '锦州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('581', 'mainland', '580', '0:003743:000512:000580:000581', '4', null, '古塔区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('582', 'mainland', '580', '0:003743:000512:000580:000582', '4', null, '凌河区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('583', 'mainland', '580', '0:003743:000512:000580:000583', '4', null, '太和区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('584', 'mainland', '580', '0:003743:000512:000580:000584', '4', null, '黑山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('585', 'mainland', '580', '0:003743:000512:000580:000585', '4', null, '义县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('586', 'mainland', '580', '0:003743:000512:000580:000586', '4', null, '凌海市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('587', 'mainland', '580', '0:003743:000512:000580:000587', '4', null, '北镇市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('588', 'mainland', '580', '0:003743:000512:000580:000588', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('589', 'mainland', '512', '0:003743:000512:000589', '3', '2108', '营口市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('590', 'mainland', '589', '0:003743:000512:000589:000590', '4', null, '站前区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('591', 'mainland', '589', '0:003743:000512:000589:000591', '4', null, '西市区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('592', 'mainland', '589', '0:003743:000512:000589:000592', '4', null, '鲅鱼圈区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('593', 'mainland', '589', '0:003743:000512:000589:000593', '4', null, '老边区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('594', 'mainland', '589', '0:003743:000512:000589:000594', '4', null, '盖州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('595', 'mainland', '589', '0:003743:000512:000589:000595', '4', null, '大石桥市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('596', 'mainland', '589', '0:003743:000512:000589:000596', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('597', 'mainland', '512', '0:003743:000512:000597', '3', '2109', '阜新市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('598', 'mainland', '597', '0:003743:000512:000597:000598', '4', null, '海州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('599', 'mainland', '597', '0:003743:000512:000597:000599', '4', null, '新邱区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('600', 'mainland', '597', '0:003743:000512:000597:000600', '4', null, '太平区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('601', 'mainland', '597', '0:003743:000512:000597:000601', '4', null, '清河门区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('602', 'mainland', '597', '0:003743:000512:000597:000602', '4', null, '细河区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('603', 'mainland', '597', '0:003743:000512:000597:000603', '4', null, '阜新蒙古族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('604', 'mainland', '597', '0:003743:000512:000597:000604', '4', null, '彰武县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('605', 'mainland', '597', '0:003743:000512:000597:000605', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('606', 'mainland', '512', '0:003743:000512:000606', '3', '606', '辽阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('607', 'mainland', '606', '0:003743:000512:000606:000607', '4', null, '白塔区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('608', 'mainland', '606', '0:003743:000512:000606:000608', '4', null, '文圣区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('609', 'mainland', '606', '0:003743:000512:000606:000609', '4', null, '宏伟区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('610', 'mainland', '606', '0:003743:000512:000606:000610', '4', null, '弓长岭区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('611', 'mainland', '606', '0:003743:000512:000606:000611', '4', null, '太子河区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('612', 'mainland', '606', '0:003743:000512:000606:000612', '4', null, '辽阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('613', 'mainland', '606', '0:003743:000512:000606:000613', '4', null, '灯塔市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('614', 'mainland', '606', '0:003743:000512:000606:000614', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('615', 'mainland', '512', '0:003743:000512:000615', '3', '2111', '盘锦市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('616', 'mainland', '615', '0:003743:000512:000615:000616', '4', null, '双台子区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('617', 'mainland', '615', '0:003743:000512:000615:000617', '4', null, '兴隆台区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('618', 'mainland', '615', '0:003743:000512:000615:000618', '4', null, '大洼县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('619', 'mainland', '615', '0:003743:000512:000615:000619', '4', null, '盘山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('620', 'mainland', '615', '0:003743:000512:000615:000620', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('621', 'mainland', '512', '0:003743:000512:000621', '3', '2112', '铁岭市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('622', 'mainland', '621', '0:003743:000512:000621:000622', '4', null, '银州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('623', 'mainland', '621', '0:003743:000512:000621:000623', '4', null, '清河区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('624', 'mainland', '621', '0:003743:000512:000621:000624', '4', null, '铁岭县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('625', 'mainland', '621', '0:003743:000512:000621:000625', '4', null, '西丰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('626', 'mainland', '621', '0:003743:000512:000621:000626', '4', null, '昌图县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('627', 'mainland', '621', '0:003743:000512:000621:000627', '4', null, '调兵山市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('628', 'mainland', '621', '0:003743:000512:000621:000628', '4', null, '开原市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('629', 'mainland', '621', '0:003743:000512:000621:000629', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('630', 'mainland', '512', '0:003743:000512:000630', '3', '2113', '朝阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('631', 'mainland', '630', '0:003743:000512:000630:000631', '4', null, '双塔区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('632', 'mainland', '630', '0:003743:000512:000630:000632', '4', null, '龙城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('633', 'mainland', '630', '0:003743:000512:000630:000633', '4', null, '朝阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('634', 'mainland', '630', '0:003743:000512:000630:000634', '4', null, '建平县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('635', 'mainland', '630', '0:003743:000512:000630:000635', '4', null, '喀喇沁左翼蒙古族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('636', 'mainland', '630', '0:003743:000512:000630:000636', '4', null, '北票市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('637', 'mainland', '630', '0:003743:000512:000630:000637', '4', null, '凌源市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('638', 'mainland', '630', '0:003743:000512:000630:000638', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('639', 'mainland', '512', '0:003743:000512:000639', '3', '2114', '葫芦岛市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('640', 'mainland', '639', '0:003743:000512:000639:000640', '4', null, '连山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('641', 'mainland', '639', '0:003743:000512:000639:000641', '4', null, '龙港区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('642', 'mainland', '639', '0:003743:000512:000639:000642', '4', null, '南票区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('643', 'mainland', '639', '0:003743:000512:000639:000643', '4', null, '绥中县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('644', 'mainland', '639', '0:003743:000512:000639:000644', '4', null, '建昌县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('645', 'mainland', '639', '0:003743:000512:000639:000645', '4', null, '兴城市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('646', 'mainland', '639', '0:003743:000512:000639:000646', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('647', 'mainland', '3743', '0:003743:000647', '2', null, '吉林省', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('648', 'mainland', '647', '0:003743:000647:000648', '3', '2201', '长春市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('649', 'mainland', '648', '0:003743:000647:000648:000649', '4', null, '南关区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('650', 'mainland', '648', '0:003743:000647:000648:000650', '4', null, '宽城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('651', 'mainland', '648', '0:003743:000647:000648:000651', '4', null, '朝阳区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('652', 'mainland', '648', '0:003743:000647:000648:000652', '4', null, '二道区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('653', 'mainland', '648', '0:003743:000647:000648:000653', '4', null, '绿园区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('654', 'mainland', '648', '0:003743:000647:000648:000654', '4', null, '双阳区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('655', 'mainland', '648', '0:003743:000647:000648:000655', '4', null, '农安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('656', 'mainland', '648', '0:003743:000647:000648:000656', '4', null, '九台市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('657', 'mainland', '648', '0:003743:000647:000648:000657', '4', null, '榆树市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('658', 'mainland', '648', '0:003743:000647:000648:000658', '4', null, '德惠市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('659', 'mainland', '648', '0:003743:000647:000648:000659', '4', null, '高新技术产业开发区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('660', 'mainland', '648', '0:003743:000647:000648:000660', '4', null, '汽车产业开发区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('661', 'mainland', '648', '0:003743:000647:000648:000661', '4', null, '经济技术开发区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('662', 'mainland', '648', '0:003743:000647:000648:000662', '4', null, '净月旅游开发区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('663', 'mainland', '648', '0:003743:000647:000648:000663', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('664', 'mainland', '647', '0:003743:000647:000664', '3', '2202', '吉林市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('665', 'mainland', '664', '0:003743:000647:000664:000665', '4', null, '昌邑区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('666', 'mainland', '664', '0:003743:000647:000664:000666', '4', null, '龙潭区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('667', 'mainland', '664', '0:003743:000647:000664:000667', '4', null, '船营区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('668', 'mainland', '664', '0:003743:000647:000664:000668', '4', null, '丰满区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('669', 'mainland', '664', '0:003743:000647:000664:000669', '4', null, '永吉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('670', 'mainland', '664', '0:003743:000647:000664:000670', '4', null, '蛟河市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('671', 'mainland', '664', '0:003743:000647:000664:000671', '4', null, '桦甸市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('672', 'mainland', '664', '0:003743:000647:000664:000672', '4', null, '舒兰市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('673', 'mainland', '664', '0:003743:000647:000664:000673', '4', null, '磐石市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('674', 'mainland', '664', '0:003743:000647:000664:000674', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('675', 'mainland', '647', '0:003743:000647:000675', '3', '2203', '四平市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('676', 'mainland', '675', '0:003743:000647:000675:000676', '4', null, '铁西区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('677', 'mainland', '675', '0:003743:000647:000675:000677', '4', null, '铁东区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('678', 'mainland', '675', '0:003743:000647:000675:000678', '4', null, '梨树县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('679', 'mainland', '675', '0:003743:000647:000675:000679', '4', null, '伊通满族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('680', 'mainland', '675', '0:003743:000647:000675:000680', '4', null, '公主岭市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('681', 'mainland', '675', '0:003743:000647:000675:000681', '4', null, '双辽市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('682', 'mainland', '675', '0:003743:000647:000675:000682', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('683', 'mainland', '647', '0:003743:000647:000683', '3', '2204', '辽源市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('684', 'mainland', '683', '0:003743:000647:000683:000684', '4', null, '龙山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('685', 'mainland', '683', '0:003743:000647:000683:000685', '4', null, '西安区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('686', 'mainland', '683', '0:003743:000647:000683:000686', '4', null, '东丰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('687', 'mainland', '683', '0:003743:000647:000683:000687', '4', null, '东辽县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('688', 'mainland', '683', '0:003743:000647:000683:000688', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('689', 'mainland', '647', '0:003743:000647:000689', '3', '2205', '通化市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('690', 'mainland', '689', '0:003743:000647:000689:000690', '4', null, '东昌区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('691', 'mainland', '689', '0:003743:000647:000689:000691', '4', null, '二道江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('692', 'mainland', '689', '0:003743:000647:000689:000692', '4', null, '通化县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('693', 'mainland', '689', '0:003743:000647:000689:000693', '4', null, '辉南县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('694', 'mainland', '689', '0:003743:000647:000689:000694', '4', null, '柳河县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('695', 'mainland', '689', '0:003743:000647:000689:000695', '4', null, '梅河口市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('696', 'mainland', '689', '0:003743:000647:000689:000696', '4', null, '集安市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('697', 'mainland', '689', '0:003743:000647:000689:000697', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('698', 'mainland', '647', '0:003743:000647:000698', '3', '2206', '白山市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('699', 'mainland', '698', '0:003743:000647:000698:000699', '4', null, '八道江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('700', 'mainland', '698', '0:003743:000647:000698:000700', '4', null, '抚松县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('701', 'mainland', '698', '0:003743:000647:000698:000701', '4', null, '靖宇县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('702', 'mainland', '698', '0:003743:000647:000698:000702', '4', null, '长白朝鲜族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('703', 'mainland', '698', '0:003743:000647:000698:000703', '4', null, '江源县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('704', 'mainland', '698', '0:003743:000647:000698:000704', '4', null, '临江市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('705', 'mainland', '698', '0:003743:000647:000698:000705', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('706', 'mainland', '647', '0:003743:000647:000706', '3', '2207', '松原市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('707', 'mainland', '706', '0:003743:000647:000706:000707', '4', null, '宁江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('708', 'mainland', '706', '0:003743:000647:000706:000708', '4', null, '前郭尔罗斯蒙古族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('709', 'mainland', '706', '0:003743:000647:000706:000709', '4', null, '长岭县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('710', 'mainland', '706', '0:003743:000647:000706:000710', '4', null, '乾安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('711', 'mainland', '706', '0:003743:000647:000706:000711', '4', null, '扶余县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('712', 'mainland', '706', '0:003743:000647:000706:000712', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('713', 'mainland', '647', '0:003743:000647:000713', '3', '2208', '白城市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('714', 'mainland', '713', '0:003743:000647:000713:000714', '4', null, '洮北区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('715', 'mainland', '713', '0:003743:000647:000713:000715', '4', null, '镇赉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('716', 'mainland', '713', '0:003743:000647:000713:000716', '4', null, '通榆县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('717', 'mainland', '713', '0:003743:000647:000713:000717', '4', null, '洮南市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('718', 'mainland', '713', '0:003743:000647:000713:000718', '4', null, '大安市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('719', 'mainland', '713', '0:003743:000647:000713:000719', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('720', 'mainland', '647', '0:003743:000647:000720', '3', '2224', '延边朝鲜族自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('721', 'mainland', '720', '0:003743:000647:000720:000721', '4', null, '延吉市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('722', 'mainland', '720', '0:003743:000647:000720:000722', '4', null, '图们市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('723', 'mainland', '720', '0:003743:000647:000720:000723', '4', null, '敦化市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('724', 'mainland', '720', '0:003743:000647:000720:000724', '4', null, '珲春市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('725', 'mainland', '720', '0:003743:000647:000720:000725', '4', null, '龙井市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('726', 'mainland', '720', '0:003743:000647:000720:000726', '4', null, '和龙市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('727', 'mainland', '720', '0:003743:000647:000720:000727', '4', null, '汪清县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('728', 'mainland', '720', '0:003743:000647:000720:000728', '4', null, '安图县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('729', 'mainland', '720', '0:003743:000647:000720:000729', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('730', 'mainland', '3743', '0:003743:000730', '2', null, '黑龙江省', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('731', 'mainland', '730', '0:003743:000730:000731', '3', '2301', '哈尔滨市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('732', 'mainland', '731', '0:003743:000730:000731:000732', '4', null, '道里区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('733', 'mainland', '731', '0:003743:000730:000731:000733', '4', null, '南岗区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('734', 'mainland', '731', '0:003743:000730:000731:000734', '4', null, '道外区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('735', 'mainland', '731', '0:003743:000730:000731:000735', '4', null, '香坊区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('736', 'mainland', '731', '0:003743:000730:000731:000736', '4', null, '动力区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('737', 'mainland', '731', '0:003743:000730:000731:000737', '4', null, '平房区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('738', 'mainland', '731', '0:003743:000730:000731:000738', '4', null, '松北区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('739', 'mainland', '731', '0:003743:000730:000731:000739', '4', null, '呼兰区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('740', 'mainland', '731', '0:003743:000730:000731:000740', '4', null, '依兰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('741', 'mainland', '731', '0:003743:000730:000731:000741', '4', null, '方正县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('742', 'mainland', '731', '0:003743:000730:000731:000742', '4', null, '宾县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('743', 'mainland', '731', '0:003743:000730:000731:000743', '4', null, '巴彦县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('744', 'mainland', '731', '0:003743:000730:000731:000744', '4', null, '木兰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('745', 'mainland', '731', '0:003743:000730:000731:000745', '4', null, '通河县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('746', 'mainland', '731', '0:003743:000730:000731:000746', '4', null, '延寿县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('747', 'mainland', '731', '0:003743:000730:000731:000747', '4', null, '阿城市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('748', 'mainland', '731', '0:003743:000730:000731:000748', '4', null, '双城市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('749', 'mainland', '731', '0:003743:000730:000731:000749', '4', null, '尚志市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('750', 'mainland', '731', '0:003743:000730:000731:000750', '4', null, '五常市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('751', 'mainland', '731', '0:003743:000730:000731:000751', '4', null, '阿城市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('752', 'mainland', '731', '0:003743:000730:000731:000752', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('753', 'mainland', '730', '0:003743:000730:000753', '3', '2302', '齐齐哈尔市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('754', 'mainland', '753', '0:003743:000730:000753:000754', '4', null, '龙沙区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('755', 'mainland', '753', '0:003743:000730:000753:000755', '4', null, '建华区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('756', 'mainland', '753', '0:003743:000730:000753:000756', '4', null, '铁锋区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('757', 'mainland', '753', '0:003743:000730:000753:000757', '4', null, '昂昂溪区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('758', 'mainland', '753', '0:003743:000730:000753:000758', '4', null, '富拉尔基区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('759', 'mainland', '753', '0:003743:000730:000753:000759', '4', null, '碾子山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('760', 'mainland', '753', '0:003743:000730:000753:000760', '4', null, '梅里斯达斡尔族区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('761', 'mainland', '753', '0:003743:000730:000753:000761', '4', null, '龙江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('762', 'mainland', '753', '0:003743:000730:000753:000762', '4', null, '依安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('763', 'mainland', '753', '0:003743:000730:000753:000763', '4', null, '泰来县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('764', 'mainland', '753', '0:003743:000730:000753:000764', '4', null, '甘南县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('765', 'mainland', '753', '0:003743:000730:000753:000765', '4', null, '富裕县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('766', 'mainland', '753', '0:003743:000730:000753:000766', '4', null, '克山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('767', 'mainland', '753', '0:003743:000730:000753:000767', '4', null, '克东县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('768', 'mainland', '753', '0:003743:000730:000753:000768', '4', null, '拜泉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('769', 'mainland', '753', '0:003743:000730:000753:000769', '4', null, '讷河市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('770', 'mainland', '753', '0:003743:000730:000753:000770', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('771', 'mainland', '730', '0:003743:000730:000771', '3', '2303', '鸡西市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('772', 'mainland', '771', '0:003743:000730:000771:000772', '4', null, '鸡冠区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('773', 'mainland', '771', '0:003743:000730:000771:000773', '4', null, '恒山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('774', 'mainland', '771', '0:003743:000730:000771:000774', '4', null, '滴道区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('775', 'mainland', '771', '0:003743:000730:000771:000775', '4', null, '梨树区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('776', 'mainland', '771', '0:003743:000730:000771:000776', '4', null, '城子河区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('777', 'mainland', '771', '0:003743:000730:000771:000777', '4', null, '麻山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('778', 'mainland', '771', '0:003743:000730:000771:000778', '4', null, '鸡东县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('779', 'mainland', '771', '0:003743:000730:000771:000779', '4', null, '虎林市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('780', 'mainland', '771', '0:003743:000730:000771:000780', '4', null, '密山市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('781', 'mainland', '771', '0:003743:000730:000771:000781', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('782', 'mainland', '730', '0:003743:000730:000782', '3', '2304', '鹤岗市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('783', 'mainland', '782', '0:003743:000730:000782:000783', '4', null, '向阳区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('784', 'mainland', '782', '0:003743:000730:000782:000784', '4', null, '工农区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('785', 'mainland', '782', '0:003743:000730:000782:000785', '4', null, '南山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('786', 'mainland', '782', '0:003743:000730:000782:000786', '4', null, '兴安区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('787', 'mainland', '782', '0:003743:000730:000782:000787', '4', null, '东山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('788', 'mainland', '782', '0:003743:000730:000782:000788', '4', null, '兴山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('789', 'mainland', '782', '0:003743:000730:000782:000789', '4', null, '萝北县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('790', 'mainland', '782', '0:003743:000730:000782:000790', '4', null, '绥滨县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('791', 'mainland', '782', '0:003743:000730:000782:000791', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('792', 'mainland', '730', '0:003743:000730:000792', '3', '2305', '双鸭山市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('793', 'mainland', '792', '0:003743:000730:000792:000793', '4', null, '尖山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('794', 'mainland', '792', '0:003743:000730:000792:000794', '4', null, '岭东区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('795', 'mainland', '792', '0:003743:000730:000792:000795', '4', null, '四方台区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('796', 'mainland', '792', '0:003743:000730:000792:000796', '4', null, '宝山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('797', 'mainland', '792', '0:003743:000730:000792:000797', '4', null, '集贤县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('798', 'mainland', '792', '0:003743:000730:000792:000798', '4', null, '友谊县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('799', 'mainland', '792', '0:003743:000730:000792:000799', '4', null, '宝清县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('800', 'mainland', '792', '0:003743:000730:000792:000800', '4', null, '饶河县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('801', 'mainland', '792', '0:003743:000730:000792:000801', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('802', 'mainland', '730', '0:003743:000730:000802', '3', '2306', '大庆市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('803', 'mainland', '802', '0:003743:000730:000802:000803', '4', null, '萨尔图区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('804', 'mainland', '802', '0:003743:000730:000802:000804', '4', null, '龙凤区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('805', 'mainland', '802', '0:003743:000730:000802:000805', '4', null, '让胡路区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('806', 'mainland', '802', '0:003743:000730:000802:000806', '4', null, '红岗区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('807', 'mainland', '802', '0:003743:000730:000802:000807', '4', null, '大同区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('808', 'mainland', '802', '0:003743:000730:000802:000808', '4', null, '肇州县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('809', 'mainland', '802', '0:003743:000730:000802:000809', '4', null, '肇源县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('810', 'mainland', '802', '0:003743:000730:000802:000810', '4', null, '林甸县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('811', 'mainland', '802', '0:003743:000730:000802:000811', '4', null, '杜尔伯特蒙古族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('812', 'mainland', '802', '0:003743:000730:000802:000812', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('813', 'mainland', '730', '0:003743:000730:000813', '3', '2307', '伊春市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('814', 'mainland', '813', '0:003743:000730:000813:000814', '4', null, '伊春区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('815', 'mainland', '813', '0:003743:000730:000813:000815', '4', null, '南岔区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('816', 'mainland', '813', '0:003743:000730:000813:000816', '4', null, '友好区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('817', 'mainland', '813', '0:003743:000730:000813:000817', '4', null, '西林区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('818', 'mainland', '813', '0:003743:000730:000813:000818', '4', null, '翠峦区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('819', 'mainland', '813', '0:003743:000730:000813:000819', '4', null, '新青区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('820', 'mainland', '813', '0:003743:000730:000813:000820', '4', null, '美溪区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('821', 'mainland', '813', '0:003743:000730:000813:000821', '4', null, '金山屯区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('822', 'mainland', '813', '0:003743:000730:000813:000822', '4', null, '五营区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('823', 'mainland', '813', '0:003743:000730:000813:000823', '4', null, '乌马河区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('824', 'mainland', '813', '0:003743:000730:000813:000824', '4', null, '汤旺河区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('825', 'mainland', '813', '0:003743:000730:000813:000825', '4', null, '带岭区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('826', 'mainland', '813', '0:003743:000730:000813:000826', '4', null, '乌伊岭区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('827', 'mainland', '813', '0:003743:000730:000813:000827', '4', null, '红星区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('828', 'mainland', '813', '0:003743:000730:000813:000828', '4', null, '上甘岭区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('829', 'mainland', '813', '0:003743:000730:000813:000829', '4', null, '嘉荫县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('830', 'mainland', '813', '0:003743:000730:000813:000830', '4', null, '铁力市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('831', 'mainland', '813', '0:003743:000730:000813:000831', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('832', 'mainland', '730', '0:003743:000730:000832', '3', '2308', '佳木斯市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('833', 'mainland', '832', '0:003743:000730:000832:000833', '4', null, '永红区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('834', 'mainland', '832', '0:003743:000730:000832:000834', '4', null, '向阳区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('835', 'mainland', '832', '0:003743:000730:000832:000835', '4', null, '前进区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('836', 'mainland', '832', '0:003743:000730:000832:000836', '4', null, '东风区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('837', 'mainland', '832', '0:003743:000730:000832:000837', '4', null, '郊区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('838', 'mainland', '832', '0:003743:000730:000832:000838', '4', null, '桦南县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('839', 'mainland', '832', '0:003743:000730:000832:000839', '4', null, '桦川县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('840', 'mainland', '832', '0:003743:000730:000832:000840', '4', null, '汤原县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('841', 'mainland', '832', '0:003743:000730:000832:000841', '4', null, '抚远县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('842', 'mainland', '832', '0:003743:000730:000832:000842', '4', null, '同江市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('843', 'mainland', '832', '0:003743:000730:000832:000843', '4', null, '富锦市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('844', 'mainland', '832', '0:003743:000730:000832:000844', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('845', 'mainland', '730', '0:003743:000730:000845', '3', '2309', '七台河市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('846', 'mainland', '845', '0:003743:000730:000845:000846', '4', null, '新兴区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('847', 'mainland', '845', '0:003743:000730:000845:000847', '4', null, '桃山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('848', 'mainland', '845', '0:003743:000730:000845:000848', '4', null, '茄子河区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('849', 'mainland', '845', '0:003743:000730:000845:000849', '4', null, '勃利县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('850', 'mainland', '845', '0:003743:000730:000845:000850', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('851', 'mainland', '730', '0:003743:000730:000851', '3', '851', '牡丹江市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('852', 'mainland', '851', '0:003743:000730:000851:000852', '4', null, '东安区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('853', 'mainland', '851', '0:003743:000730:000851:000853', '4', null, '阳明区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('854', 'mainland', '851', '0:003743:000730:000851:000854', '4', null, '爱民区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('855', 'mainland', '851', '0:003743:000730:000851:000855', '4', null, '西安区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('856', 'mainland', '851', '0:003743:000730:000851:000856', '4', null, '东宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('857', 'mainland', '851', '0:003743:000730:000851:000857', '4', null, '林口县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('858', 'mainland', '851', '0:003743:000730:000851:000858', '4', null, '绥芬河市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('859', 'mainland', '851', '0:003743:000730:000851:000859', '4', null, '海林市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('860', 'mainland', '851', '0:003743:000730:000851:000860', '4', null, '宁安市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('861', 'mainland', '851', '0:003743:000730:000851:000861', '4', null, '穆棱市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('862', 'mainland', '851', '0:003743:000730:000851:000862', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('863', 'mainland', '730', '0:003743:000730:000863', '3', '2311', '黑河市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('864', 'mainland', '863', '0:003743:000730:000863:000864', '4', null, '爱辉区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('865', 'mainland', '863', '0:003743:000730:000863:000865', '4', null, '嫩江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('866', 'mainland', '863', '0:003743:000730:000863:000866', '4', null, '逊克县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('867', 'mainland', '863', '0:003743:000730:000863:000867', '4', null, '孙吴县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('868', 'mainland', '863', '0:003743:000730:000863:000868', '4', null, '北安市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('869', 'mainland', '863', '0:003743:000730:000863:000869', '4', null, '五大连池市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('870', 'mainland', '863', '0:003743:000730:000863:000870', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('871', 'mainland', '730', '0:003743:000730:000871', '3', '2312', '绥化市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('872', 'mainland', '871', '0:003743:000730:000871:000872', '4', null, '北林区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('873', 'mainland', '871', '0:003743:000730:000871:000873', '4', null, '望奎县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('874', 'mainland', '871', '0:003743:000730:000871:000874', '4', null, '兰西县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('875', 'mainland', '871', '0:003743:000730:000871:000875', '4', null, '青冈县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('876', 'mainland', '871', '0:003743:000730:000871:000876', '4', null, '庆安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('877', 'mainland', '871', '0:003743:000730:000871:000877', '4', null, '明水县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('878', 'mainland', '871', '0:003743:000730:000871:000878', '4', null, '绥棱县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('879', 'mainland', '871', '0:003743:000730:000871:000879', '4', null, '安达市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('880', 'mainland', '871', '0:003743:000730:000871:000880', '4', null, '肇东市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('881', 'mainland', '871', '0:003743:000730:000871:000881', '4', null, '海伦市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('882', 'mainland', '871', '0:003743:000730:000871:000882', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('883', 'mainland', '730', '0:003743:000730:000883', '3', '2327', '大兴安岭地区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('884', 'mainland', '883', '0:003743:000730:000883:000884', '4', null, '呼玛县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('885', 'mainland', '883', '0:003743:000730:000883:000885', '4', null, '塔河县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('886', 'mainland', '883', '0:003743:000730:000883:000886', '4', null, '漠河县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('887', 'mainland', '883', '0:003743:000730:000883:000887', '4', null, '加格达奇区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('888', 'mainland', '883', '0:003743:000730:000883:000888', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('889', 'mainland', '3743', '0:003743:000889', '2', null, '上海', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('890', 'mainland', '889', '0:003743:000889:000890', '3', '3101', '上海市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('891', 'mainland', '890', '0:003743:000889:000890:000891', '4', null, '黄浦区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('892', 'mainland', '890', '0:003743:000889:000890:000892', '4', null, '卢湾区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('893', 'mainland', '890', '0:003743:000889:000890:000893', '4', null, '徐汇区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('894', 'mainland', '890', '0:003743:000889:000890:000894', '4', null, '长宁区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('895', 'mainland', '890', '0:003743:000889:000890:000895', '4', null, '静安区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('896', 'mainland', '890', '0:003743:000889:000890:000896', '4', null, '普陀区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('897', 'mainland', '890', '0:003743:000889:000890:000897', '4', null, '闸北区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('898', 'mainland', '890', '0:003743:000889:000890:000898', '4', null, '虹口区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('899', 'mainland', '890', '0:003743:000889:000890:000899', '4', null, '杨浦区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('900', 'mainland', '890', '0:003743:000889:000890:000900', '4', null, '闵行区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('901', 'mainland', '890', '0:003743:000889:000890:000901', '4', null, '宝山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('902', 'mainland', '890', '0:003743:000889:000890:000902', '4', null, '嘉定区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('903', 'mainland', '890', '0:003743:000889:000890:000903', '4', null, '浦东新区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('904', 'mainland', '890', '0:003743:000889:000890:000904', '4', null, '金山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('905', 'mainland', '890', '0:003743:000889:000890:000905', '4', null, '松江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('906', 'mainland', '890', '0:003743:000889:000890:000906', '4', null, '青浦区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('907', 'mainland', '890', '0:003743:000889:000890:000907', '4', null, '南汇区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('908', 'mainland', '890', '0:003743:000889:000890:000908', '4', null, '奉贤区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('909', 'mainland', '890', '0:003743:000889:000890:000909', '4', null, '川沙区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('910', 'mainland', '890', '0:003743:000889:000890:000910', '4', null, '崇明县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('911', 'mainland', '890', '0:003743:000889:000890:000911', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('912', 'mainland', '3743', '0:003743:000912', '2', null, '江苏省', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('913', 'mainland', '912', '0:003743:000912:000913', '3', '3201', '南京市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('914', 'mainland', '913', '0:003743:000912:000913:000914', '4', null, '玄武区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('915', 'mainland', '913', '0:003743:000912:000913:000915', '4', null, '白下区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('916', 'mainland', '913', '0:003743:000912:000913:000916', '4', null, '秦淮区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('917', 'mainland', '913', '0:003743:000912:000913:000917', '4', null, '建邺区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('918', 'mainland', '913', '0:003743:000912:000913:000918', '4', null, '鼓楼区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('919', 'mainland', '913', '0:003743:000912:000913:000919', '4', null, '下关区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('920', 'mainland', '913', '0:003743:000912:000913:000920', '4', null, '浦口区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('921', 'mainland', '913', '0:003743:000912:000913:000921', '4', null, '栖霞区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('922', 'mainland', '913', '0:003743:000912:000913:000922', '4', null, '雨花台区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('923', 'mainland', '913', '0:003743:000912:000913:000923', '4', null, '江宁区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('924', 'mainland', '913', '0:003743:000912:000913:000924', '4', null, '六合区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('925', 'mainland', '913', '0:003743:000912:000913:000925', '4', null, '溧水县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('926', 'mainland', '913', '0:003743:000912:000913:000926', '4', null, '高淳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('927', 'mainland', '913', '0:003743:000912:000913:000927', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('928', 'mainland', '912', '0:003743:000912:000928', '3', '3202', '无锡市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('929', 'mainland', '928', '0:003743:000912:000928:000929', '4', null, '崇安区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('930', 'mainland', '928', '0:003743:000912:000928:000930', '4', null, '南长区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('931', 'mainland', '928', '0:003743:000912:000928:000931', '4', null, '北塘区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('932', 'mainland', '928', '0:003743:000912:000928:000932', '4', null, '锡山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('933', 'mainland', '928', '0:003743:000912:000928:000933', '4', null, '惠山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('934', 'mainland', '928', '0:003743:000912:000928:000934', '4', null, '滨湖区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('935', 'mainland', '928', '0:003743:000912:000928:000935', '4', null, '江阴市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('936', 'mainland', '928', '0:003743:000912:000928:000936', '4', null, '宜兴市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('937', 'mainland', '928', '0:003743:000912:000928:000937', '4', null, '新区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('938', 'mainland', '928', '0:003743:000912:000928:000938', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('939', 'mainland', '912', '0:003743:000912:000939', '3', '3203', '徐州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('940', 'mainland', '939', '0:003743:000912:000939:000940', '4', null, '鼓楼区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('941', 'mainland', '939', '0:003743:000912:000939:000941', '4', null, '云龙区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('942', 'mainland', '939', '0:003743:000912:000939:000942', '4', null, '九里区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('943', 'mainland', '939', '0:003743:000912:000939:000943', '4', null, '贾汪区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('944', 'mainland', '939', '0:003743:000912:000939:000944', '4', null, '泉山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('945', 'mainland', '939', '0:003743:000912:000939:000945', '4', null, '丰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('946', 'mainland', '939', '0:003743:000912:000939:000946', '4', null, '沛县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('947', 'mainland', '939', '0:003743:000912:000939:000947', '4', null, '铜山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('948', 'mainland', '939', '0:003743:000912:000939:000948', '4', null, '睢宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('949', 'mainland', '939', '0:003743:000912:000939:000949', '4', null, '新沂市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('950', 'mainland', '939', '0:003743:000912:000939:000950', '4', null, '邳州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('951', 'mainland', '939', '0:003743:000912:000939:000951', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('952', 'mainland', '912', '0:003743:000912:000952', '3', '3204', '常州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('953', 'mainland', '952', '0:003743:000912:000952:000953', '4', null, '天宁区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('954', 'mainland', '952', '0:003743:000912:000952:000954', '4', null, '钟楼区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('955', 'mainland', '952', '0:003743:000912:000952:000955', '4', null, '戚墅堰区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('956', 'mainland', '952', '0:003743:000912:000952:000956', '4', null, '新北区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('957', 'mainland', '952', '0:003743:000912:000952:000957', '4', null, '武进区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('958', 'mainland', '952', '0:003743:000912:000952:000958', '4', null, '溧阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('959', 'mainland', '952', '0:003743:000912:000952:000959', '4', null, '金坛市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('960', 'mainland', '952', '0:003743:000912:000952:000960', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('961', 'mainland', '912', '0:003743:000912:000961', '3', '3205', '苏州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('962', 'mainland', '961', '0:003743:000912:000961:000962', '4', null, '沧浪区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('963', 'mainland', '961', '0:003743:000912:000961:000963', '4', null, '平江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('964', 'mainland', '961', '0:003743:000912:000961:000964', '4', null, '金阊区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('965', 'mainland', '961', '0:003743:000912:000961:000965', '4', null, '虎丘区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('966', 'mainland', '961', '0:003743:000912:000961:000966', '4', null, '吴中区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('967', 'mainland', '961', '0:003743:000912:000961:000967', '4', null, '相城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('968', 'mainland', '961', '0:003743:000912:000961:000968', '4', null, '常熟市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('969', 'mainland', '961', '0:003743:000912:000961:000969', '4', null, '张家港市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('970', 'mainland', '961', '0:003743:000912:000961:000970', '4', null, '昆山市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('971', 'mainland', '961', '0:003743:000912:000961:000971', '4', null, '吴江市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('972', 'mainland', '961', '0:003743:000912:000961:000972', '4', null, '太仓市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('973', 'mainland', '961', '0:003743:000912:000961:000973', '4', null, '新区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('974', 'mainland', '961', '0:003743:000912:000961:000974', '4', null, '园区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('975', 'mainland', '961', '0:003743:000912:000961:000975', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('976', 'mainland', '912', '0:003743:000912:000976', '3', '3206', '南通市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('977', 'mainland', '976', '0:003743:000912:000976:000977', '4', null, '崇川区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('978', 'mainland', '976', '0:003743:000912:000976:000978', '4', null, '港闸区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('979', 'mainland', '976', '0:003743:000912:000976:000979', '4', null, '通州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('980', 'mainland', '976', '0:003743:000912:000976:000980', '4', null, '海安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('981', 'mainland', '976', '0:003743:000912:000976:000981', '4', null, '如东县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('982', 'mainland', '976', '0:003743:000912:000976:000982', '4', null, '启东市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('983', 'mainland', '976', '0:003743:000912:000976:000983', '4', null, '如皋市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('984', 'mainland', '976', '0:003743:000912:000976:000984', '4', null, '通州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('985', 'mainland', '976', '0:003743:000912:000976:000985', '4', null, '海门市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('986', 'mainland', '976', '0:003743:000912:000976:000986', '4', null, '开发区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('987', 'mainland', '976', '0:003743:000912:000976:000987', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('988', 'mainland', '912', '0:003743:000912:000988', '3', '3207', '连云港市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('989', 'mainland', '988', '0:003743:000912:000988:000989', '4', null, '连云区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('990', 'mainland', '988', '0:003743:000912:000988:000990', '4', null, '新浦区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('991', 'mainland', '988', '0:003743:000912:000988:000991', '4', null, '海州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('992', 'mainland', '988', '0:003743:000912:000988:000992', '4', null, '赣榆县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('993', 'mainland', '988', '0:003743:000912:000988:000993', '4', null, '东海县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('994', 'mainland', '988', '0:003743:000912:000988:000994', '4', null, '灌云县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('995', 'mainland', '988', '0:003743:000912:000988:000995', '4', null, '灌南县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('996', 'mainland', '988', '0:003743:000912:000988:000996', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('997', 'mainland', '912', '0:003743:000912:000997', '3', '3208', '淮安市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('998', 'mainland', '997', '0:003743:000912:000997:000998', '4', null, '清河区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('999', 'mainland', '997', '0:003743:000912:000997:000999', '4', null, '楚州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1000', 'mainland', '997', '0:003743:000912:000997:001000', '4', null, '淮阴区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1001', 'mainland', '997', '0:003743:000912:000997:001001', '4', null, '清浦区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1002', 'mainland', '997', '0:003743:000912:000997:001002', '4', null, '涟水县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1003', 'mainland', '997', '0:003743:000912:000997:001003', '4', null, '洪泽县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1004', 'mainland', '997', '0:003743:000912:000997:001004', '4', null, '盱眙县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1005', 'mainland', '997', '0:003743:000912:000997:001005', '4', null, '金湖县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1006', 'mainland', '997', '0:003743:000912:000997:001006', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1007', 'mainland', '912', '0:003743:000912:001007', '3', '3209', '盐城市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1008', 'mainland', '1007', '0:003743:000912:001007:001008', '4', null, '亭湖区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1009', 'mainland', '1007', '0:003743:000912:001007:001009', '4', null, '盐都区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1010', 'mainland', '1007', '0:003743:000912:001007:001010', '4', null, '响水县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1011', 'mainland', '1007', '0:003743:000912:001007:001011', '4', null, '滨海县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1012', 'mainland', '1007', '0:003743:000912:001007:001012', '4', null, '阜宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1013', 'mainland', '1007', '0:003743:000912:001007:001013', '4', null, '射阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1014', 'mainland', '1007', '0:003743:000912:001007:001014', '4', null, '建湖县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1015', 'mainland', '1007', '0:003743:000912:001007:001015', '4', null, '东台市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1016', 'mainland', '1007', '0:003743:000912:001007:001016', '4', null, '大丰市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1017', 'mainland', '1007', '0:003743:000912:001007:001017', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1018', 'mainland', '912', '0:003743:000912:001018', '3', '1018', '扬州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1019', 'mainland', '1018', '0:003743:000912:001018:001019', '4', null, '广陵区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1020', 'mainland', '1018', '0:003743:000912:001018:001020', '4', null, '邗江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1021', 'mainland', '1018', '0:003743:000912:001018:001021', '4', null, '维扬区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1022', 'mainland', '1018', '0:003743:000912:001018:001022', '4', null, '宝应县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1023', 'mainland', '1018', '0:003743:000912:001018:001023', '4', null, '仪征市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1024', 'mainland', '1018', '0:003743:000912:001018:001024', '4', null, '高邮市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1025', 'mainland', '1018', '0:003743:000912:001018:001025', '4', null, '江都市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1026', 'mainland', '1018', '0:003743:000912:001018:001026', '4', null, '经济开发区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1027', 'mainland', '1018', '0:003743:000912:001018:001027', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1028', 'mainland', '912', '0:003743:000912:001028', '3', '3211', '镇江市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1029', 'mainland', '1028', '0:003743:000912:001028:001029', '4', null, '京口区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1030', 'mainland', '1028', '0:003743:000912:001028:001030', '4', null, '润州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1031', 'mainland', '1028', '0:003743:000912:001028:001031', '4', null, '丹徒区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1032', 'mainland', '1028', '0:003743:000912:001028:001032', '4', null, '丹阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1033', 'mainland', '1028', '0:003743:000912:001028:001033', '4', null, '扬中市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1034', 'mainland', '1028', '0:003743:000912:001028:001034', '4', null, '句容市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1035', 'mainland', '1028', '0:003743:000912:001028:001035', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1036', 'mainland', '912', '0:003743:000912:001036', '3', '3212', '泰州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1037', 'mainland', '1036', '0:003743:000912:001036:001037', '4', null, '海陵区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1038', 'mainland', '1036', '0:003743:000912:001036:001038', '4', null, '高港区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1039', 'mainland', '1036', '0:003743:000912:001036:001039', '4', null, '兴化市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1040', 'mainland', '1036', '0:003743:000912:001036:001040', '4', null, '靖江市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1041', 'mainland', '1036', '0:003743:000912:001036:001041', '4', null, '泰兴市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1042', 'mainland', '1036', '0:003743:000912:001036:001042', '4', null, '姜堰市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1043', 'mainland', '1036', '0:003743:000912:001036:001043', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1044', 'mainland', '912', '0:003743:000912:001044', '3', '3213', '宿迁市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1045', 'mainland', '1044', '0:003743:000912:001044:001045', '4', null, '宿城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1046', 'mainland', '1044', '0:003743:000912:001044:001046', '4', null, '宿豫区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1047', 'mainland', '1044', '0:003743:000912:001044:001047', '4', null, '沭阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1048', 'mainland', '1044', '0:003743:000912:001044:001048', '4', null, '泗阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1049', 'mainland', '1044', '0:003743:000912:001044:001049', '4', null, '泗洪县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1050', 'mainland', '1044', '0:003743:000912:001044:001050', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1051', 'mainland', '3743', '0:003743:001051', '2', null, '浙江省', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1052', 'mainland', '1051', '0:003743:001051:001052', '3', '3301', '杭州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1053', 'mainland', '1052', '0:003743:001051:001052:001053', '4', null, '上城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1054', 'mainland', '1052', '0:003743:001051:001052:001054', '4', null, '下城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1055', 'mainland', '1052', '0:003743:001051:001052:001055', '4', null, '江干区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1056', 'mainland', '1052', '0:003743:001051:001052:001056', '4', null, '拱墅区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1057', 'mainland', '1052', '0:003743:001051:001052:001057', '4', null, '西湖区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1058', 'mainland', '1052', '0:003743:001051:001052:001058', '4', null, '滨江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1059', 'mainland', '1052', '0:003743:001051:001052:001059', '4', null, '萧山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1060', 'mainland', '1052', '0:003743:001051:001052:001060', '4', null, '余杭区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1061', 'mainland', '1052', '0:003743:001051:001052:001061', '4', null, '桐庐县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1062', 'mainland', '1052', '0:003743:001051:001052:001062', '4', null, '淳安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1063', 'mainland', '1052', '0:003743:001051:001052:001063', '4', null, '建德市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1064', 'mainland', '1052', '0:003743:001051:001052:001064', '4', null, '富阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1065', 'mainland', '1052', '0:003743:001051:001052:001065', '4', null, '临安市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1066', 'mainland', '1052', '0:003743:001051:001052:001066', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1067', 'mainland', '1051', '0:003743:001051:001067', '3', '3302', '宁波市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1068', 'mainland', '1067', '0:003743:001051:001067:001068', '4', null, '海曙区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1069', 'mainland', '1067', '0:003743:001051:001067:001069', '4', null, '江东区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1070', 'mainland', '1067', '0:003743:001051:001067:001070', '4', null, '江北区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1071', 'mainland', '1067', '0:003743:001051:001067:001071', '4', null, '北仑区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1072', 'mainland', '1067', '0:003743:001051:001067:001072', '4', null, '镇海区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1073', 'mainland', '1067', '0:003743:001051:001067:001073', '4', null, '鄞州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1074', 'mainland', '1067', '0:003743:001051:001067:001074', '4', null, '象山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1075', 'mainland', '1067', '0:003743:001051:001067:001075', '4', null, '宁海县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1076', 'mainland', '1067', '0:003743:001051:001067:001076', '4', null, '余姚市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1077', 'mainland', '1067', '0:003743:001051:001067:001077', '4', null, '慈溪市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1078', 'mainland', '1067', '0:003743:001051:001067:001078', '4', null, '奉化市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1079', 'mainland', '1067', '0:003743:001051:001067:001079', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1080', 'mainland', '1051', '0:003743:001051:001080', '3', '3303', '温州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1081', 'mainland', '1080', '0:003743:001051:001080:001081', '4', null, '鹿城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1082', 'mainland', '1080', '0:003743:001051:001080:001082', '4', null, '龙湾区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1083', 'mainland', '1080', '0:003743:001051:001080:001083', '4', null, '瓯海区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1084', 'mainland', '1080', '0:003743:001051:001080:001084', '4', null, '洞头县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1085', 'mainland', '1080', '0:003743:001051:001080:001085', '4', null, '永嘉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1086', 'mainland', '1080', '0:003743:001051:001080:001086', '4', null, '平阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1087', 'mainland', '1080', '0:003743:001051:001080:001087', '4', null, '苍南县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1088', 'mainland', '1080', '0:003743:001051:001080:001088', '4', null, '文成县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1089', 'mainland', '1080', '0:003743:001051:001080:001089', '4', null, '泰顺县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1090', 'mainland', '1080', '0:003743:001051:001080:001090', '4', null, '瑞安市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1091', 'mainland', '1080', '0:003743:001051:001080:001091', '4', null, '乐清市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1092', 'mainland', '1080', '0:003743:001051:001080:001092', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1093', 'mainland', '1051', '0:003743:001051:001093', '3', '3304', '嘉兴市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1094', 'mainland', '1093', '0:003743:001051:001093:001094', '4', null, '南湖区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1095', 'mainland', '1093', '0:003743:001051:001093:001095', '4', null, '秀洲区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1096', 'mainland', '1093', '0:003743:001051:001093:001096', '4', null, '嘉善县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1097', 'mainland', '1093', '0:003743:001051:001093:001097', '4', null, '海盐县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1098', 'mainland', '1093', '0:003743:001051:001093:001098', '4', null, '海宁市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1099', 'mainland', '1093', '0:003743:001051:001093:001099', '4', null, '平湖市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1100', 'mainland', '1093', '0:003743:001051:001093:001100', '4', null, '桐乡市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1101', 'mainland', '1093', '0:003743:001051:001093:001101', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1102', 'mainland', '1051', '0:003743:001051:001102', '3', '3305', '湖州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1103', 'mainland', '1102', '0:003743:001051:001102:001103', '4', null, '吴兴区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1104', 'mainland', '1102', '0:003743:001051:001102:001104', '4', null, '南浔区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1105', 'mainland', '1102', '0:003743:001051:001102:001105', '4', null, '德清县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1106', 'mainland', '1102', '0:003743:001051:001102:001106', '4', null, '长兴县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1107', 'mainland', '1102', '0:003743:001051:001102:001107', '4', null, '安吉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1108', 'mainland', '1102', '0:003743:001051:001102:001108', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1109', 'mainland', '1051', '0:003743:001051:001109', '3', '3306', '绍兴市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1110', 'mainland', '1109', '0:003743:001051:001109:001110', '4', null, '越城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1111', 'mainland', '1109', '0:003743:001051:001109:001111', '4', null, '绍兴县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1112', 'mainland', '1109', '0:003743:001051:001109:001112', '4', null, '新昌县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1113', 'mainland', '1109', '0:003743:001051:001109:001113', '4', null, '诸暨市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1114', 'mainland', '1109', '0:003743:001051:001109:001114', '4', null, '上虞市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1115', 'mainland', '1109', '0:003743:001051:001109:001115', '4', null, '嵊州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1116', 'mainland', '1109', '0:003743:001051:001109:001116', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1117', 'mainland', '1051', '0:003743:001051:001117', '3', '3307', '金华市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1118', 'mainland', '1117', '0:003743:001051:001117:001118', '4', null, '婺城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1119', 'mainland', '1117', '0:003743:001051:001117:001119', '4', null, '金东区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1120', 'mainland', '1117', '0:003743:001051:001117:001120', '4', null, '武义县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1121', 'mainland', '1117', '0:003743:001051:001117:001121', '4', null, '浦江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1122', 'mainland', '1117', '0:003743:001051:001117:001122', '4', null, '磐安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1123', 'mainland', '1117', '0:003743:001051:001117:001123', '4', null, '兰溪市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1124', 'mainland', '1117', '0:003743:001051:001117:001124', '4', null, '义乌市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1125', 'mainland', '1117', '0:003743:001051:001117:001125', '4', null, '东阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1126', 'mainland', '1117', '0:003743:001051:001117:001126', '4', null, '永康市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1127', 'mainland', '1117', '0:003743:001051:001117:001127', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1128', 'mainland', '1051', '0:003743:001051:001128', '3', '3308', '衢州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1129', 'mainland', '1128', '0:003743:001051:001128:001129', '4', null, '柯城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1130', 'mainland', '1128', '0:003743:001051:001128:001130', '4', null, '衢江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1131', 'mainland', '1128', '0:003743:001051:001128:001131', '4', null, '常山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1132', 'mainland', '1128', '0:003743:001051:001128:001132', '4', null, '开化县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1133', 'mainland', '1128', '0:003743:001051:001128:001133', '4', null, '龙游县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1134', 'mainland', '1128', '0:003743:001051:001128:001134', '4', null, '江山市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1135', 'mainland', '1128', '0:003743:001051:001128:001135', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1136', 'mainland', '1051', '0:003743:001051:001136', '3', '3309', '舟山市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1137', 'mainland', '1136', '0:003743:001051:001136:001137', '4', null, '定海区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1138', 'mainland', '1136', '0:003743:001051:001136:001138', '4', null, '普陀区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1139', 'mainland', '1136', '0:003743:001051:001136:001139', '4', null, '岱山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1140', 'mainland', '1136', '0:003743:001051:001136:001140', '4', null, '嵊泗县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1141', 'mainland', '1136', '0:003743:001051:001136:001141', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1142', 'mainland', '1051', '0:003743:001051:001142', '3', '1142', '台州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1143', 'mainland', '1142', '0:003743:001051:001142:001143', '4', null, '椒江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1144', 'mainland', '1142', '0:003743:001051:001142:001144', '4', null, '黄岩区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1145', 'mainland', '1142', '0:003743:001051:001142:001145', '4', null, '路桥区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1146', 'mainland', '1142', '0:003743:001051:001142:001146', '4', null, '玉环县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1147', 'mainland', '1142', '0:003743:001051:001142:001147', '4', null, '三门县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1148', 'mainland', '1142', '0:003743:001051:001142:001148', '4', null, '天台县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1149', 'mainland', '1142', '0:003743:001051:001142:001149', '4', null, '仙居县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1150', 'mainland', '1142', '0:003743:001051:001142:001150', '4', null, '温岭市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1151', 'mainland', '1142', '0:003743:001051:001142:001151', '4', null, '临海市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1152', 'mainland', '1142', '0:003743:001051:001142:001152', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1153', 'mainland', '1051', '0:003743:001051:001153', '3', '3311', '丽水市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1154', 'mainland', '1153', '0:003743:001051:001153:001154', '4', null, '莲都区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1155', 'mainland', '1153', '0:003743:001051:001153:001155', '4', null, '青田县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1156', 'mainland', '1153', '0:003743:001051:001153:001156', '4', null, '缙云县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1157', 'mainland', '1153', '0:003743:001051:001153:001157', '4', null, '遂昌县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1158', 'mainland', '1153', '0:003743:001051:001153:001158', '4', null, '松阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1159', 'mainland', '1153', '0:003743:001051:001153:001159', '4', null, '云和县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1160', 'mainland', '1153', '0:003743:001051:001153:001160', '4', null, '庆元县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1161', 'mainland', '1153', '0:003743:001051:001153:001161', '4', null, '景宁畲族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1162', 'mainland', '1153', '0:003743:001051:001153:001162', '4', null, '龙泉市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1163', 'mainland', '1153', '0:003743:001051:001153:001163', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1164', 'mainland', '3743', '0:003743:001164', '2', null, '安徽省', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1165', 'mainland', '1164', '0:003743:001164:001165', '3', '3401', '合肥市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1166', 'mainland', '1165', '0:003743:001164:001165:001166', '4', null, '瑶海区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1167', 'mainland', '1165', '0:003743:001164:001165:001167', '4', null, '庐阳区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1168', 'mainland', '1165', '0:003743:001164:001165:001168', '4', null, '蜀山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1169', 'mainland', '1165', '0:003743:001164:001165:001169', '4', null, '包河区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1170', 'mainland', '1165', '0:003743:001164:001165:001170', '4', null, '长丰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1171', 'mainland', '1165', '0:003743:001164:001165:001171', '4', null, '肥东县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1172', 'mainland', '1165', '0:003743:001164:001165:001172', '4', null, '肥西县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1173', 'mainland', '1165', '0:003743:001164:001165:001173', '4', null, '高新区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1174', 'mainland', '1165', '0:003743:001164:001165:001174', '4', null, '中区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1175', 'mainland', '1165', '0:003743:001164:001165:001175', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1176', 'mainland', '1165', '0:003743:001164:001165:001176', '4', null, '巢湖市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1177', 'mainland', '1165', '0:003743:001164:001165:001177', '4', null, '居巢区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1178', 'mainland', '1165', '0:003743:001164:001165:001178', '4', null, '庐江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1179', 'mainland', '1164', '0:003743:001164:001179', '3', '3402', '芜湖市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1180', 'mainland', '1179', '0:003743:001164:001179:001180', '4', null, '镜湖区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1181', 'mainland', '1179', '0:003743:001164:001179:001181', '4', null, '弋江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1182', 'mainland', '1179', '0:003743:001164:001179:001182', '4', null, '鸠江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1183', 'mainland', '1179', '0:003743:001164:001179:001183', '4', null, '三山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1184', 'mainland', '1179', '0:003743:001164:001179:001184', '4', null, '芜湖县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1185', 'mainland', '1179', '0:003743:001164:001179:001185', '4', null, '繁昌县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1186', 'mainland', '1179', '0:003743:001164:001179:001186', '4', null, '南陵县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1187', 'mainland', '1179', '0:003743:001164:001179:001187', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1188', 'mainland', '1179', '0:003743:001164:001179:001188', '4', null, '无为县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1189', 'mainland', '1164', '0:003743:001164:001189', '3', '3403', '蚌埠市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1190', 'mainland', '1189', '0:003743:001164:001189:001190', '4', null, '龙子湖区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1191', 'mainland', '1189', '0:003743:001164:001189:001191', '4', null, '蚌山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1192', 'mainland', '1189', '0:003743:001164:001189:001192', '4', null, '禹会区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1193', 'mainland', '1189', '0:003743:001164:001189:001193', '4', null, '淮上区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1194', 'mainland', '1189', '0:003743:001164:001189:001194', '4', null, '怀远县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1195', 'mainland', '1189', '0:003743:001164:001189:001195', '4', null, '五河县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1196', 'mainland', '1189', '0:003743:001164:001189:001196', '4', null, '固镇县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1197', 'mainland', '1189', '0:003743:001164:001189:001197', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1198', 'mainland', '1164', '0:003743:001164:001198', '3', '3404', '淮南市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1199', 'mainland', '1198', '0:003743:001164:001198:001199', '4', null, '大通区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1200', 'mainland', '1198', '0:003743:001164:001198:001200', '4', null, '田家庵区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1201', 'mainland', '1198', '0:003743:001164:001198:001201', '4', null, '谢家集区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1202', 'mainland', '1198', '0:003743:001164:001198:001202', '4', null, '八公山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1203', 'mainland', '1198', '0:003743:001164:001198:001203', '4', null, '潘集区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1204', 'mainland', '1198', '0:003743:001164:001198:001204', '4', null, '凤台县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1205', 'mainland', '1198', '0:003743:001164:001198:001205', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1206', 'mainland', '1164', '0:003743:001164:001206', '3', '3405', '马鞍山市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1207', 'mainland', '1206', '0:003743:001164:001206:001207', '4', null, '金家庄区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1208', 'mainland', '1206', '0:003743:001164:001206:001208', '4', null, '花山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1209', 'mainland', '1206', '0:003743:001164:001206:001209', '4', null, '雨山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1210', 'mainland', '1206', '0:003743:001164:001206:001210', '4', null, '当涂县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1211', 'mainland', '1206', '0:003743:001164:001206:001211', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1212', 'mainland', '1206', '0:003743:001164:001206:001212', '4', null, '含山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1213', 'mainland', '1206', '0:003743:001164:001206:001213', '4', null, '和县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1214', 'mainland', '1164', '0:003743:001164:001214', '3', '3406', '淮北市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1215', 'mainland', '1214', '0:003743:001164:001214:001215', '4', null, '杜集区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1216', 'mainland', '1214', '0:003743:001164:001214:001216', '4', null, '相山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1217', 'mainland', '1214', '0:003743:001164:001214:001217', '4', null, '烈山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1218', 'mainland', '1214', '0:003743:001164:001214:001218', '4', null, '濉溪县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1219', 'mainland', '1214', '0:003743:001164:001214:001219', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1220', 'mainland', '1164', '0:003743:001164:001220', '3', '3407', '铜陵市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1221', 'mainland', '1220', '0:003743:001164:001220:001221', '4', null, '铜官山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1222', 'mainland', '1220', '0:003743:001164:001220:001222', '4', null, '狮子山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1223', 'mainland', '1220', '0:003743:001164:001220:001223', '4', null, '郊区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1224', 'mainland', '1220', '0:003743:001164:001220:001224', '4', null, '铜陵县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1225', 'mainland', '1220', '0:003743:001164:001220:001225', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1226', 'mainland', '1164', '0:003743:001164:001226', '3', '3408', '安庆市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1227', 'mainland', '1226', '0:003743:001164:001226:001227', '4', null, '迎江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1228', 'mainland', '1226', '0:003743:001164:001226:001228', '4', null, '大观区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1229', 'mainland', '1226', '0:003743:001164:001226:001229', '4', null, '宜秀区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1230', 'mainland', '1226', '0:003743:001164:001226:001230', '4', null, '怀宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1231', 'mainland', '1226', '0:003743:001164:001226:001231', '4', null, '枞阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1232', 'mainland', '1226', '0:003743:001164:001226:001232', '4', null, '潜山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1233', 'mainland', '1226', '0:003743:001164:001226:001233', '4', null, '太湖县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1234', 'mainland', '1226', '0:003743:001164:001226:001234', '4', null, '宿松县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1235', 'mainland', '1226', '0:003743:001164:001226:001235', '4', null, '望江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1236', 'mainland', '1226', '0:003743:001164:001226:001236', '4', null, '岳西县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1237', 'mainland', '1226', '0:003743:001164:001226:001237', '4', null, '桐城市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1238', 'mainland', '1226', '0:003743:001164:001226:001238', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1239', 'mainland', '1164', '0:003743:001164:001239', '3', '1239', '黄山市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1240', 'mainland', '1239', '0:003743:001164:001239:001240', '4', null, '屯溪区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1241', 'mainland', '1239', '0:003743:001164:001239:001241', '4', null, '黄山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1242', 'mainland', '1239', '0:003743:001164:001239:001242', '4', null, '徽州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1243', 'mainland', '1239', '0:003743:001164:001239:001243', '4', null, '歙县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1244', 'mainland', '1239', '0:003743:001164:001239:001244', '4', null, '休宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1245', 'mainland', '1239', '0:003743:001164:001239:001245', '4', null, '黟县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1246', 'mainland', '1239', '0:003743:001164:001239:001246', '4', null, '祁门县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1247', 'mainland', '1239', '0:003743:001164:001239:001247', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1248', 'mainland', '1164', '0:003743:001164:001248', '3', '3411', '滁州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1249', 'mainland', '1248', '0:003743:001164:001248:001249', '4', null, '琅琊区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1250', 'mainland', '1248', '0:003743:001164:001248:001250', '4', null, '南谯区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1251', 'mainland', '1248', '0:003743:001164:001248:001251', '4', null, '来安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1252', 'mainland', '1248', '0:003743:001164:001248:001252', '4', null, '全椒县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1253', 'mainland', '1248', '0:003743:001164:001248:001253', '4', null, '定远县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1254', 'mainland', '1248', '0:003743:001164:001248:001254', '4', null, '凤阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1255', 'mainland', '1248', '0:003743:001164:001248:001255', '4', null, '天长市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1256', 'mainland', '1248', '0:003743:001164:001248:001256', '4', null, '明光市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1257', 'mainland', '1248', '0:003743:001164:001248:001257', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1258', 'mainland', '1164', '0:003743:001164:001258', '3', '3412', '阜阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1259', 'mainland', '1258', '0:003743:001164:001258:001259', '4', null, '颍州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1260', 'mainland', '1258', '0:003743:001164:001258:001260', '4', null, '颍东区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1261', 'mainland', '1258', '0:003743:001164:001258:001261', '4', null, '颍泉区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1262', 'mainland', '1258', '0:003743:001164:001258:001262', '4', null, '临泉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1263', 'mainland', '1258', '0:003743:001164:001258:001263', '4', null, '太和县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1264', 'mainland', '1258', '0:003743:001164:001258:001264', '4', null, '阜南县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1265', 'mainland', '1258', '0:003743:001164:001258:001265', '4', null, '颍上县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1266', 'mainland', '1258', '0:003743:001164:001258:001266', '4', null, '界首市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1267', 'mainland', '1258', '0:003743:001164:001258:001267', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1268', 'mainland', '1164', '0:003743:001164:001268', '3', '3413', '宿州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1269', 'mainland', '1268', '0:003743:001164:001268:001269', '4', null, '埇桥区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1270', 'mainland', '1268', '0:003743:001164:001268:001270', '4', null, '砀山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1271', 'mainland', '1268', '0:003743:001164:001268:001271', '4', null, '萧县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1272', 'mainland', '1268', '0:003743:001164:001268:001272', '4', null, '灵璧县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1273', 'mainland', '1268', '0:003743:001164:001268:001273', '4', null, '泗县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1274', 'mainland', '1268', '0:003743:001164:001268:001274', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1275', 'mainland', '1164', '0:003743:001164:001275', '3', '3415', '六安市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1276', 'mainland', '1275', '0:003743:001164:001275:001276', '4', null, '金安区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1277', 'mainland', '1275', '0:003743:001164:001275:001277', '4', null, '裕安区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1278', 'mainland', '1275', '0:003743:001164:001275:001278', '4', null, '寿县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1279', 'mainland', '1275', '0:003743:001164:001275:001279', '4', null, '霍邱县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1280', 'mainland', '1275', '0:003743:001164:001275:001280', '4', null, '舒城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1281', 'mainland', '1275', '0:003743:001164:001275:001281', '4', null, '金寨县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1282', 'mainland', '1275', '0:003743:001164:001275:001282', '4', null, '霍山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1283', 'mainland', '1275', '0:003743:001164:001275:001283', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1284', 'mainland', '1164', '0:003743:001164:001284', '3', '3416', '亳州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1285', 'mainland', '1284', '0:003743:001164:001284:001285', '4', null, '谯城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1286', 'mainland', '1284', '0:003743:001164:001284:001286', '4', null, '涡阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1287', 'mainland', '1284', '0:003743:001164:001284:001287', '4', null, '蒙城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1288', 'mainland', '1284', '0:003743:001164:001284:001288', '4', null, '利辛县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1289', 'mainland', '1284', '0:003743:001164:001284:001289', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1290', 'mainland', '1164', '0:003743:001164:001290', '3', '3417', '池州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1291', 'mainland', '1290', '0:003743:001164:001290:001291', '4', null, '贵池区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1292', 'mainland', '1290', '0:003743:001164:001290:001292', '4', null, '东至县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1293', 'mainland', '1290', '0:003743:001164:001290:001293', '4', null, '石台县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1294', 'mainland', '1290', '0:003743:001164:001290:001294', '4', null, '青阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1295', 'mainland', '1290', '0:003743:001164:001290:001295', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1296', 'mainland', '1164', '0:003743:001164:001296', '3', '3418', '宣城市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1297', 'mainland', '1296', '0:003743:001164:001296:001297', '4', null, '宣州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1298', 'mainland', '1296', '0:003743:001164:001296:001298', '4', null, '郎溪县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1299', 'mainland', '1296', '0:003743:001164:001296:001299', '4', null, '广德县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1300', 'mainland', '1296', '0:003743:001164:001296:001300', '4', null, '泾县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1301', 'mainland', '1296', '0:003743:001164:001296:001301', '4', null, '绩溪县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1302', 'mainland', '1296', '0:003743:001164:001296:001302', '4', null, '旌德县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1303', 'mainland', '1296', '0:003743:001164:001296:001303', '4', null, '宁国市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1304', 'mainland', '1296', '0:003743:001164:001296:001304', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1305', 'mainland', '3743', '0:003743:001305', '2', null, '福建省', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1306', 'mainland', '1305', '0:003743:001305:001306', '3', '3501', '福州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1307', 'mainland', '1306', '0:003743:001305:001306:001307', '4', null, '鼓楼区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1308', 'mainland', '1306', '0:003743:001305:001306:001308', '4', null, '台江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1309', 'mainland', '1306', '0:003743:001305:001306:001309', '4', null, '仓山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1310', 'mainland', '1306', '0:003743:001305:001306:001310', '4', null, '马尾区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1311', 'mainland', '1306', '0:003743:001305:001306:001311', '4', null, '晋安区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1312', 'mainland', '1306', '0:003743:001305:001306:001312', '4', null, '闽侯县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1313', 'mainland', '1306', '0:003743:001305:001306:001313', '4', null, '连江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1314', 'mainland', '1306', '0:003743:001305:001306:001314', '4', null, '罗源县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1315', 'mainland', '1306', '0:003743:001305:001306:001315', '4', null, '闽清县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1316', 'mainland', '1306', '0:003743:001305:001306:001316', '4', null, '永泰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1317', 'mainland', '1306', '0:003743:001305:001306:001317', '4', null, '平潭县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1318', 'mainland', '1306', '0:003743:001305:001306:001318', '4', null, '福清市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1319', 'mainland', '1306', '0:003743:001305:001306:001319', '4', null, '长乐市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1320', 'mainland', '1306', '0:003743:001305:001306:001320', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1321', 'mainland', '1305', '0:003743:001305:001321', '3', '3502', '厦门市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1322', 'mainland', '1321', '0:003743:001305:001321:001322', '4', null, '思明区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1323', 'mainland', '1321', '0:003743:001305:001321:001323', '4', null, '海沧区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1324', 'mainland', '1321', '0:003743:001305:001321:001324', '4', null, '湖里区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1325', 'mainland', '1321', '0:003743:001305:001321:001325', '4', null, '集美区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1326', 'mainland', '1321', '0:003743:001305:001321:001326', '4', null, '同安区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1327', 'mainland', '1321', '0:003743:001305:001321:001327', '4', null, '翔安区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1328', 'mainland', '1321', '0:003743:001305:001321:001328', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1329', 'mainland', '1305', '0:003743:001305:001329', '3', '3503', '莆田市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1330', 'mainland', '1329', '0:003743:001305:001329:001330', '4', null, '城厢区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1331', 'mainland', '1329', '0:003743:001305:001329:001331', '4', null, '涵江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1332', 'mainland', '1329', '0:003743:001305:001329:001332', '4', null, '荔城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1333', 'mainland', '1329', '0:003743:001305:001329:001333', '4', null, '秀屿区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1334', 'mainland', '1329', '0:003743:001305:001329:001334', '4', null, '仙游县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1335', 'mainland', '1329', '0:003743:001305:001329:001335', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1336', 'mainland', '1305', '0:003743:001305:001336', '3', '3504', '三明市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1337', 'mainland', '1336', '0:003743:001305:001336:001337', '4', null, '梅列区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1338', 'mainland', '1336', '0:003743:001305:001336:001338', '4', null, '三元区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1339', 'mainland', '1336', '0:003743:001305:001336:001339', '4', null, '明溪县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1340', 'mainland', '1336', '0:003743:001305:001336:001340', '4', null, '清流县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1341', 'mainland', '1336', '0:003743:001305:001336:001341', '4', null, '宁化县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1342', 'mainland', '1336', '0:003743:001305:001336:001342', '4', null, '大田县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1343', 'mainland', '1336', '0:003743:001305:001336:001343', '4', null, '尤溪县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1344', 'mainland', '1336', '0:003743:001305:001336:001344', '4', null, '沙县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1345', 'mainland', '1336', '0:003743:001305:001336:001345', '4', null, '将乐县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1346', 'mainland', '1336', '0:003743:001305:001336:001346', '4', null, '泰宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1347', 'mainland', '1336', '0:003743:001305:001336:001347', '4', null, '建宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1348', 'mainland', '1336', '0:003743:001305:001336:001348', '4', null, '永安市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1349', 'mainland', '1336', '0:003743:001305:001336:001349', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1350', 'mainland', '1305', '0:003743:001305:001350', '3', '3505', '泉州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1351', 'mainland', '1350', '0:003743:001305:001350:001351', '4', null, '鲤城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1352', 'mainland', '1350', '0:003743:001305:001350:001352', '4', null, '丰泽区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1353', 'mainland', '1350', '0:003743:001305:001350:001353', '4', null, '洛江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1354', 'mainland', '1350', '0:003743:001305:001350:001354', '4', null, '泉港区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1355', 'mainland', '1350', '0:003743:001305:001350:001355', '4', null, '惠安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1356', 'mainland', '1350', '0:003743:001305:001350:001356', '4', null, '安溪县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1357', 'mainland', '1350', '0:003743:001305:001350:001357', '4', null, '永春县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1358', 'mainland', '1350', '0:003743:001305:001350:001358', '4', null, '德化县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1359', 'mainland', '1350', '0:003743:001305:001350:001359', '4', null, '金门县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1360', 'mainland', '1350', '0:003743:001305:001350:001360', '4', null, '石狮市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1361', 'mainland', '1350', '0:003743:001305:001350:001361', '4', null, '晋江市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1362', 'mainland', '1350', '0:003743:001305:001350:001362', '4', null, '南安市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1363', 'mainland', '1350', '0:003743:001305:001350:001363', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1364', 'mainland', '1305', '0:003743:001305:001364', '3', '3506', '漳州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1365', 'mainland', '1364', '0:003743:001305:001364:001365', '4', null, '芗城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1366', 'mainland', '1364', '0:003743:001305:001364:001366', '4', null, '龙文区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1367', 'mainland', '1364', '0:003743:001305:001364:001367', '4', null, '云霄县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1368', 'mainland', '1364', '0:003743:001305:001364:001368', '4', null, '漳浦县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1369', 'mainland', '1364', '0:003743:001305:001364:001369', '4', null, '诏安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1370', 'mainland', '1364', '0:003743:001305:001364:001370', '4', null, '长泰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1371', 'mainland', '1364', '0:003743:001305:001364:001371', '4', null, '东山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1372', 'mainland', '1364', '0:003743:001305:001364:001372', '4', null, '南靖县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1373', 'mainland', '1364', '0:003743:001305:001364:001373', '4', null, '平和县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1374', 'mainland', '1364', '0:003743:001305:001364:001374', '4', null, '华安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1375', 'mainland', '1364', '0:003743:001305:001364:001375', '4', null, '龙海市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1376', 'mainland', '1364', '0:003743:001305:001364:001376', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1377', 'mainland', '1305', '0:003743:001305:001377', '3', '3507', '南平市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1378', 'mainland', '1377', '0:003743:001305:001377:001378', '4', null, '延平区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1379', 'mainland', '1377', '0:003743:001305:001377:001379', '4', null, '顺昌县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1380', 'mainland', '1377', '0:003743:001305:001377:001380', '4', null, '浦城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1381', 'mainland', '1377', '0:003743:001305:001377:001381', '4', null, '光泽县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1382', 'mainland', '1377', '0:003743:001305:001377:001382', '4', null, '松溪县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1383', 'mainland', '1377', '0:003743:001305:001377:001383', '4', null, '政和县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1384', 'mainland', '1377', '0:003743:001305:001377:001384', '4', null, '邵武市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1385', 'mainland', '1377', '0:003743:001305:001377:001385', '4', null, '武夷山市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1386', 'mainland', '1377', '0:003743:001305:001377:001386', '4', null, '建瓯市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1387', 'mainland', '1377', '0:003743:001305:001377:001387', '4', null, '建阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1388', 'mainland', '1377', '0:003743:001305:001377:001388', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1389', 'mainland', '1305', '0:003743:001305:001389', '3', '3508', '龙岩市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1390', 'mainland', '1389', '0:003743:001305:001389:001390', '4', null, '新罗区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1391', 'mainland', '1389', '0:003743:001305:001389:001391', '4', null, '长汀县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1392', 'mainland', '1389', '0:003743:001305:001389:001392', '4', null, '永定县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1393', 'mainland', '1389', '0:003743:001305:001389:001393', '4', null, '上杭县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1394', 'mainland', '1389', '0:003743:001305:001389:001394', '4', null, '武平县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1395', 'mainland', '1389', '0:003743:001305:001389:001395', '4', null, '连城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1396', 'mainland', '1389', '0:003743:001305:001389:001396', '4', null, '漳平市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1397', 'mainland', '1389', '0:003743:001305:001389:001397', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1398', 'mainland', '1305', '0:003743:001305:001398', '3', '3509', '宁德市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1399', 'mainland', '1398', '0:003743:001305:001398:001399', '4', null, '蕉城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1400', 'mainland', '1398', '0:003743:001305:001398:001400', '4', null, '霞浦县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1401', 'mainland', '1398', '0:003743:001305:001398:001401', '4', null, '古田县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1402', 'mainland', '1398', '0:003743:001305:001398:001402', '4', null, '屏南县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1403', 'mainland', '1398', '0:003743:001305:001398:001403', '4', null, '寿宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1404', 'mainland', '1398', '0:003743:001305:001398:001404', '4', null, '周宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1405', 'mainland', '1398', '0:003743:001305:001398:001405', '4', null, '柘荣县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1406', 'mainland', '1398', '0:003743:001305:001398:001406', '4', null, '福安市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1407', 'mainland', '1398', '0:003743:001305:001398:001407', '4', null, '福鼎市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1408', 'mainland', '1398', '0:003743:001305:001398:001408', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1409', 'mainland', '3743', '0:003743:001409', '2', null, '江西省', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1410', 'mainland', '1409', '0:003743:001409:001410', '3', '3601', '南昌市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1411', 'mainland', '1410', '0:003743:001409:001410:001411', '4', null, '东湖区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1412', 'mainland', '1410', '0:003743:001409:001410:001412', '4', null, '西湖区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1413', 'mainland', '1410', '0:003743:001409:001410:001413', '4', null, '青云谱区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1414', 'mainland', '1410', '0:003743:001409:001410:001414', '4', null, '湾里区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1415', 'mainland', '1410', '0:003743:001409:001410:001415', '4', null, '青山湖区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1416', 'mainland', '1410', '0:003743:001409:001410:001416', '4', null, '南昌县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1417', 'mainland', '1410', '0:003743:001409:001410:001417', '4', null, '新建县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1418', 'mainland', '1410', '0:003743:001409:001410:001418', '4', null, '安义县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1419', 'mainland', '1410', '0:003743:001409:001410:001419', '4', null, '进贤县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1420', 'mainland', '1410', '0:003743:001409:001410:001420', '4', null, '红谷滩新区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1421', 'mainland', '1410', '0:003743:001409:001410:001421', '4', null, '经济技术开发区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1422', 'mainland', '1410', '0:003743:001409:001410:001422', '4', null, '昌北区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1423', 'mainland', '1410', '0:003743:001409:001410:001423', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1424', 'mainland', '1409', '0:003743:001409:001424', '3', '3602', '景德镇市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1425', 'mainland', '1424', '0:003743:001409:001424:001425', '4', null, '昌江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1426', 'mainland', '1424', '0:003743:001409:001424:001426', '4', null, '珠山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1427', 'mainland', '1424', '0:003743:001409:001424:001427', '4', null, '浮梁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1428', 'mainland', '1424', '0:003743:001409:001424:001428', '4', null, '乐平市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1429', 'mainland', '1424', '0:003743:001409:001424:001429', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1430', 'mainland', '1409', '0:003743:001409:001430', '3', '3603', '萍乡市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1431', 'mainland', '1430', '0:003743:001409:001430:001431', '4', null, '安源区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1432', 'mainland', '1430', '0:003743:001409:001430:001432', '4', null, '湘东区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1433', 'mainland', '1430', '0:003743:001409:001430:001433', '4', null, '莲花县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1434', 'mainland', '1430', '0:003743:001409:001430:001434', '4', null, '上栗县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1435', 'mainland', '1430', '0:003743:001409:001430:001435', '4', null, '芦溪县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1436', 'mainland', '1430', '0:003743:001409:001430:001436', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1437', 'mainland', '1409', '0:003743:001409:001437', '3', '3604', '九江市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1438', 'mainland', '1437', '0:003743:001409:001437:001438', '4', null, '庐山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1439', 'mainland', '1437', '0:003743:001409:001437:001439', '4', null, '浔阳区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1440', 'mainland', '1437', '0:003743:001409:001437:001440', '4', null, '九江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1441', 'mainland', '1437', '0:003743:001409:001437:001441', '4', null, '武宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1442', 'mainland', '1437', '0:003743:001409:001437:001442', '4', null, '修水县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1443', 'mainland', '1437', '0:003743:001409:001437:001443', '4', null, '永修县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1444', 'mainland', '1437', '0:003743:001409:001437:001444', '4', null, '德安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1445', 'mainland', '1437', '0:003743:001409:001437:001445', '4', null, '星子县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1446', 'mainland', '1437', '0:003743:001409:001437:001446', '4', null, '都昌县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1447', 'mainland', '1437', '0:003743:001409:001437:001447', '4', null, '湖口县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1448', 'mainland', '1437', '0:003743:001409:001437:001448', '4', null, '彭泽县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1449', 'mainland', '1437', '0:003743:001409:001437:001449', '4', null, '瑞昌市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1450', 'mainland', '1437', '0:003743:001409:001437:001450', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1451', 'mainland', '1409', '0:003743:001409:001451', '3', '3605', '新余市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1452', 'mainland', '1451', '0:003743:001409:001451:001452', '4', null, '渝水区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1453', 'mainland', '1451', '0:003743:001409:001451:001453', '4', null, '分宜县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1454', 'mainland', '1451', '0:003743:001409:001451:001454', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1455', 'mainland', '1409', '0:003743:001409:001455', '3', '3606', '鹰潭市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1456', 'mainland', '1455', '0:003743:001409:001455:001456', '4', null, '月湖区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1457', 'mainland', '1455', '0:003743:001409:001455:001457', '4', null, '余江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1458', 'mainland', '1455', '0:003743:001409:001455:001458', '4', null, '贵溪市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1459', 'mainland', '1455', '0:003743:001409:001455:001459', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1460', 'mainland', '1409', '0:003743:001409:001460', '3', '3607', '赣州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1461', 'mainland', '1460', '0:003743:001409:001460:001461', '4', null, '章贡区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1462', 'mainland', '1460', '0:003743:001409:001460:001462', '4', null, '赣县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1463', 'mainland', '1460', '0:003743:001409:001460:001463', '4', null, '信丰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1464', 'mainland', '1460', '0:003743:001409:001460:001464', '4', null, '大余县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1465', 'mainland', '1460', '0:003743:001409:001460:001465', '4', null, '上犹县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1466', 'mainland', '1460', '0:003743:001409:001460:001466', '4', null, '崇义县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1467', 'mainland', '1460', '0:003743:001409:001460:001467', '4', null, '安远县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1468', 'mainland', '1460', '0:003743:001409:001460:001468', '4', null, '龙南县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1469', 'mainland', '1460', '0:003743:001409:001460:001469', '4', null, '定南县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1470', 'mainland', '1460', '0:003743:001409:001460:001470', '4', null, '全南县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1471', 'mainland', '1460', '0:003743:001409:001460:001471', '4', null, '宁都县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1472', 'mainland', '1460', '0:003743:001409:001460:001472', '4', null, '于都县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1473', 'mainland', '1460', '0:003743:001409:001460:001473', '4', null, '兴国县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1474', 'mainland', '1460', '0:003743:001409:001460:001474', '4', null, '会昌县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1475', 'mainland', '1460', '0:003743:001409:001460:001475', '4', null, '寻乌县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1476', 'mainland', '1460', '0:003743:001409:001460:001476', '4', null, '石城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1477', 'mainland', '1460', '0:003743:001409:001460:001477', '4', null, '黄金区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1478', 'mainland', '1460', '0:003743:001409:001460:001478', '4', null, '瑞金市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1479', 'mainland', '1460', '0:003743:001409:001460:001479', '4', null, '南康市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1480', 'mainland', '1460', '0:003743:001409:001460:001480', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1481', 'mainland', '1409', '0:003743:001409:001481', '3', '3608', '吉安市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1482', 'mainland', '1481', '0:003743:001409:001481:001482', '4', null, '吉州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1483', 'mainland', '1481', '0:003743:001409:001481:001483', '4', null, '青原区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1484', 'mainland', '1481', '0:003743:001409:001481:001484', '4', null, '吉安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1485', 'mainland', '1481', '0:003743:001409:001481:001485', '4', null, '吉水县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1486', 'mainland', '1481', '0:003743:001409:001481:001486', '4', null, '峡江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1487', 'mainland', '1481', '0:003743:001409:001481:001487', '4', null, '新干县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1488', 'mainland', '1481', '0:003743:001409:001481:001488', '4', null, '永丰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1489', 'mainland', '1481', '0:003743:001409:001481:001489', '4', null, '泰和县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1490', 'mainland', '1481', '0:003743:001409:001481:001490', '4', null, '遂川县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1491', 'mainland', '1481', '0:003743:001409:001481:001491', '4', null, '万安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1492', 'mainland', '1481', '0:003743:001409:001481:001492', '4', null, '安福县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1493', 'mainland', '1481', '0:003743:001409:001481:001493', '4', null, '永新县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1494', 'mainland', '1481', '0:003743:001409:001481:001494', '4', null, '井冈山市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1495', 'mainland', '1481', '0:003743:001409:001481:001495', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1496', 'mainland', '1409', '0:003743:001409:001496', '3', '3609', '宜春市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1497', 'mainland', '1496', '0:003743:001409:001496:001497', '4', null, '袁州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1498', 'mainland', '1496', '0:003743:001409:001496:001498', '4', null, '奉新县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1499', 'mainland', '1496', '0:003743:001409:001496:001499', '4', null, '万载县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1500', 'mainland', '1496', '0:003743:001409:001496:001500', '4', null, '上高县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1501', 'mainland', '1496', '0:003743:001409:001496:001501', '4', null, '宜丰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1502', 'mainland', '1496', '0:003743:001409:001496:001502', '4', null, '靖安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1503', 'mainland', '1496', '0:003743:001409:001496:001503', '4', null, '铜鼓县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1504', 'mainland', '1496', '0:003743:001409:001496:001504', '4', null, '丰城市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1505', 'mainland', '1496', '0:003743:001409:001496:001505', '4', null, '樟树市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1506', 'mainland', '1496', '0:003743:001409:001496:001506', '4', null, '高安市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1507', 'mainland', '1496', '0:003743:001409:001496:001507', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1508', 'mainland', '1409', '0:003743:001409:001508', '3', '1508', '抚州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1509', 'mainland', '1508', '0:003743:001409:001508:001509', '4', null, '临川区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1510', 'mainland', '1508', '0:003743:001409:001508:001510', '4', null, '南城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1511', 'mainland', '1508', '0:003743:001409:001508:001511', '4', null, '黎川县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1512', 'mainland', '1508', '0:003743:001409:001508:001512', '4', null, '南丰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1513', 'mainland', '1508', '0:003743:001409:001508:001513', '4', null, '崇仁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1514', 'mainland', '1508', '0:003743:001409:001508:001514', '4', null, '乐安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1515', 'mainland', '1508', '0:003743:001409:001508:001515', '4', null, '宜黄县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1516', 'mainland', '1508', '0:003743:001409:001508:001516', '4', null, '金溪县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1517', 'mainland', '1508', '0:003743:001409:001508:001517', '4', null, '资溪县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1518', 'mainland', '1508', '0:003743:001409:001508:001518', '4', null, '东乡县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1519', 'mainland', '1508', '0:003743:001409:001508:001519', '4', null, '广昌县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1520', 'mainland', '1508', '0:003743:001409:001508:001520', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1521', 'mainland', '1409', '0:003743:001409:001521', '3', '3611', '上饶市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1522', 'mainland', '1521', '0:003743:001409:001521:001522', '4', null, '信州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1523', 'mainland', '1521', '0:003743:001409:001521:001523', '4', null, '上饶县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1524', 'mainland', '1521', '0:003743:001409:001521:001524', '4', null, '广丰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1525', 'mainland', '1521', '0:003743:001409:001521:001525', '4', null, '玉山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1526', 'mainland', '1521', '0:003743:001409:001521:001526', '4', null, '铅山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1527', 'mainland', '1521', '0:003743:001409:001521:001527', '4', null, '横峰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1528', 'mainland', '1521', '0:003743:001409:001521:001528', '4', null, '弋阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1529', 'mainland', '1521', '0:003743:001409:001521:001529', '4', null, '余干县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1530', 'mainland', '1521', '0:003743:001409:001521:001530', '4', null, '鄱阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1531', 'mainland', '1521', '0:003743:001409:001521:001531', '4', null, '万年县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1532', 'mainland', '1521', '0:003743:001409:001521:001532', '4', null, '婺源县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1533', 'mainland', '1521', '0:003743:001409:001521:001533', '4', null, '德兴市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1534', 'mainland', '1521', '0:003743:001409:001521:001534', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1535', 'mainland', '3743', '0:003743:001535', '2', null, '山东省', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1536', 'mainland', '1535', '0:003743:001535:001536', '3', '3701', '济南市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1537', 'mainland', '1536', '0:003743:001535:001536:001537', '4', null, '历下区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1538', 'mainland', '1536', '0:003743:001535:001536:001538', '4', null, '市中区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1539', 'mainland', '1536', '0:003743:001535:001536:001539', '4', null, '槐荫区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1540', 'mainland', '1536', '0:003743:001535:001536:001540', '4', null, '天桥区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1541', 'mainland', '1536', '0:003743:001535:001536:001541', '4', null, '历城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1542', 'mainland', '1536', '0:003743:001535:001536:001542', '4', null, '长清区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1543', 'mainland', '1536', '0:003743:001535:001536:001543', '4', null, '平阴县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1544', 'mainland', '1536', '0:003743:001535:001536:001544', '4', null, '济阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1545', 'mainland', '1536', '0:003743:001535:001536:001545', '4', null, '商河县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1546', 'mainland', '1536', '0:003743:001535:001536:001546', '4', null, '章丘市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1547', 'mainland', '1536', '0:003743:001535:001536:001547', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1548', 'mainland', '1535', '0:003743:001535:001548', '3', '3702', '青岛市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1549', 'mainland', '1548', '0:003743:001535:001548:001549', '4', null, '市南区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1550', 'mainland', '1548', '0:003743:001535:001548:001550', '4', null, '市北区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1551', 'mainland', '1548', '0:003743:001535:001548:001551', '4', null, '四方区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1552', 'mainland', '1548', '0:003743:001535:001548:001552', '4', null, '黄岛区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1553', 'mainland', '1548', '0:003743:001535:001548:001553', '4', null, '崂山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1554', 'mainland', '1548', '0:003743:001535:001548:001554', '4', null, '李沧区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1555', 'mainland', '1548', '0:003743:001535:001548:001555', '4', null, '城阳区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1556', 'mainland', '1548', '0:003743:001535:001548:001556', '4', null, '开发区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1557', 'mainland', '1548', '0:003743:001535:001548:001557', '4', null, '胶州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1558', 'mainland', '1548', '0:003743:001535:001548:001558', '4', null, '即墨市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1559', 'mainland', '1548', '0:003743:001535:001548:001559', '4', null, '平度市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1560', 'mainland', '1548', '0:003743:001535:001548:001560', '4', null, '胶南市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1561', 'mainland', '1548', '0:003743:001535:001548:001561', '4', null, '莱西市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1562', 'mainland', '1548', '0:003743:001535:001548:001562', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1563', 'mainland', '1535', '0:003743:001535:001563', '3', '3703', '淄博市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1564', 'mainland', '1563', '0:003743:001535:001563:001564', '4', null, '淄川区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1565', 'mainland', '1563', '0:003743:001535:001563:001565', '4', null, '张店区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1566', 'mainland', '1563', '0:003743:001535:001563:001566', '4', null, '博山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1567', 'mainland', '1563', '0:003743:001535:001563:001567', '4', null, '临淄区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1568', 'mainland', '1563', '0:003743:001535:001563:001568', '4', null, '周村区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1569', 'mainland', '1563', '0:003743:001535:001563:001569', '4', null, '桓台县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1570', 'mainland', '1563', '0:003743:001535:001563:001570', '4', null, '高青县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1571', 'mainland', '1563', '0:003743:001535:001563:001571', '4', null, '沂源县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1572', 'mainland', '1563', '0:003743:001535:001563:001572', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1573', 'mainland', '1535', '0:003743:001535:001573', '3', '3704', '枣庄市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1574', 'mainland', '1573', '0:003743:001535:001573:001574', '4', null, '市中区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1575', 'mainland', '1573', '0:003743:001535:001573:001575', '4', null, '薛城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1576', 'mainland', '1573', '0:003743:001535:001573:001576', '4', null, '峄城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1577', 'mainland', '1573', '0:003743:001535:001573:001577', '4', null, '台儿庄区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1578', 'mainland', '1573', '0:003743:001535:001573:001578', '4', null, '山亭区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1579', 'mainland', '1573', '0:003743:001535:001573:001579', '4', null, '滕州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1580', 'mainland', '1573', '0:003743:001535:001573:001580', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1581', 'mainland', '1535', '0:003743:001535:001581', '3', '3705', '东营市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1582', 'mainland', '1581', '0:003743:001535:001581:001582', '4', null, '东营区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1583', 'mainland', '1581', '0:003743:001535:001581:001583', '4', null, '河口区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1584', 'mainland', '1581', '0:003743:001535:001581:001584', '4', null, '垦利县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1585', 'mainland', '1581', '0:003743:001535:001581:001585', '4', null, '利津县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1586', 'mainland', '1581', '0:003743:001535:001581:001586', '4', null, '广饶县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1587', 'mainland', '1581', '0:003743:001535:001581:001587', '4', null, '西城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1588', 'mainland', '1581', '0:003743:001535:001581:001588', '4', null, '东城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1589', 'mainland', '1581', '0:003743:001535:001581:001589', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1590', 'mainland', '1535', '0:003743:001535:001590', '3', '3706', '烟台市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1591', 'mainland', '1590', '0:003743:001535:001590:001591', '4', null, '芝罘区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1592', 'mainland', '1590', '0:003743:001535:001590:001592', '4', null, '福山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1593', 'mainland', '1590', '0:003743:001535:001590:001593', '4', null, '牟平区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1594', 'mainland', '1590', '0:003743:001535:001590:001594', '4', null, '莱山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1595', 'mainland', '1590', '0:003743:001535:001590:001595', '4', null, '长岛县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1596', 'mainland', '1590', '0:003743:001535:001590:001596', '4', null, '龙口市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1597', 'mainland', '1590', '0:003743:001535:001590:001597', '4', null, '莱阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1598', 'mainland', '1590', '0:003743:001535:001590:001598', '4', null, '莱州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1599', 'mainland', '1590', '0:003743:001535:001590:001599', '4', null, '蓬莱市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1600', 'mainland', '1590', '0:003743:001535:001590:001600', '4', null, '招远市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1601', 'mainland', '1590', '0:003743:001535:001590:001601', '4', null, '栖霞市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1602', 'mainland', '1590', '0:003743:001535:001590:001602', '4', null, '海阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1603', 'mainland', '1590', '0:003743:001535:001590:001603', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1604', 'mainland', '1535', '0:003743:001535:001604', '3', '3707', '潍坊市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1605', 'mainland', '1604', '0:003743:001535:001604:001605', '4', null, '潍城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1606', 'mainland', '1604', '0:003743:001535:001604:001606', '4', null, '寒亭区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1607', 'mainland', '1604', '0:003743:001535:001604:001607', '4', null, '坊子区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1608', 'mainland', '1604', '0:003743:001535:001604:001608', '4', null, '奎文区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1609', 'mainland', '1604', '0:003743:001535:001604:001609', '4', null, '临朐县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1610', 'mainland', '1604', '0:003743:001535:001604:001610', '4', null, '昌乐县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1611', 'mainland', '1604', '0:003743:001535:001604:001611', '4', null, '开发区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1612', 'mainland', '1604', '0:003743:001535:001604:001612', '4', null, '青州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1613', 'mainland', '1604', '0:003743:001535:001604:001613', '4', null, '诸城市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1614', 'mainland', '1604', '0:003743:001535:001604:001614', '4', null, '寿光市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1615', 'mainland', '1604', '0:003743:001535:001604:001615', '4', null, '安丘市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1616', 'mainland', '1604', '0:003743:001535:001604:001616', '4', null, '高密市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1617', 'mainland', '1604', '0:003743:001535:001604:001617', '4', null, '昌邑市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1618', 'mainland', '1604', '0:003743:001535:001604:001618', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1619', 'mainland', '1535', '0:003743:001535:001619', '3', '3708', '济宁市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1620', 'mainland', '1619', '0:003743:001535:001619:001620', '4', null, '市中区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1621', 'mainland', '1619', '0:003743:001535:001619:001621', '4', null, '任城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1622', 'mainland', '1619', '0:003743:001535:001619:001622', '4', null, '微山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1623', 'mainland', '1619', '0:003743:001535:001619:001623', '4', null, '鱼台县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1624', 'mainland', '1619', '0:003743:001535:001619:001624', '4', null, '金乡县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1625', 'mainland', '1619', '0:003743:001535:001619:001625', '4', null, '嘉祥县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1626', 'mainland', '1619', '0:003743:001535:001619:001626', '4', null, '汶上县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1627', 'mainland', '1619', '0:003743:001535:001619:001627', '4', null, '泗水县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1628', 'mainland', '1619', '0:003743:001535:001619:001628', '4', null, '梁山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1629', 'mainland', '1619', '0:003743:001535:001619:001629', '4', null, '曲阜市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1630', 'mainland', '1619', '0:003743:001535:001619:001630', '4', null, '兖州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1631', 'mainland', '1619', '0:003743:001535:001619:001631', '4', null, '邹城市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1632', 'mainland', '1619', '0:003743:001535:001619:001632', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1633', 'mainland', '1535', '0:003743:001535:001633', '3', '3709', '泰安市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1634', 'mainland', '1633', '0:003743:001535:001633:001634', '4', null, '泰山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1635', 'mainland', '1633', '0:003743:001535:001633:001635', '4', null, '岱岳区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1636', 'mainland', '1633', '0:003743:001535:001633:001636', '4', null, '宁阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1637', 'mainland', '1633', '0:003743:001535:001633:001637', '4', null, '东平县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1638', 'mainland', '1633', '0:003743:001535:001633:001638', '4', null, '新泰市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1639', 'mainland', '1633', '0:003743:001535:001633:001639', '4', null, '肥城市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1640', 'mainland', '1633', '0:003743:001535:001633:001640', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1641', 'mainland', '1535', '0:003743:001535:001641', '3', '1641', '威海市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1642', 'mainland', '1641', '0:003743:001535:001641:001642', '4', null, '环翠区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1643', 'mainland', '1641', '0:003743:001535:001641:001643', '4', null, '文登市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1644', 'mainland', '1641', '0:003743:001535:001641:001644', '4', null, '荣成市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1645', 'mainland', '1641', '0:003743:001535:001641:001645', '4', null, '乳山市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1646', 'mainland', '1641', '0:003743:001535:001641:001646', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1647', 'mainland', '1535', '0:003743:001535:001647', '3', '3711', '日照市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1648', 'mainland', '1647', '0:003743:001535:001647:001648', '4', null, '东港区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1649', 'mainland', '1647', '0:003743:001535:001647:001649', '4', null, '岚山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1650', 'mainland', '1647', '0:003743:001535:001647:001650', '4', null, '五莲县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1651', 'mainland', '1647', '0:003743:001535:001647:001651', '4', null, '莒县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1652', 'mainland', '1647', '0:003743:001535:001647:001652', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1653', 'mainland', '1535', '0:003743:001535:001653', '3', '3712', '莱芜市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1654', 'mainland', '1653', '0:003743:001535:001653:001654', '4', null, '莱城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1655', 'mainland', '1653', '0:003743:001535:001653:001655', '4', null, '钢城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1656', 'mainland', '1653', '0:003743:001535:001653:001656', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1657', 'mainland', '1535', '0:003743:001535:001657', '3', '3713', '临沂市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1658', 'mainland', '1657', '0:003743:001535:001657:001658', '4', null, '兰山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1659', 'mainland', '1657', '0:003743:001535:001657:001659', '4', null, '罗庄区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1660', 'mainland', '1657', '0:003743:001535:001657:001660', '4', null, '河东区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1661', 'mainland', '1657', '0:003743:001535:001657:001661', '4', null, '沂南县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1662', 'mainland', '1657', '0:003743:001535:001657:001662', '4', null, '郯城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1663', 'mainland', '1657', '0:003743:001535:001657:001663', '4', null, '沂水县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1664', 'mainland', '1657', '0:003743:001535:001657:001664', '4', null, '苍山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1665', 'mainland', '1657', '0:003743:001535:001657:001665', '4', null, '费县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1666', 'mainland', '1657', '0:003743:001535:001657:001666', '4', null, '平邑县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1667', 'mainland', '1657', '0:003743:001535:001657:001667', '4', null, '莒南县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1668', 'mainland', '1657', '0:003743:001535:001657:001668', '4', null, '蒙阴县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1669', 'mainland', '1657', '0:003743:001535:001657:001669', '4', null, '临沭县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1670', 'mainland', '1657', '0:003743:001535:001657:001670', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1671', 'mainland', '1535', '0:003743:001535:001671', '3', '3714', '德州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1672', 'mainland', '1671', '0:003743:001535:001671:001672', '4', null, '德城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1673', 'mainland', '1671', '0:003743:001535:001671:001673', '4', null, '陵县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1674', 'mainland', '1671', '0:003743:001535:001671:001674', '4', null, '宁津县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1675', 'mainland', '1671', '0:003743:001535:001671:001675', '4', null, '庆云县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1676', 'mainland', '1671', '0:003743:001535:001671:001676', '4', null, '临邑县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1677', 'mainland', '1671', '0:003743:001535:001671:001677', '4', null, '齐河县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1678', 'mainland', '1671', '0:003743:001535:001671:001678', '4', null, '平原县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1679', 'mainland', '1671', '0:003743:001535:001671:001679', '4', null, '夏津县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1680', 'mainland', '1671', '0:003743:001535:001671:001680', '4', null, '武城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1681', 'mainland', '1671', '0:003743:001535:001671:001681', '4', null, '开发区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1682', 'mainland', '1671', '0:003743:001535:001671:001682', '4', null, '乐陵市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1683', 'mainland', '1671', '0:003743:001535:001671:001683', '4', null, '禹城市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1684', 'mainland', '1671', '0:003743:001535:001671:001684', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1685', 'mainland', '1535', '0:003743:001535:001685', '3', '3715', '聊城市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1686', 'mainland', '1685', '0:003743:001535:001685:001686', '4', null, '东昌府区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1687', 'mainland', '1685', '0:003743:001535:001685:001687', '4', null, '阳谷县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1688', 'mainland', '1685', '0:003743:001535:001685:001688', '4', null, '莘县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1689', 'mainland', '1685', '0:003743:001535:001685:001689', '4', null, '茌平县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1690', 'mainland', '1685', '0:003743:001535:001685:001690', '4', null, '东阿县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1691', 'mainland', '1685', '0:003743:001535:001685:001691', '4', null, '冠县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1692', 'mainland', '1685', '0:003743:001535:001685:001692', '4', null, '高唐县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1693', 'mainland', '1685', '0:003743:001535:001685:001693', '4', null, '临清市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1694', 'mainland', '1685', '0:003743:001535:001685:001694', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1695', 'mainland', '1535', '0:003743:001535:001695', '3', '3716', '滨州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1696', 'mainland', '1695', '0:003743:001535:001695:001696', '4', null, '滨城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1697', 'mainland', '1695', '0:003743:001535:001695:001697', '4', null, '惠民县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1698', 'mainland', '1695', '0:003743:001535:001695:001698', '4', null, '阳信县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1699', 'mainland', '1695', '0:003743:001535:001695:001699', '4', null, '无棣县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1700', 'mainland', '1695', '0:003743:001535:001695:001700', '4', null, '沾化县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1701', 'mainland', '1695', '0:003743:001535:001695:001701', '4', null, '博兴县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1702', 'mainland', '1695', '0:003743:001535:001695:001702', '4', null, '邹平县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1703', 'mainland', '1695', '0:003743:001535:001695:001703', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1704', 'mainland', '1535', '0:003743:001535:001704', '3', '3717', '菏泽市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1705', 'mainland', '1704', '0:003743:001535:001704:001705', '4', null, '牡丹区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1706', 'mainland', '1704', '0:003743:001535:001704:001706', '4', null, '曹县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1707', 'mainland', '1704', '0:003743:001535:001704:001707', '4', null, '单县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1708', 'mainland', '1704', '0:003743:001535:001704:001708', '4', null, '成武县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1709', 'mainland', '1704', '0:003743:001535:001704:001709', '4', null, '巨野县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1710', 'mainland', '1704', '0:003743:001535:001704:001710', '4', null, '郓城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1711', 'mainland', '1704', '0:003743:001535:001704:001711', '4', null, '鄄城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1712', 'mainland', '1704', '0:003743:001535:001704:001712', '4', null, '定陶县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1713', 'mainland', '1704', '0:003743:001535:001704:001713', '4', null, '东明县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1714', 'mainland', '1704', '0:003743:001535:001704:001714', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1715', 'mainland', '3743', '0:003743:001715', '2', null, '河南省', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1716', 'mainland', '1715', '0:003743:001715:001716', '3', '4101', '郑州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1717', 'mainland', '1716', '0:003743:001715:001716:001717', '4', null, '中原区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1718', 'mainland', '1716', '0:003743:001715:001716:001718', '4', null, '二七区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1719', 'mainland', '1716', '0:003743:001715:001716:001719', '4', null, '管城回族区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1720', 'mainland', '1716', '0:003743:001715:001716:001720', '4', null, '金水区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1721', 'mainland', '1716', '0:003743:001715:001716:001721', '4', null, '上街区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1722', 'mainland', '1716', '0:003743:001715:001716:001722', '4', null, '惠济区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1723', 'mainland', '1716', '0:003743:001715:001716:001723', '4', null, '中牟县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1724', 'mainland', '1716', '0:003743:001715:001716:001724', '4', null, '巩义市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1725', 'mainland', '1716', '0:003743:001715:001716:001725', '4', null, '荥阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1726', 'mainland', '1716', '0:003743:001715:001716:001726', '4', null, '新密市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1727', 'mainland', '1716', '0:003743:001715:001716:001727', '4', null, '新郑市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1728', 'mainland', '1716', '0:003743:001715:001716:001728', '4', null, '登封市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1729', 'mainland', '1716', '0:003743:001715:001716:001729', '4', null, '郑东新区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1730', 'mainland', '1716', '0:003743:001715:001716:001730', '4', null, '高新区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1731', 'mainland', '1716', '0:003743:001715:001716:001731', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1732', 'mainland', '1715', '0:003743:001715:001732', '3', '4102', '开封市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1733', 'mainland', '1732', '0:003743:001715:001732:001733', '4', null, '龙亭区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1734', 'mainland', '1732', '0:003743:001715:001732:001734', '4', null, '顺河回族区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1735', 'mainland', '1732', '0:003743:001715:001732:001735', '4', null, '鼓楼区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1736', 'mainland', '1732', '0:003743:001715:001732:001736', '4', null, '禹王台区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1737', 'mainland', '1732', '0:003743:001715:001732:001737', '4', null, '金明区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1738', 'mainland', '1732', '0:003743:001715:001732:001738', '4', null, '杞县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1739', 'mainland', '1732', '0:003743:001715:001732:001739', '4', null, '通许县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1740', 'mainland', '1732', '0:003743:001715:001732:001740', '4', null, '尉氏县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1741', 'mainland', '1732', '0:003743:001715:001732:001741', '4', null, '开封县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1742', 'mainland', '1732', '0:003743:001715:001732:001742', '4', null, '兰考县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1743', 'mainland', '1732', '0:003743:001715:001732:001743', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1744', 'mainland', '1715', '0:003743:001715:001744', '3', '4103', '洛阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1745', 'mainland', '1744', '0:003743:001715:001744:001745', '4', null, '老城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1746', 'mainland', '1744', '0:003743:001715:001744:001746', '4', null, '西工区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1747', 'mainland', '1744', '0:003743:001715:001744:001747', '4', null, '廛河回族区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1748', 'mainland', '1744', '0:003743:001715:001744:001748', '4', null, '涧西区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1749', 'mainland', '1744', '0:003743:001715:001744:001749', '4', null, '吉利区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1750', 'mainland', '1744', '0:003743:001715:001744:001750', '4', null, '洛龙区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1751', 'mainland', '1744', '0:003743:001715:001744:001751', '4', null, '孟津县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1752', 'mainland', '1744', '0:003743:001715:001744:001752', '4', null, '新安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1753', 'mainland', '1744', '0:003743:001715:001744:001753', '4', null, '栾川县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1754', 'mainland', '1744', '0:003743:001715:001744:001754', '4', null, '嵩县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1755', 'mainland', '1744', '0:003743:001715:001744:001755', '4', null, '汝阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1756', 'mainland', '1744', '0:003743:001715:001744:001756', '4', null, '宜阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1757', 'mainland', '1744', '0:003743:001715:001744:001757', '4', null, '洛宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1758', 'mainland', '1744', '0:003743:001715:001744:001758', '4', null, '伊川县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1759', 'mainland', '1744', '0:003743:001715:001744:001759', '4', null, '偃师市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1760', 'mainland', '1744', '0:003743:001715:001744:001760', '4', null, '高新区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1761', 'mainland', '1744', '0:003743:001715:001744:001761', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1762', 'mainland', '1715', '0:003743:001715:001762', '3', '4104', '平顶山市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1763', 'mainland', '1762', '0:003743:001715:001762:001763', '4', null, '新华区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1764', 'mainland', '1762', '0:003743:001715:001762:001764', '4', null, '卫东区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1765', 'mainland', '1762', '0:003743:001715:001762:001765', '4', null, '石龙区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1766', 'mainland', '1762', '0:003743:001715:001762:001766', '4', null, '湛河区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1767', 'mainland', '1762', '0:003743:001715:001762:001767', '4', null, '宝丰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1768', 'mainland', '1762', '0:003743:001715:001762:001768', '4', null, '叶县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1769', 'mainland', '1762', '0:003743:001715:001762:001769', '4', null, '鲁山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1770', 'mainland', '1762', '0:003743:001715:001762:001770', '4', null, '郏县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1771', 'mainland', '1762', '0:003743:001715:001762:001771', '4', null, '舞钢市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1772', 'mainland', '1762', '0:003743:001715:001762:001772', '4', null, '汝州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1773', 'mainland', '1762', '0:003743:001715:001762:001773', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1774', 'mainland', '1715', '0:003743:001715:001774', '3', '4105', '安阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1775', 'mainland', '1774', '0:003743:001715:001774:001775', '4', null, '文峰区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1776', 'mainland', '1774', '0:003743:001715:001774:001776', '4', null, '北关区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1777', 'mainland', '1774', '0:003743:001715:001774:001777', '4', null, '殷都区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1778', 'mainland', '1774', '0:003743:001715:001774:001778', '4', null, '龙安区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1779', 'mainland', '1774', '0:003743:001715:001774:001779', '4', null, '安阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1780', 'mainland', '1774', '0:003743:001715:001774:001780', '4', null, '汤阴县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1781', 'mainland', '1774', '0:003743:001715:001774:001781', '4', null, '滑县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1782', 'mainland', '1774', '0:003743:001715:001774:001782', '4', null, '内黄县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1783', 'mainland', '1774', '0:003743:001715:001774:001783', '4', null, '林州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1784', 'mainland', '1774', '0:003743:001715:001774:001784', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1785', 'mainland', '1715', '0:003743:001715:001785', '3', '4106', '鹤壁市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1786', 'mainland', '1785', '0:003743:001715:001785:001786', '4', null, '鹤山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1787', 'mainland', '1785', '0:003743:001715:001785:001787', '4', null, '山城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1788', 'mainland', '1785', '0:003743:001715:001785:001788', '4', null, '淇滨区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1789', 'mainland', '1785', '0:003743:001715:001785:001789', '4', null, '浚县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1790', 'mainland', '1785', '0:003743:001715:001785:001790', '4', null, '淇县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1791', 'mainland', '1785', '0:003743:001715:001785:001791', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1792', 'mainland', '1715', '0:003743:001715:001792', '3', '4107', '新乡市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1793', 'mainland', '1792', '0:003743:001715:001792:001793', '4', null, '红旗区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1794', 'mainland', '1792', '0:003743:001715:001792:001794', '4', null, '卫滨区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1795', 'mainland', '1792', '0:003743:001715:001792:001795', '4', null, '凤泉区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1796', 'mainland', '1792', '0:003743:001715:001792:001796', '4', null, '牧野区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1797', 'mainland', '1792', '0:003743:001715:001792:001797', '4', null, '新乡县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1798', 'mainland', '1792', '0:003743:001715:001792:001798', '4', null, '获嘉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1799', 'mainland', '1792', '0:003743:001715:001792:001799', '4', null, '原阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1800', 'mainland', '1792', '0:003743:001715:001792:001800', '4', null, '延津县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1801', 'mainland', '1792', '0:003743:001715:001792:001801', '4', null, '封丘县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1802', 'mainland', '1792', '0:003743:001715:001792:001802', '4', null, '长垣县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1803', 'mainland', '1792', '0:003743:001715:001792:001803', '4', null, '卫辉市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1804', 'mainland', '1792', '0:003743:001715:001792:001804', '4', null, '辉县市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1805', 'mainland', '1792', '0:003743:001715:001792:001805', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1806', 'mainland', '1715', '0:003743:001715:001806', '3', '4108', '焦作市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1807', 'mainland', '1806', '0:003743:001715:001806:001807', '4', null, '解放区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1808', 'mainland', '1806', '0:003743:001715:001806:001808', '4', null, '中站区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1809', 'mainland', '1806', '0:003743:001715:001806:001809', '4', null, '马村区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1810', 'mainland', '1806', '0:003743:001715:001806:001810', '4', null, '山阳区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1811', 'mainland', '1806', '0:003743:001715:001806:001811', '4', null, '修武县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1812', 'mainland', '1806', '0:003743:001715:001806:001812', '4', null, '博爱县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1813', 'mainland', '1806', '0:003743:001715:001806:001813', '4', null, '武陟县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1814', 'mainland', '1806', '0:003743:001715:001806:001814', '4', null, '温县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1815', 'mainland', '1806', '0:003743:001715:001806:001815', '4', null, '沁阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1816', 'mainland', '1806', '0:003743:001715:001806:001816', '4', null, '孟州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1817', 'mainland', '1806', '0:003743:001715:001806:001817', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1818', 'mainland', '1715', '0:003743:001715:001818', '3', '1818', '济源市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1819', 'mainland', '1715', '0:003743:001715:001819', '3', '4109', '濮阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1820', 'mainland', '1819', '0:003743:001715:001819:001820', '4', null, '华龙区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1821', 'mainland', '1819', '0:003743:001715:001819:001821', '4', null, '清丰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1822', 'mainland', '1819', '0:003743:001715:001819:001822', '4', null, '南乐县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1823', 'mainland', '1819', '0:003743:001715:001819:001823', '4', null, '范县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1824', 'mainland', '1819', '0:003743:001715:001819:001824', '4', null, '台前县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1825', 'mainland', '1819', '0:003743:001715:001819:001825', '4', null, '濮阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1826', 'mainland', '1819', '0:003743:001715:001819:001826', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1827', 'mainland', '1715', '0:003743:001715:001827', '3', '1827', '许昌市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1828', 'mainland', '1827', '0:003743:001715:001827:001828', '4', null, '魏都区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1829', 'mainland', '1827', '0:003743:001715:001827:001829', '4', null, '许昌县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1830', 'mainland', '1827', '0:003743:001715:001827:001830', '4', null, '鄢陵县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1831', 'mainland', '1827', '0:003743:001715:001827:001831', '4', null, '襄城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1832', 'mainland', '1827', '0:003743:001715:001827:001832', '4', null, '禹州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1833', 'mainland', '1827', '0:003743:001715:001827:001833', '4', null, '长葛市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1834', 'mainland', '1827', '0:003743:001715:001827:001834', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1835', 'mainland', '1715', '0:003743:001715:001835', '3', '4111', '漯河市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1836', 'mainland', '1835', '0:003743:001715:001835:001836', '4', null, '源汇区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1837', 'mainland', '1835', '0:003743:001715:001835:001837', '4', null, '郾城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1838', 'mainland', '1835', '0:003743:001715:001835:001838', '4', null, '召陵区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1839', 'mainland', '1835', '0:003743:001715:001835:001839', '4', null, '舞阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1840', 'mainland', '1835', '0:003743:001715:001835:001840', '4', null, '临颍县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1841', 'mainland', '1835', '0:003743:001715:001835:001841', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1842', 'mainland', '1715', '0:003743:001715:001842', '3', '4112', '三门峡市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1843', 'mainland', '1842', '0:003743:001715:001842:001843', '4', null, '湖滨区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1844', 'mainland', '1842', '0:003743:001715:001842:001844', '4', null, '渑池县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1845', 'mainland', '1842', '0:003743:001715:001842:001845', '4', null, '陕县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1846', 'mainland', '1842', '0:003743:001715:001842:001846', '4', null, '卢氏县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1847', 'mainland', '1842', '0:003743:001715:001842:001847', '4', null, '义马市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1848', 'mainland', '1842', '0:003743:001715:001842:001848', '4', null, '灵宝市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1849', 'mainland', '1842', '0:003743:001715:001842:001849', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1850', 'mainland', '1715', '0:003743:001715:001850', '3', '4113', '南阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1851', 'mainland', '1850', '0:003743:001715:001850:001851', '4', null, '宛城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1852', 'mainland', '1850', '0:003743:001715:001850:001852', '4', null, '卧龙区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1853', 'mainland', '1850', '0:003743:001715:001850:001853', '4', null, '南召县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1854', 'mainland', '1850', '0:003743:001715:001850:001854', '4', null, '方城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1855', 'mainland', '1850', '0:003743:001715:001850:001855', '4', null, '西峡县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1856', 'mainland', '1850', '0:003743:001715:001850:001856', '4', null, '镇平县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1857', 'mainland', '1850', '0:003743:001715:001850:001857', '4', null, '内乡县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1858', 'mainland', '1850', '0:003743:001715:001850:001858', '4', null, '淅川县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1859', 'mainland', '1850', '0:003743:001715:001850:001859', '4', null, '社旗县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1860', 'mainland', '1850', '0:003743:001715:001850:001860', '4', null, '唐河县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1861', 'mainland', '1850', '0:003743:001715:001850:001861', '4', null, '新野县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1862', 'mainland', '1850', '0:003743:001715:001850:001862', '4', null, '桐柏县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1863', 'mainland', '1850', '0:003743:001715:001850:001863', '4', null, '邓州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1864', 'mainland', '1850', '0:003743:001715:001850:001864', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1865', 'mainland', '1715', '0:003743:001715:001865', '3', '4114', '商丘市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1866', 'mainland', '1865', '0:003743:001715:001865:001866', '4', null, '梁园区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1867', 'mainland', '1865', '0:003743:001715:001865:001867', '4', null, '睢阳区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1868', 'mainland', '1865', '0:003743:001715:001865:001868', '4', null, '民权县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1869', 'mainland', '1865', '0:003743:001715:001865:001869', '4', null, '睢县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1870', 'mainland', '1865', '0:003743:001715:001865:001870', '4', null, '宁陵县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1871', 'mainland', '1865', '0:003743:001715:001865:001871', '4', null, '柘城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1872', 'mainland', '1865', '0:003743:001715:001865:001872', '4', null, '虞城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1873', 'mainland', '1865', '0:003743:001715:001865:001873', '4', null, '夏邑县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1874', 'mainland', '1865', '0:003743:001715:001865:001874', '4', null, '永城市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1875', 'mainland', '1865', '0:003743:001715:001865:001875', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1876', 'mainland', '1715', '0:003743:001715:001876', '3', '4115', '信阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1877', 'mainland', '1876', '0:003743:001715:001876:001877', '4', null, '浉河区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1878', 'mainland', '1876', '0:003743:001715:001876:001878', '4', null, '平桥区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1879', 'mainland', '1876', '0:003743:001715:001876:001879', '4', null, '罗山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1880', 'mainland', '1876', '0:003743:001715:001876:001880', '4', null, '光山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1881', 'mainland', '1876', '0:003743:001715:001876:001881', '4', null, '新县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1882', 'mainland', '1876', '0:003743:001715:001876:001882', '4', null, '商城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1883', 'mainland', '1876', '0:003743:001715:001876:001883', '4', null, '固始县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1884', 'mainland', '1876', '0:003743:001715:001876:001884', '4', null, '潢川县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1885', 'mainland', '1876', '0:003743:001715:001876:001885', '4', null, '淮滨县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1886', 'mainland', '1876', '0:003743:001715:001876:001886', '4', null, '息县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1887', 'mainland', '1876', '0:003743:001715:001876:001887', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1888', 'mainland', '1715', '0:003743:001715:001888', '3', '4116', '周口市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1889', 'mainland', '1888', '0:003743:001715:001888:001889', '4', null, '川汇区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1890', 'mainland', '1888', '0:003743:001715:001888:001890', '4', null, '扶沟县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1891', 'mainland', '1888', '0:003743:001715:001888:001891', '4', null, '西华县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1892', 'mainland', '1888', '0:003743:001715:001888:001892', '4', null, '商水县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1893', 'mainland', '1888', '0:003743:001715:001888:001893', '4', null, '沈丘县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1894', 'mainland', '1888', '0:003743:001715:001888:001894', '4', null, '郸城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1895', 'mainland', '1888', '0:003743:001715:001888:001895', '4', null, '淮阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1896', 'mainland', '1888', '0:003743:001715:001888:001896', '4', null, '太康县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1897', 'mainland', '1888', '0:003743:001715:001888:001897', '4', null, '鹿邑县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1898', 'mainland', '1888', '0:003743:001715:001888:001898', '4', null, '项城市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1899', 'mainland', '1888', '0:003743:001715:001888:001899', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1900', 'mainland', '1715', '0:003743:001715:001900', '3', '4117', '驻马店市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1901', 'mainland', '1900', '0:003743:001715:001900:001901', '4', null, '驿城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1902', 'mainland', '1900', '0:003743:001715:001900:001902', '4', null, '西平县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1903', 'mainland', '1900', '0:003743:001715:001900:001903', '4', null, '上蔡县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1904', 'mainland', '1900', '0:003743:001715:001900:001904', '4', null, '平舆县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1905', 'mainland', '1900', '0:003743:001715:001900:001905', '4', null, '正阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1906', 'mainland', '1900', '0:003743:001715:001900:001906', '4', null, '确山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1907', 'mainland', '1900', '0:003743:001715:001900:001907', '4', null, '泌阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1908', 'mainland', '1900', '0:003743:001715:001900:001908', '4', null, '汝南县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1909', 'mainland', '1900', '0:003743:001715:001900:001909', '4', null, '遂平县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1910', 'mainland', '1900', '0:003743:001715:001900:001910', '4', null, '新蔡县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1911', 'mainland', '1900', '0:003743:001715:001900:001911', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1912', 'mainland', '3743', '0:003743:001912', '2', null, '湖北省', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1913', 'mainland', '1912', '0:003743:001912:001913', '3', '4201', '武汉市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1914', 'mainland', '1913', '0:003743:001912:001913:001914', '4', null, '江岸区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1915', 'mainland', '1913', '0:003743:001912:001913:001915', '4', null, '江汉区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1916', 'mainland', '1913', '0:003743:001912:001913:001916', '4', null, '硚口区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1917', 'mainland', '1913', '0:003743:001912:001913:001917', '4', null, '汉阳区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1918', 'mainland', '1913', '0:003743:001912:001913:001918', '4', null, '武昌区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1919', 'mainland', '1913', '0:003743:001912:001913:001919', '4', null, '青山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1920', 'mainland', '1913', '0:003743:001912:001913:001920', '4', null, '洪山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1921', 'mainland', '1913', '0:003743:001912:001913:001921', '4', null, '东西湖区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1922', 'mainland', '1913', '0:003743:001912:001913:001922', '4', null, '汉南区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1923', 'mainland', '1913', '0:003743:001912:001913:001923', '4', null, '蔡甸区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1924', 'mainland', '1913', '0:003743:001912:001913:001924', '4', null, '江夏区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1925', 'mainland', '1913', '0:003743:001912:001913:001925', '4', null, '黄陂区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1926', 'mainland', '1913', '0:003743:001912:001913:001926', '4', null, '新洲区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1927', 'mainland', '1913', '0:003743:001912:001913:001927', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1928', 'mainland', '1912', '0:003743:001912:001928', '3', '4202', '黄石市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1929', 'mainland', '1928', '0:003743:001912:001928:001929', '4', null, '黄石港区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1930', 'mainland', '1928', '0:003743:001912:001928:001930', '4', null, '西塞山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1931', 'mainland', '1928', '0:003743:001912:001928:001931', '4', null, '下陆区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1932', 'mainland', '1928', '0:003743:001912:001928:001932', '4', null, '铁山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1933', 'mainland', '1928', '0:003743:001912:001928:001933', '4', null, '阳新县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1934', 'mainland', '1928', '0:003743:001912:001928:001934', '4', null, '大冶市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1935', 'mainland', '1928', '0:003743:001912:001928:001935', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1936', 'mainland', '1912', '0:003743:001912:001936', '3', '4203', '十堰市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1937', 'mainland', '1936', '0:003743:001912:001936:001937', '4', null, '茅箭区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1938', 'mainland', '1936', '0:003743:001912:001936:001938', '4', null, '张湾区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1939', 'mainland', '1936', '0:003743:001912:001936:001939', '4', null, '郧县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1940', 'mainland', '1936', '0:003743:001912:001936:001940', '4', null, '郧西县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1941', 'mainland', '1936', '0:003743:001912:001936:001941', '4', null, '竹山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1942', 'mainland', '1936', '0:003743:001912:001936:001942', '4', null, '竹溪县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1943', 'mainland', '1936', '0:003743:001912:001936:001943', '4', null, '房县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1944', 'mainland', '1936', '0:003743:001912:001936:001944', '4', null, '丹江口市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1945', 'mainland', '1936', '0:003743:001912:001936:001945', '4', null, '城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1946', 'mainland', '1936', '0:003743:001912:001936:001946', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1947', 'mainland', '1912', '0:003743:001912:001947', '3', '4205', '宜昌市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1948', 'mainland', '1947', '0:003743:001912:001947:001948', '4', null, '西陵区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1949', 'mainland', '1947', '0:003743:001912:001947:001949', '4', null, '伍家岗区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1950', 'mainland', '1947', '0:003743:001912:001947:001950', '4', null, '点军区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1951', 'mainland', '1947', '0:003743:001912:001947:001951', '4', null, '猇亭区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1952', 'mainland', '1947', '0:003743:001912:001947:001952', '4', null, '夷陵区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1953', 'mainland', '1947', '0:003743:001912:001947:001953', '4', null, '远安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1954', 'mainland', '1947', '0:003743:001912:001947:001954', '4', null, '兴山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1955', 'mainland', '1947', '0:003743:001912:001947:001955', '4', null, '秭归县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1956', 'mainland', '1947', '0:003743:001912:001947:001956', '4', null, '长阳土家族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1957', 'mainland', '1947', '0:003743:001912:001947:001957', '4', null, '五峰土家族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1958', 'mainland', '1947', '0:003743:001912:001947:001958', '4', null, '葛洲坝区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1959', 'mainland', '1947', '0:003743:001912:001947:001959', '4', null, '开发区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1960', 'mainland', '1947', '0:003743:001912:001947:001960', '4', null, '宜都市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1961', 'mainland', '1947', '0:003743:001912:001947:001961', '4', null, '当阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1962', 'mainland', '1947', '0:003743:001912:001947:001962', '4', null, '枝江市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1963', 'mainland', '1947', '0:003743:001912:001947:001963', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1964', 'mainland', '1912', '0:003743:001912:001964', '3', '4206', '襄阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1965', 'mainland', '1964', '0:003743:001912:001964:001965', '4', null, '襄城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1966', 'mainland', '1964', '0:003743:001912:001964:001966', '4', null, '樊城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1967', 'mainland', '1964', '0:003743:001912:001964:001967', '4', null, '襄州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1968', 'mainland', '1964', '0:003743:001912:001964:001968', '4', null, '南漳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1969', 'mainland', '1964', '0:003743:001912:001964:001969', '4', null, '谷城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1970', 'mainland', '1964', '0:003743:001912:001964:001970', '4', null, '保康县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1971', 'mainland', '1964', '0:003743:001912:001964:001971', '4', null, '老河口市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1972', 'mainland', '1964', '0:003743:001912:001964:001972', '4', null, '枣阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1973', 'mainland', '1964', '0:003743:001912:001964:001973', '4', null, '宜城市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1974', 'mainland', '1964', '0:003743:001912:001964:001974', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1975', 'mainland', '1912', '0:003743:001912:001975', '3', '4207', '鄂州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1976', 'mainland', '1975', '0:003743:001912:001975:001976', '4', null, '梁子湖区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1977', 'mainland', '1975', '0:003743:001912:001975:001977', '4', null, '华容区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1978', 'mainland', '1975', '0:003743:001912:001975:001978', '4', null, '鄂城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1979', 'mainland', '1975', '0:003743:001912:001975:001979', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1980', 'mainland', '1912', '0:003743:001912:001980', '3', '4208', '荆门市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1981', 'mainland', '1980', '0:003743:001912:001980:001981', '4', null, '东宝区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1982', 'mainland', '1980', '0:003743:001912:001980:001982', '4', null, '掇刀区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1983', 'mainland', '1980', '0:003743:001912:001980:001983', '4', null, '京山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1984', 'mainland', '1980', '0:003743:001912:001980:001984', '4', null, '沙洋县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1985', 'mainland', '1980', '0:003743:001912:001980:001985', '4', null, '钟祥市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1986', 'mainland', '1980', '0:003743:001912:001980:001986', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1987', 'mainland', '1912', '0:003743:001912:001987', '3', '4209', '孝感市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1988', 'mainland', '1987', '0:003743:001912:001987:001988', '4', null, '孝南区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1989', 'mainland', '1987', '0:003743:001912:001987:001989', '4', null, '孝昌县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1990', 'mainland', '1987', '0:003743:001912:001987:001990', '4', null, '大悟县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1991', 'mainland', '1987', '0:003743:001912:001987:001991', '4', null, '云梦县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1992', 'mainland', '1987', '0:003743:001912:001987:001992', '4', null, '应城市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1993', 'mainland', '1987', '0:003743:001912:001987:001993', '4', null, '安陆市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1994', 'mainland', '1987', '0:003743:001912:001987:001994', '4', null, '汉川市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1995', 'mainland', '1987', '0:003743:001912:001987:001995', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1996', 'mainland', '1912', '0:003743:001912:001996', '3', '1996', '荆州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1997', 'mainland', '1996', '0:003743:001912:001996:001997', '4', null, '沙市区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1998', 'mainland', '1996', '0:003743:001912:001996:001998', '4', null, '荆州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('1999', 'mainland', '1996', '0:003743:001912:001996:001999', '4', null, '公安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2000', 'mainland', '1996', '0:003743:001912:001996:002000', '4', null, '监利县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2001', 'mainland', '1996', '0:003743:001912:001996:002001', '4', null, '江陵县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2002', 'mainland', '1996', '0:003743:001912:001996:002002', '4', null, '石首市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2003', 'mainland', '1996', '0:003743:001912:001996:002003', '4', null, '洪湖市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2004', 'mainland', '1996', '0:003743:001912:001996:002004', '4', null, '松滋市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2005', 'mainland', '1996', '0:003743:001912:001996:002005', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2006', 'mainland', '1912', '0:003743:001912:002006', '3', '4211', '黄冈市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2007', 'mainland', '2006', '0:003743:001912:002006:002007', '4', null, '黄州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2008', 'mainland', '2006', '0:003743:001912:002006:002008', '4', null, '团风县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2009', 'mainland', '2006', '0:003743:001912:002006:002009', '4', null, '红安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2010', 'mainland', '2006', '0:003743:001912:002006:002010', '4', null, '罗田县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2011', 'mainland', '2006', '0:003743:001912:002006:002011', '4', null, '英山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2012', 'mainland', '2006', '0:003743:001912:002006:002012', '4', null, '浠水县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2013', 'mainland', '2006', '0:003743:001912:002006:002013', '4', null, '蕲春县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2014', 'mainland', '2006', '0:003743:001912:002006:002014', '4', null, '黄梅县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2015', 'mainland', '2006', '0:003743:001912:002006:002015', '4', null, '麻城市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2016', 'mainland', '2006', '0:003743:001912:002006:002016', '4', null, '武穴市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2017', 'mainland', '2006', '0:003743:001912:002006:002017', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2018', 'mainland', '1912', '0:003743:001912:002018', '3', '4212', '咸宁市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2019', 'mainland', '2018', '0:003743:001912:002018:002019', '4', null, '咸安区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2020', 'mainland', '2018', '0:003743:001912:002018:002020', '4', null, '嘉鱼县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2021', 'mainland', '2018', '0:003743:001912:002018:002021', '4', null, '通城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2022', 'mainland', '2018', '0:003743:001912:002018:002022', '4', null, '崇阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2023', 'mainland', '2018', '0:003743:001912:002018:002023', '4', null, '通山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2024', 'mainland', '2018', '0:003743:001912:002018:002024', '4', null, '赤壁市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2025', 'mainland', '2018', '0:003743:001912:002018:002025', '4', null, '温泉城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2026', 'mainland', '2018', '0:003743:001912:002018:002026', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2027', 'mainland', '1912', '0:003743:001912:002027', '3', '4213', '随州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2028', 'mainland', '2027', '0:003743:001912:002027:002028', '4', null, '曾都区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2029', 'mainland', '2027', '0:003743:001912:002027:002029', '4', null, '随县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2030', 'mainland', '2027', '0:003743:001912:002027:002030', '4', null, '广水市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2031', 'mainland', '2027', '0:003743:001912:002027:002031', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2032', 'mainland', '1912', '0:003743:001912:002032', '3', '4228', '恩施土家族苗族自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2033', 'mainland', '2032', '0:003743:001912:002032:002033', '4', null, '恩施市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2034', 'mainland', '2032', '0:003743:001912:002032:002034', '4', null, '利川市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2035', 'mainland', '2032', '0:003743:001912:002032:002035', '4', null, '建始县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2036', 'mainland', '2032', '0:003743:001912:002032:002036', '4', null, '巴东县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2037', 'mainland', '2032', '0:003743:001912:002032:002037', '4', null, '宣恩县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2038', 'mainland', '2032', '0:003743:001912:002032:002038', '4', null, '咸丰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2039', 'mainland', '2032', '0:003743:001912:002032:002039', '4', null, '来凤县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2040', 'mainland', '2032', '0:003743:001912:002032:002040', '4', null, '鹤峰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2041', 'mainland', '2032', '0:003743:001912:002032:002041', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2042', 'mainland', '1912', '0:003743:001912:002042', '3', '2042', '仙桃市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2043', 'mainland', '1912', '0:003743:001912:002043', '3', '2043', '潜江市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2044', 'mainland', '1912', '0:003743:001912:002044', '3', '2044', '天门市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2045', 'mainland', '1912', '0:003743:001912:002045', '3', '2045', '神农架林区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2046', 'mainland', '3743', '0:003743:002046', '2', null, '湖南省', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2047', 'mainland', '2046', '0:003743:002046:002047', '3', '4301', '长沙市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2048', 'mainland', '2047', '0:003743:002046:002047:002048', '4', null, '芙蓉区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2049', 'mainland', '2047', '0:003743:002046:002047:002049', '4', null, '天心区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2050', 'mainland', '2047', '0:003743:002046:002047:002050', '4', null, '岳麓区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2051', 'mainland', '2047', '0:003743:002046:002047:002051', '4', null, '开福区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2052', 'mainland', '2047', '0:003743:002046:002047:002052', '4', null, '雨花区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2053', 'mainland', '2047', '0:003743:002046:002047:002053', '4', null, '长沙县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2054', 'mainland', '2047', '0:003743:002046:002047:002054', '4', null, '望城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2055', 'mainland', '2047', '0:003743:002046:002047:002055', '4', null, '宁乡县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2056', 'mainland', '2047', '0:003743:002046:002047:002056', '4', null, '浏阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2057', 'mainland', '2047', '0:003743:002046:002047:002057', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2058', 'mainland', '2046', '0:003743:002046:002058', '3', '4302', '株洲市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2059', 'mainland', '2058', '0:003743:002046:002058:002059', '4', null, '荷塘区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2060', 'mainland', '2058', '0:003743:002046:002058:002060', '4', null, '芦淞区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2061', 'mainland', '2058', '0:003743:002046:002058:002061', '4', null, '石峰区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2062', 'mainland', '2058', '0:003743:002046:002058:002062', '4', null, '天元区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2063', 'mainland', '2058', '0:003743:002046:002058:002063', '4', null, '株洲县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2064', 'mainland', '2058', '0:003743:002046:002058:002064', '4', null, '攸县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2065', 'mainland', '2058', '0:003743:002046:002058:002065', '4', null, '茶陵县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2066', 'mainland', '2058', '0:003743:002046:002058:002066', '4', null, '炎陵县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2067', 'mainland', '2058', '0:003743:002046:002058:002067', '4', null, '醴陵市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2068', 'mainland', '2058', '0:003743:002046:002058:002068', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2069', 'mainland', '2046', '0:003743:002046:002069', '3', '4303', '湘潭市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2070', 'mainland', '2069', '0:003743:002046:002069:002070', '4', null, '雨湖区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2071', 'mainland', '2069', '0:003743:002046:002069:002071', '4', null, '岳塘区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2072', 'mainland', '2069', '0:003743:002046:002069:002072', '4', null, '湘潭县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2073', 'mainland', '2069', '0:003743:002046:002069:002073', '4', null, '湘乡市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2074', 'mainland', '2069', '0:003743:002046:002069:002074', '4', null, '韶山市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2075', 'mainland', '2069', '0:003743:002046:002069:002075', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2076', 'mainland', '2046', '0:003743:002046:002076', '3', '4304', '衡阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2077', 'mainland', '2076', '0:003743:002046:002076:002077', '4', null, '珠晖区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2078', 'mainland', '2076', '0:003743:002046:002076:002078', '4', null, '雁峰区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2079', 'mainland', '2076', '0:003743:002046:002076:002079', '4', null, '石鼓区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2080', 'mainland', '2076', '0:003743:002046:002076:002080', '4', null, '蒸湘区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2081', 'mainland', '2076', '0:003743:002046:002076:002081', '4', null, '南岳区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2082', 'mainland', '2076', '0:003743:002046:002076:002082', '4', null, '衡阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2083', 'mainland', '2076', '0:003743:002046:002076:002083', '4', null, '衡南县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2084', 'mainland', '2076', '0:003743:002046:002076:002084', '4', null, '衡山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2085', 'mainland', '2076', '0:003743:002046:002076:002085', '4', null, '衡东县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2086', 'mainland', '2076', '0:003743:002046:002076:002086', '4', null, '祁东县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2087', 'mainland', '2076', '0:003743:002046:002076:002087', '4', null, '耒阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2088', 'mainland', '2076', '0:003743:002046:002076:002088', '4', null, '常宁市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2089', 'mainland', '2076', '0:003743:002046:002076:002089', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2090', 'mainland', '2046', '0:003743:002046:002090', '3', '4305', '邵阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2091', 'mainland', '2090', '0:003743:002046:002090:002091', '4', null, '双清区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2092', 'mainland', '2090', '0:003743:002046:002090:002092', '4', null, '大祥区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2093', 'mainland', '2090', '0:003743:002046:002090:002093', '4', null, '北塔区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2094', 'mainland', '2090', '0:003743:002046:002090:002094', '4', null, '邵东县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2095', 'mainland', '2090', '0:003743:002046:002090:002095', '4', null, '新邵县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2096', 'mainland', '2090', '0:003743:002046:002090:002096', '4', null, '邵阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2097', 'mainland', '2090', '0:003743:002046:002090:002097', '4', null, '隆回县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2098', 'mainland', '2090', '0:003743:002046:002090:002098', '4', null, '洞口县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2099', 'mainland', '2090', '0:003743:002046:002090:002099', '4', null, '绥宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2100', 'mainland', '2090', '0:003743:002046:002090:002100', '4', null, '新宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2101', 'mainland', '2090', '0:003743:002046:002090:002101', '4', null, '城步苗族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2102', 'mainland', '2090', '0:003743:002046:002090:002102', '4', null, '武冈市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2103', 'mainland', '2090', '0:003743:002046:002090:002103', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2104', 'mainland', '2046', '0:003743:002046:002104', '3', '4306', '岳阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2105', 'mainland', '2104', '0:003743:002046:002104:002105', '4', null, '岳阳楼区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2106', 'mainland', '2104', '0:003743:002046:002104:002106', '4', null, '云溪区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2107', 'mainland', '2104', '0:003743:002046:002104:002107', '4', null, '君山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2108', 'mainland', '2104', '0:003743:002046:002104:002108', '4', null, '岳阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2109', 'mainland', '2104', '0:003743:002046:002104:002109', '4', null, '华容县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2110', 'mainland', '2104', '0:003743:002046:002104:002110', '4', null, '湘阴县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2111', 'mainland', '2104', '0:003743:002046:002104:002111', '4', null, '平江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2112', 'mainland', '2104', '0:003743:002046:002104:002112', '4', null, '汨罗市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2113', 'mainland', '2104', '0:003743:002046:002104:002113', '4', null, '临湘市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2114', 'mainland', '2104', '0:003743:002046:002104:002114', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2115', 'mainland', '2046', '0:003743:002046:002115', '3', '4307', '常德市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2116', 'mainland', '2115', '0:003743:002046:002115:002116', '4', null, '武陵区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2117', 'mainland', '2115', '0:003743:002046:002115:002117', '4', null, '鼎城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2118', 'mainland', '2115', '0:003743:002046:002115:002118', '4', null, '安乡县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2119', 'mainland', '2115', '0:003743:002046:002115:002119', '4', null, '汉寿县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2120', 'mainland', '2115', '0:003743:002046:002115:002120', '4', null, '澧县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2121', 'mainland', '2115', '0:003743:002046:002115:002121', '4', null, '临澧县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2122', 'mainland', '2115', '0:003743:002046:002115:002122', '4', null, '桃源县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2123', 'mainland', '2115', '0:003743:002046:002115:002123', '4', null, '石门县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2124', 'mainland', '2115', '0:003743:002046:002115:002124', '4', null, '津市市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2125', 'mainland', '2115', '0:003743:002046:002115:002125', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2126', 'mainland', '2046', '0:003743:002046:002126', '3', '4308', '张家界市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2127', 'mainland', '2126', '0:003743:002046:002126:002127', '4', null, '永定区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2128', 'mainland', '2126', '0:003743:002046:002126:002128', '4', null, '武陵源区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2129', 'mainland', '2126', '0:003743:002046:002126:002129', '4', null, '慈利县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2130', 'mainland', '2126', '0:003743:002046:002126:002130', '4', null, '桑植县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2131', 'mainland', '2126', '0:003743:002046:002126:002131', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2132', 'mainland', '2046', '0:003743:002046:002132', '3', '4309', '益阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2133', 'mainland', '2132', '0:003743:002046:002132:002133', '4', null, '资阳区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2134', 'mainland', '2132', '0:003743:002046:002132:002134', '4', null, '赫山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2135', 'mainland', '2132', '0:003743:002046:002132:002135', '4', null, '南县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2136', 'mainland', '2132', '0:003743:002046:002132:002136', '4', null, '桃江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2137', 'mainland', '2132', '0:003743:002046:002132:002137', '4', null, '安化县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2138', 'mainland', '2132', '0:003743:002046:002132:002138', '4', null, '沅江市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2139', 'mainland', '2132', '0:003743:002046:002132:002139', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2140', 'mainland', '2046', '0:003743:002046:002140', '3', '2140', '郴州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2141', 'mainland', '2140', '0:003743:002046:002140:002141', '4', null, '北湖区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2142', 'mainland', '2140', '0:003743:002046:002140:002142', '4', null, '苏仙区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2143', 'mainland', '2140', '0:003743:002046:002140:002143', '4', null, '桂阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2144', 'mainland', '2140', '0:003743:002046:002140:002144', '4', null, '宜章县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2145', 'mainland', '2140', '0:003743:002046:002140:002145', '4', null, '永兴县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2146', 'mainland', '2140', '0:003743:002046:002140:002146', '4', null, '嘉禾县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2147', 'mainland', '2140', '0:003743:002046:002140:002147', '4', null, '临武县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2148', 'mainland', '2140', '0:003743:002046:002140:002148', '4', null, '汝城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2149', 'mainland', '2140', '0:003743:002046:002140:002149', '4', null, '桂东县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2150', 'mainland', '2140', '0:003743:002046:002140:002150', '4', null, '安仁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2151', 'mainland', '2140', '0:003743:002046:002140:002151', '4', null, '资兴市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2152', 'mainland', '2140', '0:003743:002046:002140:002152', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2153', 'mainland', '2046', '0:003743:002046:002153', '3', '4311', '永州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2154', 'mainland', '2153', '0:003743:002046:002153:002154', '4', null, '零陵区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2155', 'mainland', '2153', '0:003743:002046:002153:002155', '4', null, '冷水滩区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2156', 'mainland', '2153', '0:003743:002046:002153:002156', '4', null, '祁阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2157', 'mainland', '2153', '0:003743:002046:002153:002157', '4', null, '东安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2158', 'mainland', '2153', '0:003743:002046:002153:002158', '4', null, '双牌县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2159', 'mainland', '2153', '0:003743:002046:002153:002159', '4', null, '道县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2160', 'mainland', '2153', '0:003743:002046:002153:002160', '4', null, '江永县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2161', 'mainland', '2153', '0:003743:002046:002153:002161', '4', null, '宁远县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2162', 'mainland', '2153', '0:003743:002046:002153:002162', '4', null, '蓝山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2163', 'mainland', '2153', '0:003743:002046:002153:002163', '4', null, '新田县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2164', 'mainland', '2153', '0:003743:002046:002153:002164', '4', null, '江华瑶族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2165', 'mainland', '2153', '0:003743:002046:002153:002165', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2166', 'mainland', '2046', '0:003743:002046:002166', '3', '4312', '怀化市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2167', 'mainland', '2166', '0:003743:002046:002166:002167', '4', null, '鹤城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2168', 'mainland', '2166', '0:003743:002046:002166:002168', '4', null, '中方县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2169', 'mainland', '2166', '0:003743:002046:002166:002169', '4', null, '沅陵县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2170', 'mainland', '2166', '0:003743:002046:002166:002170', '4', null, '辰溪县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2171', 'mainland', '2166', '0:003743:002046:002166:002171', '4', null, '溆浦县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2172', 'mainland', '2166', '0:003743:002046:002166:002172', '4', null, '会同县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2173', 'mainland', '2166', '0:003743:002046:002166:002173', '4', null, '麻阳苗族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2174', 'mainland', '2166', '0:003743:002046:002166:002174', '4', null, '新晃侗族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2175', 'mainland', '2166', '0:003743:002046:002166:002175', '4', null, '芷江侗族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2176', 'mainland', '2166', '0:003743:002046:002166:002176', '4', null, '靖州苗族侗族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2177', 'mainland', '2166', '0:003743:002046:002166:002177', '4', null, '通道侗族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2178', 'mainland', '2166', '0:003743:002046:002166:002178', '4', null, '洪江市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2179', 'mainland', '2166', '0:003743:002046:002166:002179', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2180', 'mainland', '2046', '0:003743:002046:002180', '3', '4313', '娄底市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2181', 'mainland', '2180', '0:003743:002046:002180:002181', '4', null, '娄星区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2182', 'mainland', '2180', '0:003743:002046:002180:002182', '4', null, '双峰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2183', 'mainland', '2180', '0:003743:002046:002180:002183', '4', null, '新化县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2184', 'mainland', '2180', '0:003743:002046:002180:002184', '4', null, '冷水江市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2185', 'mainland', '2180', '0:003743:002046:002180:002185', '4', null, '涟源市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2186', 'mainland', '2180', '0:003743:002046:002180:002186', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2187', 'mainland', '2046', '0:003743:002046:002187', '3', '4331', '湘西土家族苗族自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2188', 'mainland', '2187', '0:003743:002046:002187:002188', '4', null, '吉首市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2189', 'mainland', '2187', '0:003743:002046:002187:002189', '4', null, '泸溪县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2190', 'mainland', '2187', '0:003743:002046:002187:002190', '4', null, '凤凰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2191', 'mainland', '2187', '0:003743:002046:002187:002191', '4', null, '花垣县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2192', 'mainland', '2187', '0:003743:002046:002187:002192', '4', null, '保靖县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2193', 'mainland', '2187', '0:003743:002046:002187:002193', '4', null, '古丈县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2194', 'mainland', '2187', '0:003743:002046:002187:002194', '4', null, '永顺县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2195', 'mainland', '2187', '0:003743:002046:002187:002195', '4', null, '龙山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2196', 'mainland', '2187', '0:003743:002046:002187:002196', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2197', 'mainland', '3743', '0:003743:002197', '2', null, '广东省', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2198', 'mainland', '2197', '0:003743:002197:002198', '3', '4401', '广州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2199', 'mainland', '2198', '0:003743:002197:002198:002199', '4', null, '荔湾区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2200', 'mainland', '2198', '0:003743:002197:002198:002200', '4', null, '越秀区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2201', 'mainland', '2198', '0:003743:002197:002198:002201', '4', null, '海珠区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2202', 'mainland', '2198', '0:003743:002197:002198:002202', '4', null, '天河区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2203', 'mainland', '2198', '0:003743:002197:002198:002203', '4', null, '白云区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2204', 'mainland', '2198', '0:003743:002197:002198:002204', '4', null, '黄埔区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2205', 'mainland', '2198', '0:003743:002197:002198:002205', '4', null, '番禺区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2206', 'mainland', '2198', '0:003743:002197:002198:002206', '4', null, '花都区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2207', 'mainland', '2198', '0:003743:002197:002198:002207', '4', null, '南沙区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2208', 'mainland', '2198', '0:003743:002197:002198:002208', '4', null, '萝岗区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2209', 'mainland', '2198', '0:003743:002197:002198:002209', '4', null, '增城市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2210', 'mainland', '2198', '0:003743:002197:002198:002210', '4', null, '从化市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2211', 'mainland', '2198', '0:003743:002197:002198:002211', '4', null, '东山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2212', 'mainland', '2198', '0:003743:002197:002198:002212', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2213', 'mainland', '2197', '0:003743:002197:002213', '3', '4402', '韶关市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2214', 'mainland', '2213', '0:003743:002197:002213:002214', '4', null, '武江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2215', 'mainland', '2213', '0:003743:002197:002213:002215', '4', null, '浈江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2216', 'mainland', '2213', '0:003743:002197:002213:002216', '4', null, '曲江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2217', 'mainland', '2213', '0:003743:002197:002213:002217', '4', null, '始兴县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2218', 'mainland', '2213', '0:003743:002197:002213:002218', '4', null, '仁化县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2219', 'mainland', '2213', '0:003743:002197:002213:002219', '4', null, '翁源县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2220', 'mainland', '2213', '0:003743:002197:002213:002220', '4', null, '乳源瑶族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2221', 'mainland', '2213', '0:003743:002197:002213:002221', '4', null, '新丰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2222', 'mainland', '2213', '0:003743:002197:002213:002222', '4', null, '乐昌市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2223', 'mainland', '2213', '0:003743:002197:002213:002223', '4', null, '南雄市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2224', 'mainland', '2213', '0:003743:002197:002213:002224', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2225', 'mainland', '2197', '0:003743:002197:002225', '3', '4403', '深圳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2226', 'mainland', '2225', '0:003743:002197:002225:002226', '4', null, '罗湖区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2227', 'mainland', '2225', '0:003743:002197:002225:002227', '4', null, '福田区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2228', 'mainland', '2225', '0:003743:002197:002225:002228', '4', null, '南山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2229', 'mainland', '2225', '0:003743:002197:002225:002229', '4', null, '宝安区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2230', 'mainland', '2225', '0:003743:002197:002225:002230', '4', null, '龙岗区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2231', 'mainland', '2225', '0:003743:002197:002225:002231', '4', null, '盐田区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2232', 'mainland', '2225', '0:003743:002197:002225:002232', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2233', 'mainland', '2197', '0:003743:002197:002233', '3', '4404', '珠海市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2234', 'mainland', '2233', '0:003743:002197:002233:002234', '4', null, '香洲区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2235', 'mainland', '2233', '0:003743:002197:002233:002235', '4', null, '斗门区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2236', 'mainland', '2233', '0:003743:002197:002233:002236', '4', null, '金湾区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2237', 'mainland', '2233', '0:003743:002197:002233:002237', '4', null, '金唐区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2238', 'mainland', '2233', '0:003743:002197:002233:002238', '4', null, '南湾区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2239', 'mainland', '2233', '0:003743:002197:002233:002239', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2240', 'mainland', '2197', '0:003743:002197:002240', '3', '4405', '汕头市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2241', 'mainland', '2240', '0:003743:002197:002240:002241', '4', null, '龙湖区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2242', 'mainland', '2240', '0:003743:002197:002240:002242', '4', null, '金平区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2243', 'mainland', '2240', '0:003743:002197:002240:002243', '4', null, '濠江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2244', 'mainland', '2240', '0:003743:002197:002240:002244', '4', null, '潮阳区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2245', 'mainland', '2240', '0:003743:002197:002240:002245', '4', null, '潮南区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2246', 'mainland', '2240', '0:003743:002197:002240:002246', '4', null, '澄海区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2247', 'mainland', '2240', '0:003743:002197:002240:002247', '4', null, '南澳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2248', 'mainland', '2240', '0:003743:002197:002240:002248', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2249', 'mainland', '2197', '0:003743:002197:002249', '3', '4406', '佛山市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2250', 'mainland', '2249', '0:003743:002197:002249:002250', '4', null, '禅城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2251', 'mainland', '2249', '0:003743:002197:002249:002251', '4', null, '南海区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2252', 'mainland', '2249', '0:003743:002197:002249:002252', '4', null, '顺德区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2253', 'mainland', '2249', '0:003743:002197:002249:002253', '4', null, '三水区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2254', 'mainland', '2249', '0:003743:002197:002249:002254', '4', null, '高明区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2255', 'mainland', '2249', '0:003743:002197:002249:002255', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2256', 'mainland', '2197', '0:003743:002197:002256', '3', '4407', '江门市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2257', 'mainland', '2256', '0:003743:002197:002256:002257', '4', null, '蓬江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2258', 'mainland', '2256', '0:003743:002197:002256:002258', '4', null, '江海区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2259', 'mainland', '2256', '0:003743:002197:002256:002259', '4', null, '新会区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2260', 'mainland', '2256', '0:003743:002197:002256:002260', '4', null, '台山市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2261', 'mainland', '2256', '0:003743:002197:002256:002261', '4', null, '开平市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2262', 'mainland', '2256', '0:003743:002197:002256:002262', '4', null, '鹤山市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2263', 'mainland', '2256', '0:003743:002197:002256:002263', '4', null, '恩平市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2264', 'mainland', '2256', '0:003743:002197:002256:002264', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2265', 'mainland', '2197', '0:003743:002197:002265', '3', '4408', '湛江市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2266', 'mainland', '2265', '0:003743:002197:002265:002266', '4', null, '赤坎区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2267', 'mainland', '2265', '0:003743:002197:002265:002267', '4', null, '霞山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2268', 'mainland', '2265', '0:003743:002197:002265:002268', '4', null, '坡头区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2269', 'mainland', '2265', '0:003743:002197:002265:002269', '4', null, '麻章区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2270', 'mainland', '2265', '0:003743:002197:002265:002270', '4', null, '遂溪县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2271', 'mainland', '2265', '0:003743:002197:002265:002271', '4', null, '徐闻县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2272', 'mainland', '2265', '0:003743:002197:002265:002272', '4', null, '廉江市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2273', 'mainland', '2265', '0:003743:002197:002265:002273', '4', null, '雷州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2274', 'mainland', '2265', '0:003743:002197:002265:002274', '4', null, '吴川市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2275', 'mainland', '2265', '0:003743:002197:002265:002275', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2276', 'mainland', '2197', '0:003743:002197:002276', '3', '4409', '茂名市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2277', 'mainland', '2276', '0:003743:002197:002276:002277', '4', null, '茂南区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2278', 'mainland', '2276', '0:003743:002197:002276:002278', '4', null, '茂港区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2279', 'mainland', '2276', '0:003743:002197:002276:002279', '4', null, '电白县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2280', 'mainland', '2276', '0:003743:002197:002276:002280', '4', null, '高州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2281', 'mainland', '2276', '0:003743:002197:002276:002281', '4', null, '化州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2282', 'mainland', '2276', '0:003743:002197:002276:002282', '4', null, '信宜市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2283', 'mainland', '2276', '0:003743:002197:002276:002283', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2284', 'mainland', '2197', '0:003743:002197:002284', '3', '4412', '肇庆市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2285', 'mainland', '2284', '0:003743:002197:002284:002285', '4', null, '端州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2286', 'mainland', '2284', '0:003743:002197:002284:002286', '4', null, '鼎湖区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2287', 'mainland', '2284', '0:003743:002197:002284:002287', '4', null, '广宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2288', 'mainland', '2284', '0:003743:002197:002284:002288', '4', null, '怀集县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2289', 'mainland', '2284', '0:003743:002197:002284:002289', '4', null, '封开县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2290', 'mainland', '2284', '0:003743:002197:002284:002290', '4', null, '德庆县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2291', 'mainland', '2284', '0:003743:002197:002284:002291', '4', null, '高要市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2292', 'mainland', '2284', '0:003743:002197:002284:002292', '4', null, '四会市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2293', 'mainland', '2284', '0:003743:002197:002284:002293', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2294', 'mainland', '2197', '0:003743:002197:002294', '3', '4413', '惠州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2295', 'mainland', '2294', '0:003743:002197:002294:002295', '4', null, '惠城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2296', 'mainland', '2294', '0:003743:002197:002294:002296', '4', null, '惠阳区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2297', 'mainland', '2294', '0:003743:002197:002294:002297', '4', null, '博罗县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2298', 'mainland', '2294', '0:003743:002197:002294:002298', '4', null, '惠东县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2299', 'mainland', '2294', '0:003743:002197:002294:002299', '4', null, '龙门县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2300', 'mainland', '2294', '0:003743:002197:002294:002300', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2301', 'mainland', '2197', '0:003743:002197:002301', '3', '4414', '梅州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2302', 'mainland', '2301', '0:003743:002197:002301:002302', '4', null, '梅江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2303', 'mainland', '2301', '0:003743:002197:002301:002303', '4', null, '梅县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2304', 'mainland', '2301', '0:003743:002197:002301:002304', '4', null, '大埔县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2305', 'mainland', '2301', '0:003743:002197:002301:002305', '4', null, '丰顺县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2306', 'mainland', '2301', '0:003743:002197:002301:002306', '4', null, '五华县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2307', 'mainland', '2301', '0:003743:002197:002301:002307', '4', null, '平远县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2308', 'mainland', '2301', '0:003743:002197:002301:002308', '4', null, '蕉岭县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2309', 'mainland', '2301', '0:003743:002197:002301:002309', '4', null, '兴宁市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2310', 'mainland', '2301', '0:003743:002197:002301:002310', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2311', 'mainland', '2197', '0:003743:002197:002311', '3', '4415', '汕尾市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2312', 'mainland', '2311', '0:003743:002197:002311:002312', '4', null, '城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2313', 'mainland', '2311', '0:003743:002197:002311:002313', '4', null, '海丰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2314', 'mainland', '2311', '0:003743:002197:002311:002314', '4', null, '陆河县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2315', 'mainland', '2311', '0:003743:002197:002311:002315', '4', null, '陆丰市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2316', 'mainland', '2311', '0:003743:002197:002311:002316', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2317', 'mainland', '2197', '0:003743:002197:002317', '3', '4416', '河源市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2318', 'mainland', '2317', '0:003743:002197:002317:002318', '4', null, '源城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2319', 'mainland', '2317', '0:003743:002197:002317:002319', '4', null, '紫金县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2320', 'mainland', '2317', '0:003743:002197:002317:002320', '4', null, '龙川县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2321', 'mainland', '2317', '0:003743:002197:002317:002321', '4', null, '连平县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2322', 'mainland', '2317', '0:003743:002197:002317:002322', '4', null, '和平县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2323', 'mainland', '2317', '0:003743:002197:002317:002323', '4', null, '东源县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2324', 'mainland', '2317', '0:003743:002197:002317:002324', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2325', 'mainland', '2197', '0:003743:002197:002325', '3', '4417', '阳江市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2326', 'mainland', '2325', '0:003743:002197:002325:002326', '4', null, '江城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2327', 'mainland', '2325', '0:003743:002197:002325:002327', '4', null, '阳西县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2328', 'mainland', '2325', '0:003743:002197:002325:002328', '4', null, '阳东县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2329', 'mainland', '2325', '0:003743:002197:002325:002329', '4', null, '阳春市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2330', 'mainland', '2325', '0:003743:002197:002325:002330', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2331', 'mainland', '2197', '0:003743:002197:002331', '3', '4418', '清远市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2332', 'mainland', '2331', '0:003743:002197:002331:002332', '4', null, '清城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2333', 'mainland', '2331', '0:003743:002197:002331:002333', '4', null, '佛冈县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2334', 'mainland', '2331', '0:003743:002197:002331:002334', '4', null, '阳山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2335', 'mainland', '2331', '0:003743:002197:002331:002335', '4', null, '连山壮族瑶族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2336', 'mainland', '2331', '0:003743:002197:002331:002336', '4', null, '连南瑶族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2337', 'mainland', '2331', '0:003743:002197:002331:002337', '4', null, '清新县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2338', 'mainland', '2331', '0:003743:002197:002331:002338', '4', null, '英德市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2339', 'mainland', '2331', '0:003743:002197:002331:002339', '4', null, '连州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2340', 'mainland', '2331', '0:003743:002197:002331:002340', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2341', 'mainland', '2197', '0:003743:002197:002341', '3', '4419', '东莞市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2342', 'mainland', '2197', '0:003743:002197:002342', '3', '2342', '中山市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2343', 'mainland', '2197', '0:003743:002197:002343', '3', '4451', '潮州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2344', 'mainland', '2343', '0:003743:002197:002343:002344', '4', null, '湘桥区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2345', 'mainland', '2343', '0:003743:002197:002343:002345', '4', null, '潮安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2346', 'mainland', '2343', '0:003743:002197:002343:002346', '4', null, '饶平县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2347', 'mainland', '2343', '0:003743:002197:002343:002347', '4', null, '枫溪区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2348', 'mainland', '2343', '0:003743:002197:002343:002348', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2349', 'mainland', '2197', '0:003743:002197:002349', '3', '4452', '揭阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2350', 'mainland', '2349', '0:003743:002197:002349:002350', '4', null, '榕城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2351', 'mainland', '2349', '0:003743:002197:002349:002351', '4', null, '揭东县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2352', 'mainland', '2349', '0:003743:002197:002349:002352', '4', null, '揭西县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2353', 'mainland', '2349', '0:003743:002197:002349:002353', '4', null, '惠来县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2354', 'mainland', '2349', '0:003743:002197:002349:002354', '4', null, '普宁市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2355', 'mainland', '2349', '0:003743:002197:002349:002355', '4', null, '东山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2356', 'mainland', '2349', '0:003743:002197:002349:002356', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2357', 'mainland', '2197', '0:003743:002197:002357', '3', '4453', '云浮市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2358', 'mainland', '2357', '0:003743:002197:002357:002358', '4', null, '云城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2359', 'mainland', '2357', '0:003743:002197:002357:002359', '4', null, '新兴县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2360', 'mainland', '2357', '0:003743:002197:002357:002360', '4', null, '郁南县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2361', 'mainland', '2357', '0:003743:002197:002357:002361', '4', null, '云安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2362', 'mainland', '2357', '0:003743:002197:002357:002362', '4', null, '罗定市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2363', 'mainland', '2357', '0:003743:002197:002357:002363', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2364', 'mainland', '3743', '0:003743:002364', '2', null, '广西壮族自治区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2365', 'mainland', '2364', '0:003743:002364:002365', '3', '4501', '南宁市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2366', 'mainland', '2365', '0:003743:002364:002365:002366', '4', null, '兴宁区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2367', 'mainland', '2365', '0:003743:002364:002365:002367', '4', null, '青秀区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2368', 'mainland', '2365', '0:003743:002364:002365:002368', '4', null, '江南区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2369', 'mainland', '2365', '0:003743:002364:002365:002369', '4', null, '西乡塘区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2370', 'mainland', '2365', '0:003743:002364:002365:002370', '4', null, '良庆区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2371', 'mainland', '2365', '0:003743:002364:002365:002371', '4', null, '邕宁区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2372', 'mainland', '2365', '0:003743:002364:002365:002372', '4', null, '武鸣县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2373', 'mainland', '2365', '0:003743:002364:002365:002373', '4', null, '隆安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2374', 'mainland', '2365', '0:003743:002364:002365:002374', '4', null, '马山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2375', 'mainland', '2365', '0:003743:002364:002365:002375', '4', null, '上林县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2376', 'mainland', '2365', '0:003743:002364:002365:002376', '4', null, '宾阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2377', 'mainland', '2365', '0:003743:002364:002365:002377', '4', null, '横县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2378', 'mainland', '2365', '0:003743:002364:002365:002378', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2379', 'mainland', '2364', '0:003743:002364:002379', '3', '4502', '柳州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2380', 'mainland', '2379', '0:003743:002364:002379:002380', '4', null, '城中区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2381', 'mainland', '2379', '0:003743:002364:002379:002381', '4', null, '鱼峰区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2382', 'mainland', '2379', '0:003743:002364:002379:002382', '4', null, '柳南区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2383', 'mainland', '2379', '0:003743:002364:002379:002383', '4', null, '柳北区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2384', 'mainland', '2379', '0:003743:002364:002379:002384', '4', null, '柳江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2385', 'mainland', '2379', '0:003743:002364:002379:002385', '4', null, '柳城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2386', 'mainland', '2379', '0:003743:002364:002379:002386', '4', null, '鹿寨县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2387', 'mainland', '2379', '0:003743:002364:002379:002387', '4', null, '融安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2388', 'mainland', '2379', '0:003743:002364:002379:002388', '4', null, '融水苗族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2389', 'mainland', '2379', '0:003743:002364:002379:002389', '4', null, '三江侗族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2390', 'mainland', '2379', '0:003743:002364:002379:002390', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2391', 'mainland', '2364', '0:003743:002364:002391', '3', '4503', '桂林市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2392', 'mainland', '2391', '0:003743:002364:002391:002392', '4', null, '秀峰区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2393', 'mainland', '2391', '0:003743:002364:002391:002393', '4', null, '叠彩区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2394', 'mainland', '2391', '0:003743:002364:002391:002394', '4', null, '象山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2395', 'mainland', '2391', '0:003743:002364:002391:002395', '4', null, '七星区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2396', 'mainland', '2391', '0:003743:002364:002391:002396', '4', null, '雁山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2397', 'mainland', '2391', '0:003743:002364:002391:002397', '4', null, '阳朔县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2398', 'mainland', '2391', '0:003743:002364:002391:002398', '4', null, '临桂县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2399', 'mainland', '2391', '0:003743:002364:002391:002399', '4', null, '灵川县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2400', 'mainland', '2391', '0:003743:002364:002391:002400', '4', null, '全州县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2401', 'mainland', '2391', '0:003743:002364:002391:002401', '4', null, '兴安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2402', 'mainland', '2391', '0:003743:002364:002391:002402', '4', null, '永福县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2403', 'mainland', '2391', '0:003743:002364:002391:002403', '4', null, '灌阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2404', 'mainland', '2391', '0:003743:002364:002391:002404', '4', null, '龙胜各族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2405', 'mainland', '2391', '0:003743:002364:002391:002405', '4', null, '资源县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2406', 'mainland', '2391', '0:003743:002364:002391:002406', '4', null, '平乐县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2407', 'mainland', '2391', '0:003743:002364:002391:002407', '4', null, '荔浦县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2408', 'mainland', '2391', '0:003743:002364:002391:002408', '4', null, '恭城瑶族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2409', 'mainland', '2391', '0:003743:002364:002391:002409', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2410', 'mainland', '2364', '0:003743:002364:002410', '3', '4504', '梧州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2411', 'mainland', '2410', '0:003743:002364:002410:002411', '4', null, '万秀区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2412', 'mainland', '2410', '0:003743:002364:002410:002412', '4', null, '蝶山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2413', 'mainland', '2410', '0:003743:002364:002410:002413', '4', null, '长洲区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2414', 'mainland', '2410', '0:003743:002364:002410:002414', '4', null, '苍梧县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2415', 'mainland', '2410', '0:003743:002364:002410:002415', '4', null, '藤县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2416', 'mainland', '2410', '0:003743:002364:002410:002416', '4', null, '蒙山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2417', 'mainland', '2410', '0:003743:002364:002410:002417', '4', null, '岑溪市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2418', 'mainland', '2410', '0:003743:002364:002410:002418', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2419', 'mainland', '2364', '0:003743:002364:002419', '3', '4505', '北海市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2420', 'mainland', '2419', '0:003743:002364:002419:002420', '4', null, '海城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2421', 'mainland', '2419', '0:003743:002364:002419:002421', '4', null, '银海区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2422', 'mainland', '2419', '0:003743:002364:002419:002422', '4', null, '铁山港区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2423', 'mainland', '2419', '0:003743:002364:002419:002423', '4', null, '合浦县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2424', 'mainland', '2419', '0:003743:002364:002419:002424', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2425', 'mainland', '2364', '0:003743:002364:002425', '3', '4506', '防城港市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2426', 'mainland', '2425', '0:003743:002364:002425:002426', '4', null, '港口区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2427', 'mainland', '2425', '0:003743:002364:002425:002427', '4', null, '防城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2428', 'mainland', '2425', '0:003743:002364:002425:002428', '4', null, '上思县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2429', 'mainland', '2425', '0:003743:002364:002425:002429', '4', null, '东兴市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2430', 'mainland', '2425', '0:003743:002364:002425:002430', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2431', 'mainland', '2364', '0:003743:002364:002431', '3', '4507', '钦州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2432', 'mainland', '2431', '0:003743:002364:002431:002432', '4', null, '钦南区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2433', 'mainland', '2431', '0:003743:002364:002431:002433', '4', null, '钦北区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2434', 'mainland', '2431', '0:003743:002364:002431:002434', '4', null, '灵山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2435', 'mainland', '2431', '0:003743:002364:002431:002435', '4', null, '浦北县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2436', 'mainland', '2431', '0:003743:002364:002431:002436', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2437', 'mainland', '2364', '0:003743:002364:002437', '3', '4508', '贵港市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2438', 'mainland', '2437', '0:003743:002364:002437:002438', '4', null, '港北区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2439', 'mainland', '2437', '0:003743:002364:002437:002439', '4', null, '港南区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2440', 'mainland', '2437', '0:003743:002364:002437:002440', '4', null, '覃塘区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2441', 'mainland', '2437', '0:003743:002364:002437:002441', '4', null, '平南县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2442', 'mainland', '2437', '0:003743:002364:002437:002442', '4', null, '桂平市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2443', 'mainland', '2437', '0:003743:002364:002437:002443', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2444', 'mainland', '2364', '0:003743:002364:002444', '3', '4509', '玉林市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2445', 'mainland', '2444', '0:003743:002364:002444:002445', '4', null, '玉州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2446', 'mainland', '2444', '0:003743:002364:002444:002446', '4', null, '容县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2447', 'mainland', '2444', '0:003743:002364:002444:002447', '4', null, '陆川县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2448', 'mainland', '2444', '0:003743:002364:002444:002448', '4', null, '博白县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2449', 'mainland', '2444', '0:003743:002364:002444:002449', '4', null, '兴业县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2450', 'mainland', '2444', '0:003743:002364:002444:002450', '4', null, '北流市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2451', 'mainland', '2444', '0:003743:002364:002444:002451', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2452', 'mainland', '2364', '0:003743:002364:002452', '3', '2452', '百色市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2453', 'mainland', '2452', '0:003743:002364:002452:002453', '4', null, '右江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2454', 'mainland', '2452', '0:003743:002364:002452:002454', '4', null, '田阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2455', 'mainland', '2452', '0:003743:002364:002452:002455', '4', null, '田东县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2456', 'mainland', '2452', '0:003743:002364:002452:002456', '4', null, '平果县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2457', 'mainland', '2452', '0:003743:002364:002452:002457', '4', null, '德保县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2458', 'mainland', '2452', '0:003743:002364:002452:002458', '4', null, '靖西县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2459', 'mainland', '2452', '0:003743:002364:002452:002459', '4', null, '那坡县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2460', 'mainland', '2452', '0:003743:002364:002452:002460', '4', null, '凌云县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2461', 'mainland', '2452', '0:003743:002364:002452:002461', '4', null, '乐业县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2462', 'mainland', '2452', '0:003743:002364:002452:002462', '4', null, '田林县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2463', 'mainland', '2452', '0:003743:002364:002452:002463', '4', null, '西林县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2464', 'mainland', '2452', '0:003743:002364:002452:002464', '4', null, '隆林各族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2465', 'mainland', '2452', '0:003743:002364:002452:002465', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2466', 'mainland', '2364', '0:003743:002364:002466', '3', '4511', '贺州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2467', 'mainland', '2466', '0:003743:002364:002466:002467', '4', null, '八步区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2468', 'mainland', '2466', '0:003743:002364:002466:002468', '4', null, '昭平县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2469', 'mainland', '2466', '0:003743:002364:002466:002469', '4', null, '钟山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2470', 'mainland', '2466', '0:003743:002364:002466:002470', '4', null, '富川瑶族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2471', 'mainland', '2466', '0:003743:002364:002466:002471', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2472', 'mainland', '2364', '0:003743:002364:002472', '3', '4512', '河池市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2473', 'mainland', '2472', '0:003743:002364:002472:002473', '4', null, '金城江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2474', 'mainland', '2472', '0:003743:002364:002472:002474', '4', null, '南丹县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2475', 'mainland', '2472', '0:003743:002364:002472:002475', '4', null, '天峨县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2476', 'mainland', '2472', '0:003743:002364:002472:002476', '4', null, '凤山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2477', 'mainland', '2472', '0:003743:002364:002472:002477', '4', null, '东兰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2478', 'mainland', '2472', '0:003743:002364:002472:002478', '4', null, '罗城仫佬族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2479', 'mainland', '2472', '0:003743:002364:002472:002479', '4', null, '环江毛南族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2480', 'mainland', '2472', '0:003743:002364:002472:002480', '4', null, '巴马瑶族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2481', 'mainland', '2472', '0:003743:002364:002472:002481', '4', null, '都安瑶族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2482', 'mainland', '2472', '0:003743:002364:002472:002482', '4', null, '大化瑶族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2483', 'mainland', '2472', '0:003743:002364:002472:002483', '4', null, '宜州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2484', 'mainland', '2472', '0:003743:002364:002472:002484', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2485', 'mainland', '2364', '0:003743:002364:002485', '3', '4513', '来宾市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2486', 'mainland', '2485', '0:003743:002364:002485:002486', '4', null, '兴宾区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2487', 'mainland', '2485', '0:003743:002364:002485:002487', '4', null, '忻城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2488', 'mainland', '2485', '0:003743:002364:002485:002488', '4', null, '象州县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2489', 'mainland', '2485', '0:003743:002364:002485:002489', '4', null, '武宣县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2490', 'mainland', '2485', '0:003743:002364:002485:002490', '4', null, '金秀瑶族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2491', 'mainland', '2485', '0:003743:002364:002485:002491', '4', null, '合山市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2492', 'mainland', '2485', '0:003743:002364:002485:002492', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2493', 'mainland', '2364', '0:003743:002364:002493', '3', '4514', '崇左市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2494', 'mainland', '2493', '0:003743:002364:002493:002494', '4', null, '江州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2495', 'mainland', '2493', '0:003743:002364:002493:002495', '4', null, '扶绥县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2496', 'mainland', '2493', '0:003743:002364:002493:002496', '4', null, '宁明县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2497', 'mainland', '2493', '0:003743:002364:002493:002497', '4', null, '龙州县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2498', 'mainland', '2493', '0:003743:002364:002493:002498', '4', null, '大新县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2499', 'mainland', '2493', '0:003743:002364:002493:002499', '4', null, '天等县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2500', 'mainland', '2493', '0:003743:002364:002493:002500', '4', null, '凭祥市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2501', 'mainland', '2493', '0:003743:002364:002493:002501', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2502', 'mainland', '3743', '0:003743:002502', '2', null, '海南省', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2503', 'mainland', '2502', '0:003743:002502:002503', '3', '4601', '海口市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2504', 'mainland', '2503', '0:003743:002502:002503:002504', '4', null, '秀英区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2505', 'mainland', '2503', '0:003743:002502:002503:002505', '4', null, '龙华区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2506', 'mainland', '2503', '0:003743:002502:002503:002506', '4', null, '琼山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2507', 'mainland', '2503', '0:003743:002502:002503:002507', '4', null, '美兰区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2508', 'mainland', '2503', '0:003743:002502:002503:002508', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2509', 'mainland', '2502', '0:003743:002502:002509', '3', '4602', '三亚市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2510', 'mainland', '2502', '0:003743:002502:002510', '3', '2510', '五指山市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2511', 'mainland', '2502', '0:003743:002502:002511', '3', '2511', '琼海市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2512', 'mainland', '2502', '0:003743:002502:002512', '3', '2512', '儋州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2513', 'mainland', '2502', '0:003743:002502:002513', '3', '2513', '文昌市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2514', 'mainland', '2502', '0:003743:002502:002514', '3', '2514', '万宁市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2515', 'mainland', '2502', '0:003743:002502:002515', '3', '2515', '东方市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2516', 'mainland', '2502', '0:003743:002502:002516', '3', '2516', '定安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2517', 'mainland', '2502', '0:003743:002502:002517', '3', '2517', '屯昌县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2518', 'mainland', '2502', '0:003743:002502:002518', '3', '2518', '澄迈县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2519', 'mainland', '2502', '0:003743:002502:002519', '3', '2519', '临高县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2520', 'mainland', '2502', '0:003743:002502:002520', '3', '2520', '白沙黎族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2521', 'mainland', '2502', '0:003743:002502:002521', '3', '2521', '昌江黎族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2522', 'mainland', '2502', '0:003743:002502:002522', '3', '2522', '乐东黎族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2523', 'mainland', '2502', '0:003743:002502:002523', '3', '2523', '陵水黎族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2524', 'mainland', '2502', '0:003743:002502:002524', '3', '2524', '保亭黎族苗族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2525', 'mainland', '2502', '0:003743:002502:002525', '3', '2525', '琼中黎族苗族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2526', 'mainland', '2502', '0:003743:002502:002526', '3', '2526', '西沙群岛', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2527', 'mainland', '2502', '0:003743:002502:002527', '3', '2527', '南沙群岛', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2528', 'mainland', '2502', '0:003743:002502:002528', '3', '2528', '中沙群岛的岛礁及其海域', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2529', 'mainland', '3743', '0:003743:002529', '2', null, '重庆', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2530', 'mainland', '2529', '0:003743:002529:002530', '3', '2530', '重庆市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2531', 'mainland', '2530', '0:003743:002529:002530:002531', '4', null, '万州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2532', 'mainland', '2530', '0:003743:002529:002530:002532', '4', null, '涪陵区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2533', 'mainland', '2530', '0:003743:002529:002530:002533', '4', null, '渝中区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2534', 'mainland', '2530', '0:003743:002529:002530:002534', '4', null, '大渡口区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2535', 'mainland', '2530', '0:003743:002529:002530:002535', '4', null, '江北区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2536', 'mainland', '2530', '0:003743:002529:002530:002536', '4', null, '沙坪坝区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2537', 'mainland', '2530', '0:003743:002529:002530:002537', '4', null, '九龙坡区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2538', 'mainland', '2530', '0:003743:002529:002530:002538', '4', null, '南岸区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2539', 'mainland', '2530', '0:003743:002529:002530:002539', '4', null, '北碚区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2540', 'mainland', '2530', '0:003743:002529:002530:002540', '4', null, '万盛区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2541', 'mainland', '2530', '0:003743:002529:002530:002541', '4', null, '双桥区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2542', 'mainland', '2530', '0:003743:002529:002530:002542', '4', null, '渝北区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2543', 'mainland', '2530', '0:003743:002529:002530:002543', '4', null, '巴南区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2544', 'mainland', '2530', '0:003743:002529:002530:002544', '4', null, '黔江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2545', 'mainland', '2530', '0:003743:002529:002530:002545', '4', null, '长寿区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2546', 'mainland', '2530', '0:003743:002529:002530:002546', '4', null, '綦江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2547', 'mainland', '2530', '0:003743:002529:002530:002547', '4', null, '潼南县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2548', 'mainland', '2530', '0:003743:002529:002530:002548', '4', null, '铜梁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2549', 'mainland', '2530', '0:003743:002529:002530:002549', '4', null, '大足县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2550', 'mainland', '2530', '0:003743:002529:002530:002550', '4', null, '荣昌县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2551', 'mainland', '2530', '0:003743:002529:002530:002551', '4', null, '璧山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2552', 'mainland', '2530', '0:003743:002529:002530:002552', '4', null, '梁平县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2553', 'mainland', '2530', '0:003743:002529:002530:002553', '4', null, '城口县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2554', 'mainland', '2530', '0:003743:002529:002530:002554', '4', null, '丰都县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2555', 'mainland', '2530', '0:003743:002529:002530:002555', '4', null, '垫江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2556', 'mainland', '2530', '0:003743:002529:002530:002556', '4', null, '武隆县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2557', 'mainland', '2530', '0:003743:002529:002530:002557', '4', null, '忠县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2558', 'mainland', '2530', '0:003743:002529:002530:002558', '4', null, '开县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2559', 'mainland', '2530', '0:003743:002529:002530:002559', '4', null, '云阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2560', 'mainland', '2530', '0:003743:002529:002530:002560', '4', null, '奉节县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2561', 'mainland', '2530', '0:003743:002529:002530:002561', '4', null, '巫山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2562', 'mainland', '2530', '0:003743:002529:002530:002562', '4', null, '巫溪县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2563', 'mainland', '2530', '0:003743:002529:002530:002563', '4', null, '石柱土家族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2564', 'mainland', '2530', '0:003743:002529:002530:002564', '4', null, '秀山土家族苗族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2565', 'mainland', '2530', '0:003743:002529:002530:002565', '4', null, '酉阳土家族苗族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2566', 'mainland', '2530', '0:003743:002529:002530:002566', '4', null, '彭水苗族土家族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2567', 'mainland', '2530', '0:003743:002529:002530:002567', '4', null, '江津区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2568', 'mainland', '2530', '0:003743:002529:002530:002568', '4', null, '合川区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2569', 'mainland', '2530', '0:003743:002529:002530:002569', '4', null, '永川区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2570', 'mainland', '2530', '0:003743:002529:002530:002570', '4', null, '南川区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2571', 'mainland', '2530', '0:003743:002529:002530:002571', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2572', 'mainland', '3743', '0:003743:002572', '2', null, '四川省', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2573', 'mainland', '2572', '0:003743:002572:002573', '3', '5101', '成都市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2574', 'mainland', '2573', '0:003743:002572:002573:002574', '4', null, '锦江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2575', 'mainland', '2573', '0:003743:002572:002573:002575', '4', null, '青羊区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2576', 'mainland', '2573', '0:003743:002572:002573:002576', '4', null, '金牛区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2577', 'mainland', '2573', '0:003743:002572:002573:002577', '4', null, '武侯区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2578', 'mainland', '2573', '0:003743:002572:002573:002578', '4', null, '成华区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2579', 'mainland', '2573', '0:003743:002572:002573:002579', '4', null, '龙泉驿区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2580', 'mainland', '2573', '0:003743:002572:002573:002580', '4', null, '青白江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2581', 'mainland', '2573', '0:003743:002572:002573:002581', '4', null, '新都区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2582', 'mainland', '2573', '0:003743:002572:002573:002582', '4', null, '温江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2583', 'mainland', '2573', '0:003743:002572:002573:002583', '4', null, '金堂县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2584', 'mainland', '2573', '0:003743:002572:002573:002584', '4', null, '双流县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2585', 'mainland', '2573', '0:003743:002572:002573:002585', '4', null, '郫县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2586', 'mainland', '2573', '0:003743:002572:002573:002586', '4', null, '大邑县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2587', 'mainland', '2573', '0:003743:002572:002573:002587', '4', null, '蒲江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2588', 'mainland', '2573', '0:003743:002572:002573:002588', '4', null, '新津县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2589', 'mainland', '2573', '0:003743:002572:002573:002589', '4', null, '都江堰市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2590', 'mainland', '2573', '0:003743:002572:002573:002590', '4', null, '彭州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2591', 'mainland', '2573', '0:003743:002572:002573:002591', '4', null, '邛崃市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2592', 'mainland', '2573', '0:003743:002572:002573:002592', '4', null, '崇州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2593', 'mainland', '2573', '0:003743:002572:002573:002593', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2594', 'mainland', '2572', '0:003743:002572:002594', '3', '5103', '自贡市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2595', 'mainland', '2594', '0:003743:002572:002594:002595', '4', null, '自流井区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2596', 'mainland', '2594', '0:003743:002572:002594:002596', '4', null, '贡井区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2597', 'mainland', '2594', '0:003743:002572:002594:002597', '4', null, '大安区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2598', 'mainland', '2594', '0:003743:002572:002594:002598', '4', null, '沿滩区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2599', 'mainland', '2594', '0:003743:002572:002594:002599', '4', null, '荣县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2600', 'mainland', '2594', '0:003743:002572:002594:002600', '4', null, '富顺县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2601', 'mainland', '2594', '0:003743:002572:002594:002601', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2602', 'mainland', '2572', '0:003743:002572:002602', '3', '5104', '攀枝花市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2603', 'mainland', '2602', '0:003743:002572:002602:002603', '4', null, '东区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2604', 'mainland', '2602', '0:003743:002572:002602:002604', '4', null, '西区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2605', 'mainland', '2602', '0:003743:002572:002602:002605', '4', null, '仁和区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2606', 'mainland', '2602', '0:003743:002572:002602:002606', '4', null, '米易县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2607', 'mainland', '2602', '0:003743:002572:002602:002607', '4', null, '盐边县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2608', 'mainland', '2602', '0:003743:002572:002602:002608', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2609', 'mainland', '2572', '0:003743:002572:002609', '3', '5105', '泸州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2610', 'mainland', '2609', '0:003743:002572:002609:002610', '4', null, '江阳区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2611', 'mainland', '2609', '0:003743:002572:002609:002611', '4', null, '纳溪区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2612', 'mainland', '2609', '0:003743:002572:002609:002612', '4', null, '龙马潭区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2613', 'mainland', '2609', '0:003743:002572:002609:002613', '4', null, '泸县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2614', 'mainland', '2609', '0:003743:002572:002609:002614', '4', null, '合江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2615', 'mainland', '2609', '0:003743:002572:002609:002615', '4', null, '叙永县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2616', 'mainland', '2609', '0:003743:002572:002609:002616', '4', null, '古蔺县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2617', 'mainland', '2609', '0:003743:002572:002609:002617', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2618', 'mainland', '2572', '0:003743:002572:002618', '3', '5106', '德阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2619', 'mainland', '2618', '0:003743:002572:002618:002619', '4', null, '旌阳区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2620', 'mainland', '2618', '0:003743:002572:002618:002620', '4', null, '中江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2621', 'mainland', '2618', '0:003743:002572:002618:002621', '4', null, '罗江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2622', 'mainland', '2618', '0:003743:002572:002618:002622', '4', null, '广汉市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2623', 'mainland', '2618', '0:003743:002572:002618:002623', '4', null, '什邡市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2624', 'mainland', '2618', '0:003743:002572:002618:002624', '4', null, '绵竹市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2625', 'mainland', '2618', '0:003743:002572:002618:002625', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2626', 'mainland', '2572', '0:003743:002572:002626', '3', '5107', '绵阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2627', 'mainland', '2626', '0:003743:002572:002626:002627', '4', null, '涪城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2628', 'mainland', '2626', '0:003743:002572:002626:002628', '4', null, '游仙区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2629', 'mainland', '2626', '0:003743:002572:002626:002629', '4', null, '三台县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2630', 'mainland', '2626', '0:003743:002572:002626:002630', '4', null, '盐亭县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2631', 'mainland', '2626', '0:003743:002572:002626:002631', '4', null, '安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2632', 'mainland', '2626', '0:003743:002572:002626:002632', '4', null, '梓潼县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2633', 'mainland', '2626', '0:003743:002572:002626:002633', '4', null, '北川羌族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2634', 'mainland', '2626', '0:003743:002572:002626:002634', '4', null, '平武县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2635', 'mainland', '2626', '0:003743:002572:002626:002635', '4', null, '高新区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2636', 'mainland', '2626', '0:003743:002572:002626:002636', '4', null, '江油市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2637', 'mainland', '2626', '0:003743:002572:002626:002637', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2638', 'mainland', '2572', '0:003743:002572:002638', '3', '5108', '广元市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2639', 'mainland', '2638', '0:003743:002572:002638:002639', '4', null, '利州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2640', 'mainland', '2638', '0:003743:002572:002638:002640', '4', null, '元坝区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2641', 'mainland', '2638', '0:003743:002572:002638:002641', '4', null, '朝天区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2642', 'mainland', '2638', '0:003743:002572:002638:002642', '4', null, '旺苍县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2643', 'mainland', '2638', '0:003743:002572:002638:002643', '4', null, '青川县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2644', 'mainland', '2638', '0:003743:002572:002638:002644', '4', null, '剑阁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2645', 'mainland', '2638', '0:003743:002572:002638:002645', '4', null, '苍溪县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2646', 'mainland', '2638', '0:003743:002572:002638:002646', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2647', 'mainland', '2572', '0:003743:002572:002647', '3', '5109', '遂宁市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2648', 'mainland', '2647', '0:003743:002572:002647:002648', '4', null, '船山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2649', 'mainland', '2647', '0:003743:002572:002647:002649', '4', null, '安居区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2650', 'mainland', '2647', '0:003743:002572:002647:002650', '4', null, '蓬溪县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2651', 'mainland', '2647', '0:003743:002572:002647:002651', '4', null, '射洪县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2652', 'mainland', '2647', '0:003743:002572:002647:002652', '4', null, '大英县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2653', 'mainland', '2647', '0:003743:002572:002647:002653', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2654', 'mainland', '2572', '0:003743:002572:002654', '3', '2654', '内江市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2655', 'mainland', '2654', '0:003743:002572:002654:002655', '4', null, '市中区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2656', 'mainland', '2654', '0:003743:002572:002654:002656', '4', null, '东兴区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2657', 'mainland', '2654', '0:003743:002572:002654:002657', '4', null, '威远县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2658', 'mainland', '2654', '0:003743:002572:002654:002658', '4', null, '资中县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2659', 'mainland', '2654', '0:003743:002572:002654:002659', '4', null, '隆昌县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2660', 'mainland', '2654', '0:003743:002572:002654:002660', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2661', 'mainland', '2572', '0:003743:002572:002661', '3', '5111', '乐山市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2662', 'mainland', '2661', '0:003743:002572:002661:002662', '4', null, '市中区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2663', 'mainland', '2661', '0:003743:002572:002661:002663', '4', null, '沙湾区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2664', 'mainland', '2661', '0:003743:002572:002661:002664', '4', null, '五通桥区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2665', 'mainland', '2661', '0:003743:002572:002661:002665', '4', null, '金口河区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2666', 'mainland', '2661', '0:003743:002572:002661:002666', '4', null, '犍为县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2667', 'mainland', '2661', '0:003743:002572:002661:002667', '4', null, '井研县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2668', 'mainland', '2661', '0:003743:002572:002661:002668', '4', null, '夹江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2669', 'mainland', '2661', '0:003743:002572:002661:002669', '4', null, '沐川县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2670', 'mainland', '2661', '0:003743:002572:002661:002670', '4', null, '峨边彝族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2671', 'mainland', '2661', '0:003743:002572:002661:002671', '4', null, '马边彝族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2672', 'mainland', '2661', '0:003743:002572:002661:002672', '4', null, '峨眉山市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2673', 'mainland', '2661', '0:003743:002572:002661:002673', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2674', 'mainland', '2572', '0:003743:002572:002674', '3', '5113', '南充市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2675', 'mainland', '2674', '0:003743:002572:002674:002675', '4', null, '顺庆区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2676', 'mainland', '2674', '0:003743:002572:002674:002676', '4', null, '高坪区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2677', 'mainland', '2674', '0:003743:002572:002674:002677', '4', null, '嘉陵区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2678', 'mainland', '2674', '0:003743:002572:002674:002678', '4', null, '南部县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2679', 'mainland', '2674', '0:003743:002572:002674:002679', '4', null, '营山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2680', 'mainland', '2674', '0:003743:002572:002674:002680', '4', null, '蓬安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2681', 'mainland', '2674', '0:003743:002572:002674:002681', '4', null, '仪陇县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2682', 'mainland', '2674', '0:003743:002572:002674:002682', '4', null, '西充县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2683', 'mainland', '2674', '0:003743:002572:002674:002683', '4', null, '阆中市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2684', 'mainland', '2674', '0:003743:002572:002674:002684', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2685', 'mainland', '2572', '0:003743:002572:002685', '3', '5114', '眉山市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2686', 'mainland', '2685', '0:003743:002572:002685:002686', '4', null, '东坡区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2687', 'mainland', '2685', '0:003743:002572:002685:002687', '4', null, '仁寿县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2688', 'mainland', '2685', '0:003743:002572:002685:002688', '4', null, '彭山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2689', 'mainland', '2685', '0:003743:002572:002685:002689', '4', null, '洪雅县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2690', 'mainland', '2685', '0:003743:002572:002685:002690', '4', null, '丹棱县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2691', 'mainland', '2685', '0:003743:002572:002685:002691', '4', null, '青神县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2692', 'mainland', '2685', '0:003743:002572:002685:002692', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2693', 'mainland', '2572', '0:003743:002572:002693', '3', '5115', '宜宾市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2694', 'mainland', '2693', '0:003743:002572:002693:002694', '4', null, '翠屏区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2695', 'mainland', '2693', '0:003743:002572:002693:002695', '4', null, '宜宾县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2696', 'mainland', '2693', '0:003743:002572:002693:002696', '4', null, '南溪县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2697', 'mainland', '2693', '0:003743:002572:002693:002697', '4', null, '江安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2698', 'mainland', '2693', '0:003743:002572:002693:002698', '4', null, '长宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2699', 'mainland', '2693', '0:003743:002572:002693:002699', '4', null, '高县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2700', 'mainland', '2693', '0:003743:002572:002693:002700', '4', null, '珙县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2701', 'mainland', '2693', '0:003743:002572:002693:002701', '4', null, '筠连县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2702', 'mainland', '2693', '0:003743:002572:002693:002702', '4', null, '兴文县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2703', 'mainland', '2693', '0:003743:002572:002693:002703', '4', null, '屏山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2704', 'mainland', '2693', '0:003743:002572:002693:002704', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2705', 'mainland', '2572', '0:003743:002572:002705', '3', '5116', '广安市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2706', 'mainland', '2705', '0:003743:002572:002705:002706', '4', null, '广安区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2707', 'mainland', '2705', '0:003743:002572:002705:002707', '4', null, '岳池县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2708', 'mainland', '2705', '0:003743:002572:002705:002708', '4', null, '武胜县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2709', 'mainland', '2705', '0:003743:002572:002705:002709', '4', null, '邻水县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2710', 'mainland', '2705', '0:003743:002572:002705:002710', '4', null, '华蓥市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2711', 'mainland', '2705', '0:003743:002572:002705:002711', '4', null, '市辖区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2712', 'mainland', '2705', '0:003743:002572:002705:002712', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2713', 'mainland', '2572', '0:003743:002572:002713', '3', '5117', '达州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2714', 'mainland', '2713', '0:003743:002572:002713:002714', '4', null, '通川区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2715', 'mainland', '2713', '0:003743:002572:002713:002715', '4', null, '达县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2716', 'mainland', '2713', '0:003743:002572:002713:002716', '4', null, '宣汉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2717', 'mainland', '2713', '0:003743:002572:002713:002717', '4', null, '开江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2718', 'mainland', '2713', '0:003743:002572:002713:002718', '4', null, '大竹县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2719', 'mainland', '2713', '0:003743:002572:002713:002719', '4', null, '渠县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2720', 'mainland', '2713', '0:003743:002572:002713:002720', '4', null, '万源市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2721', 'mainland', '2713', '0:003743:002572:002713:002721', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2722', 'mainland', '2572', '0:003743:002572:002722', '3', '5118', '雅安市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2723', 'mainland', '2722', '0:003743:002572:002722:002723', '4', null, '雨城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2724', 'mainland', '2722', '0:003743:002572:002722:002724', '4', null, '名山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2725', 'mainland', '2722', '0:003743:002572:002722:002725', '4', null, '荥经县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2726', 'mainland', '2722', '0:003743:002572:002722:002726', '4', null, '汉源县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2727', 'mainland', '2722', '0:003743:002572:002722:002727', '4', null, '石棉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2728', 'mainland', '2722', '0:003743:002572:002722:002728', '4', null, '天全县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2729', 'mainland', '2722', '0:003743:002572:002722:002729', '4', null, '芦山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2730', 'mainland', '2722', '0:003743:002572:002722:002730', '4', null, '宝兴县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2731', 'mainland', '2722', '0:003743:002572:002722:002731', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2732', 'mainland', '2572', '0:003743:002572:002732', '3', '5119', '巴中市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2733', 'mainland', '2732', '0:003743:002572:002732:002733', '4', null, '巴州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2734', 'mainland', '2732', '0:003743:002572:002732:002734', '4', null, '通江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2735', 'mainland', '2732', '0:003743:002572:002732:002735', '4', null, '南江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2736', 'mainland', '2732', '0:003743:002572:002732:002736', '4', null, '平昌县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2737', 'mainland', '2732', '0:003743:002572:002732:002737', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2738', 'mainland', '2572', '0:003743:002572:002738', '3', '2738', '资阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2739', 'mainland', '2738', '0:003743:002572:002738:002739', '4', null, '雁江区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2740', 'mainland', '2738', '0:003743:002572:002738:002740', '4', null, '安岳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2741', 'mainland', '2738', '0:003743:002572:002738:002741', '4', null, '乐至县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2742', 'mainland', '2738', '0:003743:002572:002738:002742', '4', null, '简阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2743', 'mainland', '2738', '0:003743:002572:002738:002743', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2744', 'mainland', '2572', '0:003743:002572:002744', '3', '5132', '阿坝藏族羌族自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2745', 'mainland', '2744', '0:003743:002572:002744:002745', '4', null, '汶川县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2746', 'mainland', '2744', '0:003743:002572:002744:002746', '4', null, '理县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2747', 'mainland', '2744', '0:003743:002572:002744:002747', '4', null, '茂县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2748', 'mainland', '2744', '0:003743:002572:002744:002748', '4', null, '松潘县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2749', 'mainland', '2744', '0:003743:002572:002744:002749', '4', null, '九寨沟县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2750', 'mainland', '2744', '0:003743:002572:002744:002750', '4', null, '金川县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2751', 'mainland', '2744', '0:003743:002572:002744:002751', '4', null, '小金县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2752', 'mainland', '2744', '0:003743:002572:002744:002752', '4', null, '黑水县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2753', 'mainland', '2744', '0:003743:002572:002744:002753', '4', null, '马尔康县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2754', 'mainland', '2744', '0:003743:002572:002744:002754', '4', null, '壤塘县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2755', 'mainland', '2744', '0:003743:002572:002744:002755', '4', null, '阿坝县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2756', 'mainland', '2744', '0:003743:002572:002744:002756', '4', null, '若尔盖县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2757', 'mainland', '2744', '0:003743:002572:002744:002757', '4', null, '红原县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2758', 'mainland', '2744', '0:003743:002572:002744:002758', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2759', 'mainland', '2572', '0:003743:002572:002759', '3', '5133', '甘孜藏族自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2760', 'mainland', '2759', '0:003743:002572:002759:002760', '4', null, '康定县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2761', 'mainland', '2759', '0:003743:002572:002759:002761', '4', null, '泸定县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2762', 'mainland', '2759', '0:003743:002572:002759:002762', '4', null, '丹巴县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2763', 'mainland', '2759', '0:003743:002572:002759:002763', '4', null, '九龙县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2764', 'mainland', '2759', '0:003743:002572:002759:002764', '4', null, '雅江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2765', 'mainland', '2759', '0:003743:002572:002759:002765', '4', null, '道孚县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2766', 'mainland', '2759', '0:003743:002572:002759:002766', '4', null, '炉霍县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2767', 'mainland', '2759', '0:003743:002572:002759:002767', '4', null, '甘孜县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2768', 'mainland', '2759', '0:003743:002572:002759:002768', '4', null, '新龙县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2769', 'mainland', '2759', '0:003743:002572:002759:002769', '4', null, '德格县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2770', 'mainland', '2759', '0:003743:002572:002759:002770', '4', null, '白玉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2771', 'mainland', '2759', '0:003743:002572:002759:002771', '4', null, '石渠县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2772', 'mainland', '2759', '0:003743:002572:002759:002772', '4', null, '色达县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2773', 'mainland', '2759', '0:003743:002572:002759:002773', '4', null, '理塘县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2774', 'mainland', '2759', '0:003743:002572:002759:002774', '4', null, '巴塘县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2775', 'mainland', '2759', '0:003743:002572:002759:002775', '4', null, '乡城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2776', 'mainland', '2759', '0:003743:002572:002759:002776', '4', null, '稻城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2777', 'mainland', '2759', '0:003743:002572:002759:002777', '4', null, '得荣县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2778', 'mainland', '2759', '0:003743:002572:002759:002778', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2779', 'mainland', '2572', '0:003743:002572:002779', '3', '5134', '凉山彝族自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2780', 'mainland', '2779', '0:003743:002572:002779:002780', '4', null, '西昌市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2781', 'mainland', '2779', '0:003743:002572:002779:002781', '4', null, '木里藏族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2782', 'mainland', '2779', '0:003743:002572:002779:002782', '4', null, '盐源县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2783', 'mainland', '2779', '0:003743:002572:002779:002783', '4', null, '德昌县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2784', 'mainland', '2779', '0:003743:002572:002779:002784', '4', null, '会理县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2785', 'mainland', '2779', '0:003743:002572:002779:002785', '4', null, '会东县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2786', 'mainland', '2779', '0:003743:002572:002779:002786', '4', null, '宁南县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2787', 'mainland', '2779', '0:003743:002572:002779:002787', '4', null, '普格县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2788', 'mainland', '2779', '0:003743:002572:002779:002788', '4', null, '布拖县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2789', 'mainland', '2779', '0:003743:002572:002779:002789', '4', null, '金阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2790', 'mainland', '2779', '0:003743:002572:002779:002790', '4', null, '昭觉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2791', 'mainland', '2779', '0:003743:002572:002779:002791', '4', null, '喜德县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2792', 'mainland', '2779', '0:003743:002572:002779:002792', '4', null, '冕宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2793', 'mainland', '2779', '0:003743:002572:002779:002793', '4', null, '越西县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2794', 'mainland', '2779', '0:003743:002572:002779:002794', '4', null, '甘洛县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2795', 'mainland', '2779', '0:003743:002572:002779:002795', '4', null, '美姑县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2796', 'mainland', '2779', '0:003743:002572:002779:002796', '4', null, '雷波县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2797', 'mainland', '2779', '0:003743:002572:002779:002797', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2798', 'mainland', '3743', '0:003743:002798', '2', null, '贵州省', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2799', 'mainland', '2798', '0:003743:002798:002799', '3', '5201', '贵阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2800', 'mainland', '2799', '0:003743:002798:002799:002800', '4', null, '南明区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2801', 'mainland', '2799', '0:003743:002798:002799:002801', '4', null, '云岩区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2802', 'mainland', '2799', '0:003743:002798:002799:002802', '4', null, '花溪区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2803', 'mainland', '2799', '0:003743:002798:002799:002803', '4', null, '乌当区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2804', 'mainland', '2799', '0:003743:002798:002799:002804', '4', null, '白云区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2805', 'mainland', '2799', '0:003743:002798:002799:002805', '4', null, '小河区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2806', 'mainland', '2799', '0:003743:002798:002799:002806', '4', null, '开阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2807', 'mainland', '2799', '0:003743:002798:002799:002807', '4', null, '息烽县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2808', 'mainland', '2799', '0:003743:002798:002799:002808', '4', null, '修文县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2809', 'mainland', '2799', '0:003743:002798:002799:002809', '4', null, '金阳开发区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2810', 'mainland', '2799', '0:003743:002798:002799:002810', '4', null, '清镇市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2811', 'mainland', '2799', '0:003743:002798:002799:002811', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2812', 'mainland', '2798', '0:003743:002798:002812', '3', '5202', '六盘水市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2813', 'mainland', '2812', '0:003743:002798:002812:002813', '4', null, '钟山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2814', 'mainland', '2812', '0:003743:002798:002812:002814', '4', null, '六枝特区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2815', 'mainland', '2812', '0:003743:002798:002812:002815', '4', null, '水城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2816', 'mainland', '2812', '0:003743:002798:002812:002816', '4', null, '盘县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2817', 'mainland', '2812', '0:003743:002798:002812:002817', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2818', 'mainland', '2798', '0:003743:002798:002818', '3', '5203', '遵义市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2819', 'mainland', '2818', '0:003743:002798:002818:002819', '4', null, '红花岗区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2820', 'mainland', '2818', '0:003743:002798:002818:002820', '4', null, '汇川区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2821', 'mainland', '2818', '0:003743:002798:002818:002821', '4', null, '遵义县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2822', 'mainland', '2818', '0:003743:002798:002818:002822', '4', null, '桐梓县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2823', 'mainland', '2818', '0:003743:002798:002818:002823', '4', null, '绥阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2824', 'mainland', '2818', '0:003743:002798:002818:002824', '4', null, '正安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2825', 'mainland', '2818', '0:003743:002798:002818:002825', '4', null, '道真仡佬族苗族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2826', 'mainland', '2818', '0:003743:002798:002818:002826', '4', null, '务川仡佬族苗族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2827', 'mainland', '2818', '0:003743:002798:002818:002827', '4', null, '凤冈县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2828', 'mainland', '2818', '0:003743:002798:002818:002828', '4', null, '湄潭县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2829', 'mainland', '2818', '0:003743:002798:002818:002829', '4', null, '余庆县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2830', 'mainland', '2818', '0:003743:002798:002818:002830', '4', null, '习水县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2831', 'mainland', '2818', '0:003743:002798:002818:002831', '4', null, '赤水市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2832', 'mainland', '2818', '0:003743:002798:002818:002832', '4', null, '仁怀市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2833', 'mainland', '2818', '0:003743:002798:002818:002833', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2834', 'mainland', '2798', '0:003743:002798:002834', '3', '5204', '安顺市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2835', 'mainland', '2834', '0:003743:002798:002834:002835', '4', null, '西秀区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2836', 'mainland', '2834', '0:003743:002798:002834:002836', '4', null, '平坝县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2837', 'mainland', '2834', '0:003743:002798:002834:002837', '4', null, '普定县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2838', 'mainland', '2834', '0:003743:002798:002834:002838', '4', null, '镇宁布依族苗族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2839', 'mainland', '2834', '0:003743:002798:002834:002839', '4', null, '关岭布依族苗族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2840', 'mainland', '2834', '0:003743:002798:002834:002840', '4', null, '紫云苗族布依族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2841', 'mainland', '2834', '0:003743:002798:002834:002841', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2842', 'mainland', '2798', '0:003743:002798:002842', '3', '2842', '铜仁地区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2843', 'mainland', '2842', '0:003743:002798:002842:002843', '4', '5206', '铜仁市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2844', 'mainland', '2842', '0:003743:002798:002842:002844', '4', null, '江口县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2845', 'mainland', '2842', '0:003743:002798:002842:002845', '4', null, '玉屏侗族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2846', 'mainland', '2842', '0:003743:002798:002842:002846', '4', null, '石阡县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2847', 'mainland', '2842', '0:003743:002798:002842:002847', '4', null, '思南县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2848', 'mainland', '2842', '0:003743:002798:002842:002848', '4', null, '印江土家族苗族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2849', 'mainland', '2842', '0:003743:002798:002842:002849', '4', null, '德江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2850', 'mainland', '2842', '0:003743:002798:002842:002850', '4', null, '沿河土家族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2851', 'mainland', '2842', '0:003743:002798:002842:002851', '4', null, '松桃苗族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2852', 'mainland', '2842', '0:003743:002798:002842:002852', '4', null, '万山特区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2853', 'mainland', '2842', '0:003743:002798:002842:002853', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2854', 'mainland', '2798', '0:003743:002798:002854', '3', '5223', '黔西南布依族苗族自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2855', 'mainland', '2854', '0:003743:002798:002854:002855', '4', null, '兴义市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2856', 'mainland', '2854', '0:003743:002798:002854:002856', '4', null, '兴仁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2857', 'mainland', '2854', '0:003743:002798:002854:002857', '4', null, '普安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2858', 'mainland', '2854', '0:003743:002798:002854:002858', '4', null, '晴隆县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2859', 'mainland', '2854', '0:003743:002798:002854:002859', '4', null, '贞丰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2860', 'mainland', '2854', '0:003743:002798:002854:002860', '4', null, '望谟县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2861', 'mainland', '2854', '0:003743:002798:002854:002861', '4', null, '册亨县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2862', 'mainland', '2854', '0:003743:002798:002854:002862', '4', null, '安龙县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2863', 'mainland', '2854', '0:003743:002798:002854:002863', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2864', 'mainland', '2798', '0:003743:002798:002864', '3', '2864', '毕节地区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2865', 'mainland', '2864', '0:003743:002798:002864:002865', '4', '5205', '毕节市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2866', 'mainland', '2864', '0:003743:002798:002864:002866', '4', null, '大方县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2867', 'mainland', '2864', '0:003743:002798:002864:002867', '4', null, '黔西县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2868', 'mainland', '2864', '0:003743:002798:002864:002868', '4', null, '金沙县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2869', 'mainland', '2864', '0:003743:002798:002864:002869', '4', null, '织金县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2870', 'mainland', '2864', '0:003743:002798:002864:002870', '4', null, '纳雍县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2871', 'mainland', '2864', '0:003743:002798:002864:002871', '4', null, '威宁彝族回族苗族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2872', 'mainland', '2864', '0:003743:002798:002864:002872', '4', null, '赫章县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2873', 'mainland', '2864', '0:003743:002798:002864:002873', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2874', 'mainland', '2798', '0:003743:002798:002874', '3', '5226', '黔东南苗族侗族自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2875', 'mainland', '2874', '0:003743:002798:002874:002875', '4', null, '凯里市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2876', 'mainland', '2874', '0:003743:002798:002874:002876', '4', null, '黄平县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2877', 'mainland', '2874', '0:003743:002798:002874:002877', '4', null, '施秉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2878', 'mainland', '2874', '0:003743:002798:002874:002878', '4', null, '三穗县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2879', 'mainland', '2874', '0:003743:002798:002874:002879', '4', null, '镇远县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2880', 'mainland', '2874', '0:003743:002798:002874:002880', '4', null, '岑巩县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2881', 'mainland', '2874', '0:003743:002798:002874:002881', '4', null, '天柱县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2882', 'mainland', '2874', '0:003743:002798:002874:002882', '4', null, '锦屏县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2883', 'mainland', '2874', '0:003743:002798:002874:002883', '4', null, '剑河县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2884', 'mainland', '2874', '0:003743:002798:002874:002884', '4', null, '台江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2885', 'mainland', '2874', '0:003743:002798:002874:002885', '4', null, '黎平县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2886', 'mainland', '2874', '0:003743:002798:002874:002886', '4', null, '榕江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2887', 'mainland', '2874', '0:003743:002798:002874:002887', '4', null, '从江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2888', 'mainland', '2874', '0:003743:002798:002874:002888', '4', null, '雷山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2889', 'mainland', '2874', '0:003743:002798:002874:002889', '4', null, '麻江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2890', 'mainland', '2874', '0:003743:002798:002874:002890', '4', null, '丹寨县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2891', 'mainland', '2874', '0:003743:002798:002874:002891', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2892', 'mainland', '2798', '0:003743:002798:002892', '3', '5227', '黔南布依族苗族自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2893', 'mainland', '2892', '0:003743:002798:002892:002893', '4', null, '都匀市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2894', 'mainland', '2892', '0:003743:002798:002892:002894', '4', null, '福泉市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2895', 'mainland', '2892', '0:003743:002798:002892:002895', '4', null, '荔波县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2896', 'mainland', '2892', '0:003743:002798:002892:002896', '4', null, '贵定县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2897', 'mainland', '2892', '0:003743:002798:002892:002897', '4', null, '瓮安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2898', 'mainland', '2892', '0:003743:002798:002892:002898', '4', null, '独山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2899', 'mainland', '2892', '0:003743:002798:002892:002899', '4', null, '平塘县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2900', 'mainland', '2892', '0:003743:002798:002892:002900', '4', null, '罗甸县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2901', 'mainland', '2892', '0:003743:002798:002892:002901', '4', null, '长顺县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2902', 'mainland', '2892', '0:003743:002798:002892:002902', '4', null, '龙里县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2903', 'mainland', '2892', '0:003743:002798:002892:002903', '4', null, '惠水县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2904', 'mainland', '2892', '0:003743:002798:002892:002904', '4', null, '三都水族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2905', 'mainland', '2892', '0:003743:002798:002892:002905', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2906', 'mainland', '3743', '0:003743:002906', '2', null, '云南省', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2907', 'mainland', '2906', '0:003743:002906:002907', '3', '5301', '昆明市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2908', 'mainland', '2907', '0:003743:002906:002907:002908', '4', null, '五华区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2909', 'mainland', '2907', '0:003743:002906:002907:002909', '4', null, '盘龙区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2910', 'mainland', '2907', '0:003743:002906:002907:002910', '4', null, '官渡区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2911', 'mainland', '2907', '0:003743:002906:002907:002911', '4', null, '西山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2912', 'mainland', '2907', '0:003743:002906:002907:002912', '4', null, '东川区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2913', 'mainland', '2907', '0:003743:002906:002907:002913', '4', null, '呈贡县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2914', 'mainland', '2907', '0:003743:002906:002907:002914', '4', null, '晋宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2915', 'mainland', '2907', '0:003743:002906:002907:002915', '4', null, '富民县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2916', 'mainland', '2907', '0:003743:002906:002907:002916', '4', null, '宜良县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2917', 'mainland', '2907', '0:003743:002906:002907:002917', '4', null, '石林彝族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2918', 'mainland', '2907', '0:003743:002906:002907:002918', '4', null, '嵩明县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2919', 'mainland', '2907', '0:003743:002906:002907:002919', '4', null, '禄劝彝族苗族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2920', 'mainland', '2907', '0:003743:002906:002907:002920', '4', null, '寻甸回族彝族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2921', 'mainland', '2907', '0:003743:002906:002907:002921', '4', null, '安宁市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2922', 'mainland', '2907', '0:003743:002906:002907:002922', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2923', 'mainland', '2906', '0:003743:002906:002923', '3', '5303', '曲靖市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2924', 'mainland', '2923', '0:003743:002906:002923:002924', '4', null, '麒麟区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2925', 'mainland', '2923', '0:003743:002906:002923:002925', '4', null, '马龙县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2926', 'mainland', '2923', '0:003743:002906:002923:002926', '4', null, '陆良县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2927', 'mainland', '2923', '0:003743:002906:002923:002927', '4', null, '师宗县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2928', 'mainland', '2923', '0:003743:002906:002923:002928', '4', null, '罗平县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2929', 'mainland', '2923', '0:003743:002906:002923:002929', '4', null, '富源县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2930', 'mainland', '2923', '0:003743:002906:002923:002930', '4', null, '会泽县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2931', 'mainland', '2923', '0:003743:002906:002923:002931', '4', null, '沾益县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2932', 'mainland', '2923', '0:003743:002906:002923:002932', '4', null, '宣威市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2933', 'mainland', '2923', '0:003743:002906:002923:002933', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2934', 'mainland', '2906', '0:003743:002906:002934', '3', '5304', '玉溪市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2935', 'mainland', '2934', '0:003743:002906:002934:002935', '4', null, '红塔区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2936', 'mainland', '2934', '0:003743:002906:002934:002936', '4', null, '江川县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2937', 'mainland', '2934', '0:003743:002906:002934:002937', '4', null, '澄江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2938', 'mainland', '2934', '0:003743:002906:002934:002938', '4', null, '通海县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2939', 'mainland', '2934', '0:003743:002906:002934:002939', '4', null, '华宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2940', 'mainland', '2934', '0:003743:002906:002934:002940', '4', null, '易门县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2941', 'mainland', '2934', '0:003743:002906:002934:002941', '4', null, '峨山彝族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2942', 'mainland', '2934', '0:003743:002906:002934:002942', '4', null, '新平彝族傣族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2943', 'mainland', '2934', '0:003743:002906:002934:002943', '4', null, '元江哈尼族彝族傣族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2944', 'mainland', '2934', '0:003743:002906:002934:002944', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2945', 'mainland', '2906', '0:003743:002906:002945', '3', '5305', '保山市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2946', 'mainland', '2945', '0:003743:002906:002945:002946', '4', null, '隆阳区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2947', 'mainland', '2945', '0:003743:002906:002945:002947', '4', null, '施甸县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2948', 'mainland', '2945', '0:003743:002906:002945:002948', '4', null, '腾冲县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2949', 'mainland', '2945', '0:003743:002906:002945:002949', '4', null, '龙陵县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2950', 'mainland', '2945', '0:003743:002906:002945:002950', '4', null, '昌宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2951', 'mainland', '2945', '0:003743:002906:002945:002951', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2952', 'mainland', '2906', '0:003743:002906:002952', '3', '5306', '昭通市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2953', 'mainland', '2952', '0:003743:002906:002952:002953', '4', null, '昭阳区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2954', 'mainland', '2952', '0:003743:002906:002952:002954', '4', null, '鲁甸县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2955', 'mainland', '2952', '0:003743:002906:002952:002955', '4', null, '巧家县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2956', 'mainland', '2952', '0:003743:002906:002952:002956', '4', null, '盐津县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2957', 'mainland', '2952', '0:003743:002906:002952:002957', '4', null, '大关县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2958', 'mainland', '2952', '0:003743:002906:002952:002958', '4', null, '永善县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2959', 'mainland', '2952', '0:003743:002906:002952:002959', '4', null, '绥江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2960', 'mainland', '2952', '0:003743:002906:002952:002960', '4', null, '镇雄县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2961', 'mainland', '2952', '0:003743:002906:002952:002961', '4', null, '彝良县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2962', 'mainland', '2952', '0:003743:002906:002952:002962', '4', null, '威信县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2963', 'mainland', '2952', '0:003743:002906:002952:002963', '4', null, '水富县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2964', 'mainland', '2952', '0:003743:002906:002952:002964', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2965', 'mainland', '2906', '0:003743:002906:002965', '3', '5307', '丽江市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2966', 'mainland', '2965', '0:003743:002906:002965:002966', '4', null, '古城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2967', 'mainland', '2965', '0:003743:002906:002965:002967', '4', null, '玉龙纳西族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2968', 'mainland', '2965', '0:003743:002906:002965:002968', '4', null, '永胜县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2969', 'mainland', '2965', '0:003743:002906:002965:002969', '4', null, '华坪县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2970', 'mainland', '2965', '0:003743:002906:002965:002970', '4', null, '宁蒗彝族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2971', 'mainland', '2965', '0:003743:002906:002965:002971', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2972', 'mainland', '2906', '0:003743:002906:002972', '3', '5308', '普洱市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2973', 'mainland', '2972', '0:003743:002906:002972:002973', '4', null, '思茅区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2974', 'mainland', '2972', '0:003743:002906:002972:002974', '4', null, '宁洱哈尼族彝族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2975', 'mainland', '2972', '0:003743:002906:002972:002975', '4', null, '墨江哈尼族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2976', 'mainland', '2972', '0:003743:002906:002972:002976', '4', null, '景东彝族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2977', 'mainland', '2972', '0:003743:002906:002972:002977', '4', null, '景谷傣族彝族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2978', 'mainland', '2972', '0:003743:002906:002972:002978', '4', null, '镇沅彝族哈尼族拉祜族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2979', 'mainland', '2972', '0:003743:002906:002972:002979', '4', null, '江城哈尼族彝族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2980', 'mainland', '2972', '0:003743:002906:002972:002980', '4', null, '孟连傣族拉祜族佤族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2981', 'mainland', '2972', '0:003743:002906:002972:002981', '4', null, '澜沧拉祜族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2982', 'mainland', '2972', '0:003743:002906:002972:002982', '4', null, '西盟佤族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2983', 'mainland', '2972', '0:003743:002906:002972:002983', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2984', 'mainland', '2906', '0:003743:002906:002984', '3', '5309', '临沧市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2985', 'mainland', '2984', '0:003743:002906:002984:002985', '4', null, '临翔区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2986', 'mainland', '2984', '0:003743:002906:002984:002986', '4', null, '凤庆县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2987', 'mainland', '2984', '0:003743:002906:002984:002987', '4', null, '云县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2988', 'mainland', '2984', '0:003743:002906:002984:002988', '4', null, '永德县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2989', 'mainland', '2984', '0:003743:002906:002984:002989', '4', null, '镇康县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2990', 'mainland', '2984', '0:003743:002906:002984:002990', '4', null, '双江拉祜族佤族布朗族傣族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2991', 'mainland', '2984', '0:003743:002906:002984:002991', '4', null, '耿马傣族佤族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2992', 'mainland', '2984', '0:003743:002906:002984:002992', '4', null, '沧源佤族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2993', 'mainland', '2984', '0:003743:002906:002984:002993', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2994', 'mainland', '2906', '0:003743:002906:002994', '3', '5323', '楚雄彝族自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2995', 'mainland', '2994', '0:003743:002906:002994:002995', '4', null, '楚雄市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2996', 'mainland', '2994', '0:003743:002906:002994:002996', '4', null, '双柏县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2997', 'mainland', '2994', '0:003743:002906:002994:002997', '4', null, '牟定县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2998', 'mainland', '2994', '0:003743:002906:002994:002998', '4', null, '南华县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('2999', 'mainland', '2994', '0:003743:002906:002994:002999', '4', null, '姚安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3000', 'mainland', '2994', '0:003743:002906:002994:003000', '4', null, '大姚县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3001', 'mainland', '2994', '0:003743:002906:002994:003001', '4', null, '永仁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3002', 'mainland', '2994', '0:003743:002906:002994:003002', '4', null, '元谋县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3003', 'mainland', '2994', '0:003743:002906:002994:003003', '4', null, '武定县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3004', 'mainland', '2994', '0:003743:002906:002994:003004', '4', null, '禄丰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3005', 'mainland', '2994', '0:003743:002906:002994:003005', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3006', 'mainland', '2906', '0:003743:002906:003006', '3', '5325', '红河哈尼族彝族自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3007', 'mainland', '3006', '0:003743:002906:003006:003007', '4', null, '个旧市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3008', 'mainland', '3006', '0:003743:002906:003006:003008', '4', null, '开远市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3009', 'mainland', '3006', '0:003743:002906:003006:003009', '4', null, '蒙自县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3010', 'mainland', '3006', '0:003743:002906:003006:003010', '4', null, '屏边苗族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3011', 'mainland', '3006', '0:003743:002906:003006:003011', '4', null, '建水县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3012', 'mainland', '3006', '0:003743:002906:003006:003012', '4', null, '石屏县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3013', 'mainland', '3006', '0:003743:002906:003006:003013', '4', null, '弥勒县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3014', 'mainland', '3006', '0:003743:002906:003006:003014', '4', null, '泸西县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3015', 'mainland', '3006', '0:003743:002906:003006:003015', '4', null, '元阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3016', 'mainland', '3006', '0:003743:002906:003006:003016', '4', null, '红河县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3017', 'mainland', '3006', '0:003743:002906:003006:003017', '4', null, '金平苗族瑶族傣族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3018', 'mainland', '3006', '0:003743:002906:003006:003018', '4', null, '绿春县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3019', 'mainland', '3006', '0:003743:002906:003006:003019', '4', null, '河口瑶族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3020', 'mainland', '3006', '0:003743:002906:003006:003020', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3021', 'mainland', '2906', '0:003743:002906:003021', '3', '5326', '文山壮族苗族自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3022', 'mainland', '3021', '0:003743:002906:003021:003022', '4', null, '文山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3023', 'mainland', '3021', '0:003743:002906:003021:003023', '4', null, '砚山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3024', 'mainland', '3021', '0:003743:002906:003021:003024', '4', null, '西畴县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3025', 'mainland', '3021', '0:003743:002906:003021:003025', '4', null, '麻栗坡县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3026', 'mainland', '3021', '0:003743:002906:003021:003026', '4', null, '马关县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3027', 'mainland', '3021', '0:003743:002906:003021:003027', '4', null, '丘北县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3028', 'mainland', '3021', '0:003743:002906:003021:003028', '4', null, '广南县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3029', 'mainland', '3021', '0:003743:002906:003021:003029', '4', null, '富宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3030', 'mainland', '3021', '0:003743:002906:003021:003030', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3031', 'mainland', '2906', '0:003743:002906:003031', '3', '5328', '西双版纳傣族自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3032', 'mainland', '3031', '0:003743:002906:003031:003032', '4', null, '景洪市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3033', 'mainland', '3031', '0:003743:002906:003031:003033', '4', null, '勐海县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3034', 'mainland', '3031', '0:003743:002906:003031:003034', '4', null, '勐腊县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3035', 'mainland', '3031', '0:003743:002906:003031:003035', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3036', 'mainland', '2906', '0:003743:002906:003036', '3', '5329', '大理白族自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3037', 'mainland', '3036', '0:003743:002906:003036:003037', '4', null, '大理市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3038', 'mainland', '3036', '0:003743:002906:003036:003038', '4', null, '漾濞彝族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3039', 'mainland', '3036', '0:003743:002906:003036:003039', '4', null, '祥云县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3040', 'mainland', '3036', '0:003743:002906:003036:003040', '4', null, '宾川县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3041', 'mainland', '3036', '0:003743:002906:003036:003041', '4', null, '弥渡县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3042', 'mainland', '3036', '0:003743:002906:003036:003042', '4', null, '南涧彝族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3043', 'mainland', '3036', '0:003743:002906:003036:003043', '4', null, '巍山彝族回族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3044', 'mainland', '3036', '0:003743:002906:003036:003044', '4', null, '永平县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3045', 'mainland', '3036', '0:003743:002906:003036:003045', '4', null, '云龙县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3046', 'mainland', '3036', '0:003743:002906:003036:003046', '4', null, '洱源县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3047', 'mainland', '3036', '0:003743:002906:003036:003047', '4', null, '剑川县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3048', 'mainland', '3036', '0:003743:002906:003036:003048', '4', null, '鹤庆县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3049', 'mainland', '3036', '0:003743:002906:003036:003049', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3050', 'mainland', '2906', '0:003743:002906:003050', '3', '5331', '德宏傣族景颇族自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3051', 'mainland', '3050', '0:003743:002906:003050:003051', '4', null, '瑞丽市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3052', 'mainland', '3050', '0:003743:002906:003050:003052', '4', null, '潞西市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3053', 'mainland', '3050', '0:003743:002906:003050:003053', '4', null, '梁河县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3054', 'mainland', '3050', '0:003743:002906:003050:003054', '4', null, '盈江县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3055', 'mainland', '3050', '0:003743:002906:003050:003055', '4', null, '陇川县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3056', 'mainland', '3050', '0:003743:002906:003050:003056', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3057', 'mainland', '2906', '0:003743:002906:003057', '3', '5333', '怒江傈僳族自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3058', 'mainland', '3057', '0:003743:002906:003057:003058', '4', null, '泸水县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3059', 'mainland', '3057', '0:003743:002906:003057:003059', '4', null, '福贡县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3060', 'mainland', '3057', '0:003743:002906:003057:003060', '4', null, '贡山独龙族怒族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3061', 'mainland', '3057', '0:003743:002906:003057:003061', '4', null, '兰坪白族普米族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3062', 'mainland', '3057', '0:003743:002906:003057:003062', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3063', 'mainland', '2906', '0:003743:002906:003063', '3', '5334', '迪庆藏族自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3064', 'mainland', '3063', '0:003743:002906:003063:003064', '4', null, '香格里拉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3065', 'mainland', '3063', '0:003743:002906:003063:003065', '4', null, '德钦县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3066', 'mainland', '3063', '0:003743:002906:003063:003066', '4', null, '维西傈僳族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3067', 'mainland', '3063', '0:003743:002906:003063:003067', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3068', 'mainland', '3743', '0:003743:003068', '2', null, '西藏自治区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3069', 'mainland', '3068', '0:003743:003068:003069', '3', '5401', '拉萨市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3070', 'mainland', '3069', '0:003743:003068:003069:003070', '4', null, '城关区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3071', 'mainland', '3069', '0:003743:003068:003069:003071', '4', null, '林周县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3072', 'mainland', '3069', '0:003743:003068:003069:003072', '4', null, '当雄县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3073', 'mainland', '3069', '0:003743:003068:003069:003073', '4', null, '尼木县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3074', 'mainland', '3069', '0:003743:003068:003069:003074', '4', null, '曲水县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3075', 'mainland', '3069', '0:003743:003068:003069:003075', '4', null, '堆龙德庆县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3076', 'mainland', '3069', '0:003743:003068:003069:003076', '4', null, '达孜县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3077', 'mainland', '3069', '0:003743:003068:003069:003077', '4', null, '墨竹工卡县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3078', 'mainland', '3069', '0:003743:003068:003069:003078', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3079', 'mainland', '3068', '0:003743:003068:003079', '3', '5421', '昌都地区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3080', 'mainland', '3079', '0:003743:003068:003079:003080', '4', null, '昌都县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3081', 'mainland', '3079', '0:003743:003068:003079:003081', '4', null, '江达县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3082', 'mainland', '3079', '0:003743:003068:003079:003082', '4', null, '贡觉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3083', 'mainland', '3079', '0:003743:003068:003079:003083', '4', null, '类乌齐县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3084', 'mainland', '3079', '0:003743:003068:003079:003084', '4', null, '丁青县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3085', 'mainland', '3079', '0:003743:003068:003079:003085', '4', null, '察雅县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3086', 'mainland', '3079', '0:003743:003068:003079:003086', '4', null, '八宿县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3087', 'mainland', '3079', '0:003743:003068:003079:003087', '4', null, '左贡县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3088', 'mainland', '3079', '0:003743:003068:003079:003088', '4', null, '芒康县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3089', 'mainland', '3079', '0:003743:003068:003079:003089', '4', null, '洛隆县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3090', 'mainland', '3079', '0:003743:003068:003079:003090', '4', null, '边坝县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3091', 'mainland', '3079', '0:003743:003068:003079:003091', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3092', 'mainland', '3068', '0:003743:003068:003092', '3', '5422', '山南地区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3095', 'mainland', '3092', '0:003743:003068:003092:003095', '4', null, '贡嘎县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3096', 'mainland', '3092', '0:003743:003068:003092:003096', '4', null, '桑日县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3097', 'mainland', '3092', '0:003743:003068:003092:003097', '4', null, '琼结县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3098', 'mainland', '3092', '0:003743:003068:003092:003098', '4', null, '曲松县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3099', 'mainland', '3092', '0:003743:003068:003092:003099', '4', null, '措美县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3100', 'mainland', '3092', '0:003743:003068:003092:003100', '4', null, '洛扎县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3101', 'mainland', '3092', '0:003743:003068:003092:003101', '4', null, '加查县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3102', 'mainland', '3092', '0:003743:003068:003092:003102', '4', null, '隆子县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3103', 'mainland', '3092', '0:003743:003068:003092:003103', '4', null, '错那县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3104', 'mainland', '3092', '0:003743:003068:003092:003104', '4', null, '浪卡子县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3105', 'mainland', '3092', '0:003743:003068:003092:003105', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3106', 'mainland', '3068', '0:003743:003068:003106', '3', '5424', '日喀则地区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3107', 'mainland', '3106', '0:003743:003068:003106:003107', '4', null, '日喀则市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3108', 'mainland', '3106', '0:003743:003068:003106:003108', '4', null, '南木林县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3109', 'mainland', '3106', '0:003743:003068:003106:003109', '4', null, '江孜县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3110', 'mainland', '3106', '0:003743:003068:003106:003110', '4', null, '定日县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3111', 'mainland', '3106', '0:003743:003068:003106:003111', '4', null, '萨迦县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3112', 'mainland', '3106', '0:003743:003068:003106:003112', '4', null, '拉孜县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3113', 'mainland', '3106', '0:003743:003068:003106:003113', '4', null, '昂仁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3114', 'mainland', '3106', '0:003743:003068:003106:003114', '4', null, '谢通门县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3115', 'mainland', '3106', '0:003743:003068:003106:003115', '4', null, '白朗县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3116', 'mainland', '3106', '0:003743:003068:003106:003116', '4', null, '仁布县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3117', 'mainland', '3106', '0:003743:003068:003106:003117', '4', null, '康马县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3118', 'mainland', '3106', '0:003743:003068:003106:003118', '4', null, '定结县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3119', 'mainland', '3106', '0:003743:003068:003106:003119', '4', null, '仲巴县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3120', 'mainland', '3106', '0:003743:003068:003106:003120', '4', null, '亚东县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3121', 'mainland', '3106', '0:003743:003068:003106:003121', '4', null, '吉隆县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3122', 'mainland', '3106', '0:003743:003068:003106:003122', '4', null, '聂拉木县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3123', 'mainland', '3106', '0:003743:003068:003106:003123', '4', null, '萨嘎县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3124', 'mainland', '3106', '0:003743:003068:003106:003124', '4', null, '岗巴县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3125', 'mainland', '3106', '0:003743:003068:003106:003125', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3126', 'mainland', '3068', '0:003743:003068:003126', '3', '3126', '那曲地区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3127', 'mainland', '3126', '0:003743:003068:003126:003127', '4', null, '那曲县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3128', 'mainland', '3126', '0:003743:003068:003126:003128', '4', null, '嘉黎县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3129', 'mainland', '3126', '0:003743:003068:003126:003129', '4', null, '比如县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3130', 'mainland', '3126', '0:003743:003068:003126:003130', '4', null, '聂荣县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3131', 'mainland', '3126', '0:003743:003068:003126:003131', '4', null, '安多县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3132', 'mainland', '3126', '0:003743:003068:003126:003132', '4', null, '申扎县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3133', 'mainland', '3126', '0:003743:003068:003126:003133', '4', null, '索县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3134', 'mainland', '3126', '0:003743:003068:003126:003134', '4', null, '班戈县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3135', 'mainland', '3126', '0:003743:003068:003126:003135', '4', null, '巴青县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3136', 'mainland', '3126', '0:003743:003068:003126:003136', '4', null, '尼玛县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3137', 'mainland', '3126', '0:003743:003068:003126:003137', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3138', 'mainland', '3068', '0:003743:003068:003138', '3', '5425', '阿里地区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3139', 'mainland', '3138', '0:003743:003068:003138:003139', '4', null, '普兰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3140', 'mainland', '3138', '0:003743:003068:003138:003140', '4', null, '札达县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3141', 'mainland', '3138', '0:003743:003068:003138:003141', '4', null, '噶尔县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3142', 'mainland', '3138', '0:003743:003068:003138:003142', '4', null, '日土县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3143', 'mainland', '3138', '0:003743:003068:003138:003143', '4', null, '革吉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3144', 'mainland', '3138', '0:003743:003068:003138:003144', '4', null, '改则县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3145', 'mainland', '3138', '0:003743:003068:003138:003145', '4', null, '措勤县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3146', 'mainland', '3138', '0:003743:003068:003138:003146', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3147', 'mainland', '3068', '0:003743:003068:003147', '3', '5426', '林芝地区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3148', 'mainland', '3147', '0:003743:003068:003147:003148', '4', null, '林芝县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3149', 'mainland', '3147', '0:003743:003068:003147:003149', '4', null, '工布江达县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3150', 'mainland', '3147', '0:003743:003068:003147:003150', '4', null, '米林县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3151', 'mainland', '3147', '0:003743:003068:003147:003151', '4', null, '墨脱县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3152', 'mainland', '3147', '0:003743:003068:003147:003152', '4', null, '波密县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3153', 'mainland', '3147', '0:003743:003068:003147:003153', '4', null, '察隅县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3154', 'mainland', '3147', '0:003743:003068:003147:003154', '4', null, '朗县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3155', 'mainland', '3147', '0:003743:003068:003147:003155', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3156', 'mainland', '3743', '0:003743:003156', '2', null, '陕西省', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3157', 'mainland', '3156', '0:003743:003156:003157', '3', '6101', '西安市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3158', 'mainland', '3157', '0:003743:003156:003157:003158', '4', null, '新城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3159', 'mainland', '3157', '0:003743:003156:003157:003159', '4', null, '碑林区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3160', 'mainland', '3157', '0:003743:003156:003157:003160', '4', null, '莲湖区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3161', 'mainland', '3157', '0:003743:003156:003157:003161', '4', null, '灞桥区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3162', 'mainland', '3157', '0:003743:003156:003157:003162', '4', null, '未央区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3163', 'mainland', '3157', '0:003743:003156:003157:003163', '4', null, '雁塔区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3164', 'mainland', '3157', '0:003743:003156:003157:003164', '4', null, '阎良区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3165', 'mainland', '3157', '0:003743:003156:003157:003165', '4', null, '临潼区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3166', 'mainland', '3157', '0:003743:003156:003157:003166', '4', null, '长安区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3167', 'mainland', '3157', '0:003743:003156:003157:003167', '4', null, '蓝田县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3168', 'mainland', '3157', '0:003743:003156:003157:003168', '4', null, '周至县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3169', 'mainland', '3157', '0:003743:003156:003157:003169', '4', null, '户县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3170', 'mainland', '3157', '0:003743:003156:003157:003170', '4', null, '高陵县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3171', 'mainland', '3157', '0:003743:003156:003157:003171', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3172', 'mainland', '3156', '0:003743:003156:003172', '3', '6102', '铜川市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3173', 'mainland', '3172', '0:003743:003156:003172:003173', '4', null, '王益区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3174', 'mainland', '3172', '0:003743:003156:003172:003174', '4', null, '印台区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3175', 'mainland', '3172', '0:003743:003156:003172:003175', '4', null, '耀州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3176', 'mainland', '3172', '0:003743:003156:003172:003176', '4', null, '宜君县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3177', 'mainland', '3172', '0:003743:003156:003172:003177', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3178', 'mainland', '3156', '0:003743:003156:003178', '3', '6103', '宝鸡市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3179', 'mainland', '3178', '0:003743:003156:003178:003179', '4', null, '渭滨区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3180', 'mainland', '3178', '0:003743:003156:003178:003180', '4', null, '金台区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3181', 'mainland', '3178', '0:003743:003156:003178:003181', '4', null, '陈仓区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3182', 'mainland', '3178', '0:003743:003156:003178:003182', '4', null, '凤翔县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3183', 'mainland', '3178', '0:003743:003156:003178:003183', '4', null, '岐山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3184', 'mainland', '3178', '0:003743:003156:003178:003184', '4', null, '扶风县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3185', 'mainland', '3178', '0:003743:003156:003178:003185', '4', null, '眉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3186', 'mainland', '3178', '0:003743:003156:003178:003186', '4', null, '陇县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3187', 'mainland', '3178', '0:003743:003156:003178:003187', '4', null, '千阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3188', 'mainland', '3178', '0:003743:003156:003178:003188', '4', null, '麟游县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3189', 'mainland', '3178', '0:003743:003156:003178:003189', '4', null, '凤县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3190', 'mainland', '3178', '0:003743:003156:003178:003190', '4', null, '太白县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3191', 'mainland', '3178', '0:003743:003156:003178:003191', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3192', 'mainland', '3156', '0:003743:003156:003192', '3', '6104', '咸阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3193', 'mainland', '3192', '0:003743:003156:003192:003193', '4', null, '秦都区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3194', 'mainland', '3192', '0:003743:003156:003192:003194', '4', null, '杨凌区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3195', 'mainland', '3192', '0:003743:003156:003192:003195', '4', null, '渭城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3196', 'mainland', '3192', '0:003743:003156:003192:003196', '4', null, '三原县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3197', 'mainland', '3192', '0:003743:003156:003192:003197', '4', null, '泾阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3198', 'mainland', '3192', '0:003743:003156:003192:003198', '4', null, '乾县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3199', 'mainland', '3192', '0:003743:003156:003192:003199', '4', null, '礼泉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3200', 'mainland', '3192', '0:003743:003156:003192:003200', '4', null, '永寿县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3201', 'mainland', '3192', '0:003743:003156:003192:003201', '4', null, '彬县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3202', 'mainland', '3192', '0:003743:003156:003192:003202', '4', null, '长武县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3203', 'mainland', '3192', '0:003743:003156:003192:003203', '4', null, '旬邑县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3204', 'mainland', '3192', '0:003743:003156:003192:003204', '4', null, '淳化县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3205', 'mainland', '3192', '0:003743:003156:003192:003205', '4', null, '武功县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3206', 'mainland', '3192', '0:003743:003156:003192:003206', '4', null, '兴平市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3207', 'mainland', '3192', '0:003743:003156:003192:003207', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3208', 'mainland', '3156', '0:003743:003156:003208', '3', '6105', '渭南市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3209', 'mainland', '3208', '0:003743:003156:003208:003209', '4', null, '临渭区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3210', 'mainland', '3208', '0:003743:003156:003208:003210', '4', null, '华县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3211', 'mainland', '3208', '0:003743:003156:003208:003211', '4', null, '潼关县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3212', 'mainland', '3208', '0:003743:003156:003208:003212', '4', null, '大荔县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3213', 'mainland', '3208', '0:003743:003156:003208:003213', '4', null, '合阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3214', 'mainland', '3208', '0:003743:003156:003208:003214', '4', null, '澄城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3215', 'mainland', '3208', '0:003743:003156:003208:003215', '4', null, '蒲城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3216', 'mainland', '3208', '0:003743:003156:003208:003216', '4', null, '白水县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3217', 'mainland', '3208', '0:003743:003156:003208:003217', '4', null, '富平县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3218', 'mainland', '3208', '0:003743:003156:003208:003218', '4', null, '韩城市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3219', 'mainland', '3208', '0:003743:003156:003208:003219', '4', null, '华阴市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3220', 'mainland', '3208', '0:003743:003156:003208:003220', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3221', 'mainland', '3156', '0:003743:003156:003221', '3', '6106', '延安市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3222', 'mainland', '3221', '0:003743:003156:003221:003222', '4', null, '宝塔区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3223', 'mainland', '3221', '0:003743:003156:003221:003223', '4', null, '延长县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3224', 'mainland', '3221', '0:003743:003156:003221:003224', '4', null, '延川县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3225', 'mainland', '3221', '0:003743:003156:003221:003225', '4', null, '子长县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3226', 'mainland', '3221', '0:003743:003156:003221:003226', '4', null, '安塞县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3227', 'mainland', '3221', '0:003743:003156:003221:003227', '4', null, '志丹县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3228', 'mainland', '3221', '0:003743:003156:003221:003228', '4', null, '吴起县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3229', 'mainland', '3221', '0:003743:003156:003221:003229', '4', null, '甘泉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3230', 'mainland', '3221', '0:003743:003156:003221:003230', '4', null, '富县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3231', 'mainland', '3221', '0:003743:003156:003221:003231', '4', null, '洛川县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3232', 'mainland', '3221', '0:003743:003156:003221:003232', '4', null, '宜川县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3233', 'mainland', '3221', '0:003743:003156:003221:003233', '4', null, '黄龙县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3234', 'mainland', '3221', '0:003743:003156:003221:003234', '4', null, '黄陵县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3235', 'mainland', '3221', '0:003743:003156:003221:003235', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3236', 'mainland', '3156', '0:003743:003156:003236', '3', '6107', '汉中市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3237', 'mainland', '3236', '0:003743:003156:003236:003237', '4', null, '汉台区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3238', 'mainland', '3236', '0:003743:003156:003236:003238', '4', null, '南郑县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3239', 'mainland', '3236', '0:003743:003156:003236:003239', '4', null, '城固县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3240', 'mainland', '3236', '0:003743:003156:003236:003240', '4', null, '洋县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3241', 'mainland', '3236', '0:003743:003156:003236:003241', '4', null, '西乡县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3242', 'mainland', '3236', '0:003743:003156:003236:003242', '4', null, '勉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3243', 'mainland', '3236', '0:003743:003156:003236:003243', '4', null, '宁强县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3244', 'mainland', '3236', '0:003743:003156:003236:003244', '4', null, '略阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3245', 'mainland', '3236', '0:003743:003156:003236:003245', '4', null, '镇巴县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3246', 'mainland', '3236', '0:003743:003156:003236:003246', '4', null, '留坝县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3247', 'mainland', '3236', '0:003743:003156:003236:003247', '4', null, '佛坪县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3248', 'mainland', '3236', '0:003743:003156:003236:003248', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3249', 'mainland', '3156', '0:003743:003156:003249', '3', '6108', '榆林市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3250', 'mainland', '3249', '0:003743:003156:003249:003250', '4', null, '榆阳区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3251', 'mainland', '3249', '0:003743:003156:003249:003251', '4', null, '神木县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3252', 'mainland', '3249', '0:003743:003156:003249:003252', '4', null, '府谷县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3253', 'mainland', '3249', '0:003743:003156:003249:003253', '4', null, '横山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3254', 'mainland', '3249', '0:003743:003156:003249:003254', '4', null, '靖边县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3255', 'mainland', '3249', '0:003743:003156:003249:003255', '4', null, '定边县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3256', 'mainland', '3249', '0:003743:003156:003249:003256', '4', null, '绥德县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3257', 'mainland', '3249', '0:003743:003156:003249:003257', '4', null, '米脂县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3258', 'mainland', '3249', '0:003743:003156:003249:003258', '4', null, '佳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3259', 'mainland', '3249', '0:003743:003156:003249:003259', '4', null, '吴堡县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3260', 'mainland', '3249', '0:003743:003156:003249:003260', '4', null, '清涧县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3261', 'mainland', '3249', '0:003743:003156:003249:003261', '4', null, '子洲县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3262', 'mainland', '3249', '0:003743:003156:003249:003262', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3263', 'mainland', '3156', '0:003743:003156:003263', '3', '6109', '安康市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3264', 'mainland', '3263', '0:003743:003156:003263:003264', '4', null, '汉滨区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3265', 'mainland', '3263', '0:003743:003156:003263:003265', '4', null, '汉阴县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3266', 'mainland', '3263', '0:003743:003156:003263:003266', '4', null, '石泉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3267', 'mainland', '3263', '0:003743:003156:003263:003267', '4', null, '宁陕县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3268', 'mainland', '3263', '0:003743:003156:003263:003268', '4', null, '紫阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3269', 'mainland', '3263', '0:003743:003156:003263:003269', '4', null, '岚皋县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3270', 'mainland', '3263', '0:003743:003156:003263:003270', '4', null, '平利县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3271', 'mainland', '3263', '0:003743:003156:003263:003271', '4', null, '镇坪县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3272', 'mainland', '3263', '0:003743:003156:003263:003272', '4', null, '旬阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3273', 'mainland', '3263', '0:003743:003156:003263:003273', '4', null, '白河县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3274', 'mainland', '3263', '0:003743:003156:003263:003274', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3275', 'mainland', '3156', '0:003743:003156:003275', '3', '3275', '商洛市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3276', 'mainland', '3275', '0:003743:003156:003275:003276', '4', null, '商州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3277', 'mainland', '3275', '0:003743:003156:003275:003277', '4', null, '洛南县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3278', 'mainland', '3275', '0:003743:003156:003275:003278', '4', null, '丹凤县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3279', 'mainland', '3275', '0:003743:003156:003275:003279', '4', null, '商南县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3280', 'mainland', '3275', '0:003743:003156:003275:003280', '4', null, '山阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3281', 'mainland', '3275', '0:003743:003156:003275:003281', '4', null, '镇安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3282', 'mainland', '3275', '0:003743:003156:003275:003282', '4', null, '柞水县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3283', 'mainland', '3275', '0:003743:003156:003275:003283', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3284', 'mainland', '3743', '0:003743:003284', '2', null, '甘肃省', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3285', 'mainland', '3284', '0:003743:003284:003285', '3', '6201', '兰州市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3286', 'mainland', '3285', '0:003743:003284:003285:003286', '4', null, '城关区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3287', 'mainland', '3285', '0:003743:003284:003285:003287', '4', null, '七里河区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3288', 'mainland', '3285', '0:003743:003284:003285:003288', '4', null, '西固区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3289', 'mainland', '3285', '0:003743:003284:003285:003289', '4', null, '安宁区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3290', 'mainland', '3285', '0:003743:003284:003285:003290', '4', null, '红古区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3291', 'mainland', '3285', '0:003743:003284:003285:003291', '4', null, '永登县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3292', 'mainland', '3285', '0:003743:003284:003285:003292', '4', null, '皋兰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3293', 'mainland', '3285', '0:003743:003284:003285:003293', '4', null, '榆中县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3294', 'mainland', '3285', '0:003743:003284:003285:003294', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3295', 'mainland', '3284', '0:003743:003284:003295', '3', '6202', '嘉峪关市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3296', 'mainland', '3284', '0:003743:003284:003296', '3', '6203', '金昌市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3297', 'mainland', '3296', '0:003743:003284:003296:003297', '4', null, '金川区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3298', 'mainland', '3296', '0:003743:003284:003296:003298', '4', null, '永昌县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3299', 'mainland', '3296', '0:003743:003284:003296:003299', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3300', 'mainland', '3284', '0:003743:003284:003300', '3', '6204', '白银市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3301', 'mainland', '3300', '0:003743:003284:003300:003301', '4', null, '白银区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3302', 'mainland', '3300', '0:003743:003284:003300:003302', '4', null, '平川区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3303', 'mainland', '3300', '0:003743:003284:003300:003303', '4', null, '靖远县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3304', 'mainland', '3300', '0:003743:003284:003300:003304', '4', null, '会宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3305', 'mainland', '3300', '0:003743:003284:003300:003305', '4', null, '景泰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3306', 'mainland', '3300', '0:003743:003284:003300:003306', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3307', 'mainland', '3284', '0:003743:003284:003307', '3', '6205', '天水市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3308', 'mainland', '3307', '0:003743:003284:003307:003308', '4', null, '秦州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3309', 'mainland', '3307', '0:003743:003284:003307:003309', '4', null, '麦积区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3310', 'mainland', '3307', '0:003743:003284:003307:003310', '4', null, '清水县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3311', 'mainland', '3307', '0:003743:003284:003307:003311', '4', null, '秦安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3312', 'mainland', '3307', '0:003743:003284:003307:003312', '4', null, '甘谷县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3313', 'mainland', '3307', '0:003743:003284:003307:003313', '4', null, '武山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3314', 'mainland', '3307', '0:003743:003284:003307:003314', '4', null, '张家川回族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3315', 'mainland', '3307', '0:003743:003284:003307:003315', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3316', 'mainland', '3284', '0:003743:003284:003316', '3', '6206', '武威市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3317', 'mainland', '3316', '0:003743:003284:003316:003317', '4', null, '凉州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3318', 'mainland', '3316', '0:003743:003284:003316:003318', '4', null, '民勤县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3319', 'mainland', '3316', '0:003743:003284:003316:003319', '4', null, '古浪县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3320', 'mainland', '3316', '0:003743:003284:003316:003320', '4', null, '天祝藏族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3321', 'mainland', '3316', '0:003743:003284:003316:003321', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3322', 'mainland', '3284', '0:003743:003284:003322', '3', '6207', '张掖市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3323', 'mainland', '3322', '0:003743:003284:003322:003323', '4', null, '甘州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3324', 'mainland', '3322', '0:003743:003284:003322:003324', '4', null, '肃南裕固族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3325', 'mainland', '3322', '0:003743:003284:003322:003325', '4', null, '民乐县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3326', 'mainland', '3322', '0:003743:003284:003322:003326', '4', null, '临泽县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3327', 'mainland', '3322', '0:003743:003284:003322:003327', '4', null, '高台县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3328', 'mainland', '3322', '0:003743:003284:003322:003328', '4', null, '山丹县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3329', 'mainland', '3322', '0:003743:003284:003322:003329', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3330', 'mainland', '3284', '0:003743:003284:003330', '3', '6208', '平凉市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3331', 'mainland', '3330', '0:003743:003284:003330:003331', '4', null, '崆峒区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3332', 'mainland', '3330', '0:003743:003284:003330:003332', '4', null, '泾川县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3333', 'mainland', '3330', '0:003743:003284:003330:003333', '4', null, '灵台县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3334', 'mainland', '3330', '0:003743:003284:003330:003334', '4', null, '崇信县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3335', 'mainland', '3330', '0:003743:003284:003330:003335', '4', null, '华亭县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3336', 'mainland', '3330', '0:003743:003284:003330:003336', '4', null, '庄浪县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3337', 'mainland', '3330', '0:003743:003284:003330:003337', '4', null, '静宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3338', 'mainland', '3330', '0:003743:003284:003330:003338', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3339', 'mainland', '3284', '0:003743:003284:003339', '3', '6209', '酒泉市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3340', 'mainland', '3339', '0:003743:003284:003339:003340', '4', null, '肃州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3341', 'mainland', '3339', '0:003743:003284:003339:003341', '4', null, '金塔县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3342', 'mainland', '3339', '0:003743:003284:003339:003342', '4', null, '安西县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3343', 'mainland', '3339', '0:003743:003284:003339:003343', '4', null, '肃北蒙古族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3344', 'mainland', '3339', '0:003743:003284:003339:003344', '4', null, '阿克塞哈萨克族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3345', 'mainland', '3339', '0:003743:003284:003339:003345', '4', null, '玉门市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3346', 'mainland', '3339', '0:003743:003284:003339:003346', '4', null, '敦煌市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3347', 'mainland', '3339', '0:003743:003284:003339:003347', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3348', 'mainland', '3284', '0:003743:003284:003348', '3', '3348', '庆阳市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3349', 'mainland', '3348', '0:003743:003284:003348:003349', '4', null, '西峰区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3350', 'mainland', '3348', '0:003743:003284:003348:003350', '4', null, '庆城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3351', 'mainland', '3348', '0:003743:003284:003348:003351', '4', null, '环县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3352', 'mainland', '3348', '0:003743:003284:003348:003352', '4', null, '华池县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3353', 'mainland', '3348', '0:003743:003284:003348:003353', '4', null, '合水县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3354', 'mainland', '3348', '0:003743:003284:003348:003354', '4', null, '正宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3355', 'mainland', '3348', '0:003743:003284:003348:003355', '4', null, '宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3356', 'mainland', '3348', '0:003743:003284:003348:003356', '4', null, '镇原县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3357', 'mainland', '3348', '0:003743:003284:003348:003357', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3358', 'mainland', '3284', '0:003743:003284:003358', '3', '6211', '定西市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3359', 'mainland', '3358', '0:003743:003284:003358:003359', '4', null, '安定区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3360', 'mainland', '3358', '0:003743:003284:003358:003360', '4', null, '通渭县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3361', 'mainland', '3358', '0:003743:003284:003358:003361', '4', null, '陇西县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3362', 'mainland', '3358', '0:003743:003284:003358:003362', '4', null, '渭源县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3363', 'mainland', '3358', '0:003743:003284:003358:003363', '4', null, '临洮县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3364', 'mainland', '3358', '0:003743:003284:003358:003364', '4', null, '漳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3365', 'mainland', '3358', '0:003743:003284:003358:003365', '4', null, '岷县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3366', 'mainland', '3358', '0:003743:003284:003358:003366', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3367', 'mainland', '3284', '0:003743:003284:003367', '3', '6212', '陇南市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3368', 'mainland', '3367', '0:003743:003284:003367:003368', '4', null, '武都区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3369', 'mainland', '3367', '0:003743:003284:003367:003369', '4', null, '成县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3370', 'mainland', '3367', '0:003743:003284:003367:003370', '4', null, '文县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3371', 'mainland', '3367', '0:003743:003284:003367:003371', '4', null, '宕昌县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3372', 'mainland', '3367', '0:003743:003284:003367:003372', '4', null, '康县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3373', 'mainland', '3367', '0:003743:003284:003367:003373', '4', null, '西和县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3374', 'mainland', '3367', '0:003743:003284:003367:003374', '4', null, '礼县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3375', 'mainland', '3367', '0:003743:003284:003367:003375', '4', null, '徽县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3376', 'mainland', '3367', '0:003743:003284:003367:003376', '4', null, '两当县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3377', 'mainland', '3367', '0:003743:003284:003367:003377', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3378', 'mainland', '3284', '0:003743:003284:003378', '3', '6229', '临夏回族自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3379', 'mainland', '3378', '0:003743:003284:003378:003379', '4', null, '临夏市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3380', 'mainland', '3378', '0:003743:003284:003378:003380', '4', null, '临夏县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3381', 'mainland', '3378', '0:003743:003284:003378:003381', '4', null, '康乐县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3382', 'mainland', '3378', '0:003743:003284:003378:003382', '4', null, '永靖县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3383', 'mainland', '3378', '0:003743:003284:003378:003383', '4', null, '广河县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3384', 'mainland', '3378', '0:003743:003284:003378:003384', '4', null, '和政县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3385', 'mainland', '3378', '0:003743:003284:003378:003385', '4', null, '东乡族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3386', 'mainland', '3378', '0:003743:003284:003378:003386', '4', null, '积石山保安族东乡族撒拉族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3387', 'mainland', '3378', '0:003743:003284:003378:003387', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3388', 'mainland', '3284', '0:003743:003284:003388', '3', '3388', '甘南藏族自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3389', 'mainland', '3388', '0:003743:003284:003388:003389', '4', null, '合作市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3390', 'mainland', '3388', '0:003743:003284:003388:003390', '4', null, '临潭县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3391', 'mainland', '3388', '0:003743:003284:003388:003391', '4', null, '卓尼县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3392', 'mainland', '3388', '0:003743:003284:003388:003392', '4', null, '舟曲县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3393', 'mainland', '3388', '0:003743:003284:003388:003393', '4', null, '迭部县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3394', 'mainland', '3388', '0:003743:003284:003388:003394', '4', null, '玛曲县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3395', 'mainland', '3388', '0:003743:003284:003388:003395', '4', null, '碌曲县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3396', 'mainland', '3388', '0:003743:003284:003388:003396', '4', null, '夏河县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3397', 'mainland', '3388', '0:003743:003284:003388:003397', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3398', 'mainland', '3743', '0:003743:003398', '2', null, '青海省', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3399', 'mainland', '3398', '0:003743:003398:003399', '3', '6301', '西宁市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3400', 'mainland', '3399', '0:003743:003398:003399:003400', '4', null, '城东区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3401', 'mainland', '3399', '0:003743:003398:003399:003401', '4', null, '城中区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3402', 'mainland', '3399', '0:003743:003398:003399:003402', '4', null, '城西区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3403', 'mainland', '3399', '0:003743:003398:003399:003403', '4', null, '城北区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3404', 'mainland', '3399', '0:003743:003398:003399:003404', '4', null, '大通回族土族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3405', 'mainland', '3399', '0:003743:003398:003399:003405', '4', null, '湟中县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3406', 'mainland', '3399', '0:003743:003398:003399:003406', '4', null, '湟源县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3407', 'mainland', '3399', '0:003743:003398:003399:003407', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3408', 'mainland', '3398', '0:003743:003398:003408', '3', '6321', '海东地区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3409', 'mainland', '3408', '0:003743:003398:003408:003409', '4', null, '平安县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3410', 'mainland', '3408', '0:003743:003398:003408:003410', '4', null, '民和回族土族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3411', 'mainland', '3408', '0:003743:003398:003408:003411', '4', null, '乐都县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3412', 'mainland', '3408', '0:003743:003398:003408:003412', '4', null, '互助土族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3413', 'mainland', '3408', '0:003743:003398:003408:003413', '4', null, '化隆回族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3414', 'mainland', '3408', '0:003743:003398:003408:003414', '4', null, '循化撒拉族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3415', 'mainland', '3408', '0:003743:003398:003408:003415', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3416', 'mainland', '3398', '0:003743:003398:003416', '3', '6322', '海北藏族自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3417', 'mainland', '3416', '0:003743:003398:003416:003417', '4', null, '门源回族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3418', 'mainland', '3416', '0:003743:003398:003416:003418', '4', null, '祁连县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3419', 'mainland', '3416', '0:003743:003398:003416:003419', '4', null, '海晏县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3420', 'mainland', '3416', '0:003743:003398:003416:003420', '4', null, '刚察县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3421', 'mainland', '3416', '0:003743:003398:003416:003421', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3422', 'mainland', '3398', '0:003743:003398:003422', '3', '6323', '黄南藏族自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3423', 'mainland', '3422', '0:003743:003398:003422:003423', '4', null, '同仁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3424', 'mainland', '3422', '0:003743:003398:003422:003424', '4', null, '尖扎县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3425', 'mainland', '3422', '0:003743:003398:003422:003425', '4', null, '泽库县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3426', 'mainland', '3422', '0:003743:003398:003422:003426', '4', null, '河南蒙古族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3427', 'mainland', '3422', '0:003743:003398:003422:003427', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3428', 'mainland', '3398', '0:003743:003398:003428', '3', '6325', '海南藏族自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3429', 'mainland', '3428', '0:003743:003398:003428:003429', '4', null, '共和县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3430', 'mainland', '3428', '0:003743:003398:003428:003430', '4', null, '同德县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3431', 'mainland', '3428', '0:003743:003398:003428:003431', '4', null, '贵德县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3432', 'mainland', '3428', '0:003743:003398:003428:003432', '4', null, '兴海县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3433', 'mainland', '3428', '0:003743:003398:003428:003433', '4', null, '贵南县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3434', 'mainland', '3428', '0:003743:003398:003428:003434', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3435', 'mainland', '3398', '0:003743:003398:003435', '3', '6326', '果洛藏族自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3436', 'mainland', '3435', '0:003743:003398:003435:003436', '4', null, '玛沁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3437', 'mainland', '3435', '0:003743:003398:003435:003437', '4', null, '班玛县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3438', 'mainland', '3435', '0:003743:003398:003435:003438', '4', null, '甘德县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3439', 'mainland', '3435', '0:003743:003398:003435:003439', '4', null, '达日县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3440', 'mainland', '3435', '0:003743:003398:003435:003440', '4', null, '久治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3441', 'mainland', '3435', '0:003743:003398:003435:003441', '4', null, '玛多县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3442', 'mainland', '3435', '0:003743:003398:003435:003442', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3443', 'mainland', '3398', '0:003743:003398:003443', '3', '6327', '玉树藏族自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3444', 'mainland', '3443', '0:003743:003398:003443:003444', '4', null, '玉树县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3445', 'mainland', '3443', '0:003743:003398:003443:003445', '4', null, '杂多县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3446', 'mainland', '3443', '0:003743:003398:003443:003446', '4', null, '称多县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3447', 'mainland', '3443', '0:003743:003398:003443:003447', '4', null, '治多县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3448', 'mainland', '3443', '0:003743:003398:003443:003448', '4', null, '囊谦县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3449', 'mainland', '3443', '0:003743:003398:003443:003449', '4', null, '曲麻莱县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3450', 'mainland', '3443', '0:003743:003398:003443:003450', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3451', 'mainland', '3398', '0:003743:003398:003451', '3', '6328', '海西蒙古族藏族自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3452', 'mainland', '3451', '0:003743:003398:003451:003452', '4', null, '格尔木市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3453', 'mainland', '3451', '0:003743:003398:003451:003453', '4', null, '德令哈市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3454', 'mainland', '3451', '0:003743:003398:003451:003454', '4', null, '乌兰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3455', 'mainland', '3451', '0:003743:003398:003451:003455', '4', null, '都兰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3456', 'mainland', '3451', '0:003743:003398:003451:003456', '4', null, '天峻县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3457', 'mainland', '3451', '0:003743:003398:003451:003457', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3458', 'mainland', '3743', '0:003743:003458', '2', null, '宁夏回族自治区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3459', 'mainland', '3458', '0:003743:003458:003459', '3', '6401', '银川市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3460', 'mainland', '3459', '0:003743:003458:003459:003460', '4', null, '兴庆区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3461', 'mainland', '3459', '0:003743:003458:003459:003461', '4', null, '西夏区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3462', 'mainland', '3459', '0:003743:003458:003459:003462', '4', null, '金凤区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3463', 'mainland', '3459', '0:003743:003458:003459:003463', '4', null, '永宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3464', 'mainland', '3459', '0:003743:003458:003459:003464', '4', null, '贺兰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3465', 'mainland', '3459', '0:003743:003458:003459:003465', '4', null, '灵武市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3466', 'mainland', '3459', '0:003743:003458:003459:003466', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3467', 'mainland', '3458', '0:003743:003458:003467', '3', '6402', '石嘴山市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3468', 'mainland', '3467', '0:003743:003458:003467:003468', '4', null, '大武口区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3469', 'mainland', '3467', '0:003743:003458:003467:003469', '4', null, '惠农区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3470', 'mainland', '3467', '0:003743:003458:003467:003470', '4', null, '平罗县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3471', 'mainland', '3467', '0:003743:003458:003467:003471', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3472', 'mainland', '3458', '0:003743:003458:003472', '3', '6403', '吴忠市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3473', 'mainland', '3472', '0:003743:003458:003472:003473', '4', null, '利通区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3474', 'mainland', '3472', '0:003743:003458:003472:003474', '4', null, '红寺堡区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3475', 'mainland', '3472', '0:003743:003458:003472:003475', '4', null, '盐池县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3476', 'mainland', '3472', '0:003743:003458:003472:003476', '4', null, '同心县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3477', 'mainland', '3472', '0:003743:003458:003472:003477', '4', null, '青铜峡市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3478', 'mainland', '3472', '0:003743:003458:003472:003478', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3479', 'mainland', '3458', '0:003743:003458:003479', '3', '6404', '固原市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3480', 'mainland', '3479', '0:003743:003458:003479:003480', '4', null, '原州区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3481', 'mainland', '3479', '0:003743:003458:003479:003481', '4', null, '西吉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3482', 'mainland', '3479', '0:003743:003458:003479:003482', '4', null, '隆德县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3483', 'mainland', '3479', '0:003743:003458:003479:003483', '4', null, '泾源县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3484', 'mainland', '3479', '0:003743:003458:003479:003484', '4', null, '彭阳县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3485', 'mainland', '3479', '0:003743:003458:003479:003485', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3486', 'mainland', '3458', '0:003743:003458:003486', '3', '6405', '中卫市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3487', 'mainland', '3486', '0:003743:003458:003486:003487', '4', null, '沙坡头区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3488', 'mainland', '3486', '0:003743:003458:003486:003488', '4', null, '中宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3489', 'mainland', '3486', '0:003743:003458:003486:003489', '4', null, '海原县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3490', 'mainland', '3486', '0:003743:003458:003486:003490', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3491', 'mainland', '3743', '0:003743:003491', '2', null, '新疆维吾尔自治区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3492', 'mainland', '3491', '0:003743:003491:003492', '3', '6501', '乌鲁木齐市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3493', 'mainland', '3492', '0:003743:003491:003492:003493', '4', null, '天山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3494', 'mainland', '3492', '0:003743:003491:003492:003494', '4', null, '沙依巴克区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3495', 'mainland', '3492', '0:003743:003491:003492:003495', '4', null, '新市区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3496', 'mainland', '3492', '0:003743:003491:003492:003496', '4', null, '水磨沟区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3497', 'mainland', '3492', '0:003743:003491:003492:003497', '4', null, '头屯河区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3498', 'mainland', '3492', '0:003743:003491:003492:003498', '4', null, '达坂城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3499', 'mainland', '3492', '0:003743:003491:003492:003499', '4', null, '东山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3500', 'mainland', '3492', '0:003743:003491:003492:003500', '4', null, '米东区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3501', 'mainland', '3492', '0:003743:003491:003492:003501', '4', null, '乌鲁木齐县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3502', 'mainland', '3492', '0:003743:003491:003492:003502', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3503', 'mainland', '3491', '0:003743:003491:003503', '3', '6502', '克拉玛依市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3504', 'mainland', '3503', '0:003743:003491:003503:003504', '4', null, '独山子区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3505', 'mainland', '3503', '0:003743:003491:003503:003505', '4', null, '克拉玛依区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3506', 'mainland', '3503', '0:003743:003491:003503:003506', '4', null, '白碱滩区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3507', 'mainland', '3503', '0:003743:003491:003503:003507', '4', null, '乌尔禾区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3508', 'mainland', '3503', '0:003743:003491:003503:003508', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3509', 'mainland', '3491', '0:003743:003491:003509', '3', '6521', '吐鲁番地区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3510', 'mainland', '3509', '0:003743:003491:003509:003510', '4', null, '吐鲁番市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3511', 'mainland', '3509', '0:003743:003491:003509:003511', '4', null, '鄯善县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3512', 'mainland', '3509', '0:003743:003491:003509:003512', '4', null, '托克逊县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3513', 'mainland', '3509', '0:003743:003491:003509:003513', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3514', 'mainland', '3491', '0:003743:003491:003514', '3', '6522', '哈密地区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3515', 'mainland', '3514', '0:003743:003491:003514:003515', '4', null, '哈密市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3516', 'mainland', '3514', '0:003743:003491:003514:003516', '4', null, '巴里坤哈萨克自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3517', 'mainland', '3514', '0:003743:003491:003514:003517', '4', null, '伊吾县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3518', 'mainland', '3514', '0:003743:003491:003514:003518', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3519', 'mainland', '3491', '0:003743:003491:003519', '3', '6523', '昌吉回族自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3520', 'mainland', '3519', '0:003743:003491:003519:003520', '4', null, '昌吉市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3521', 'mainland', '3519', '0:003743:003491:003519:003521', '4', null, '阜康市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3522', 'mainland', '3519', '0:003743:003491:003519:003522', '4', null, '米泉市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3523', 'mainland', '3519', '0:003743:003491:003519:003523', '4', null, '呼图壁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3524', 'mainland', '3519', '0:003743:003491:003519:003524', '4', null, '玛纳斯县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3525', 'mainland', '3519', '0:003743:003491:003519:003525', '4', null, '奇台县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3526', 'mainland', '3519', '0:003743:003491:003519:003526', '4', null, '吉木萨尔县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3527', 'mainland', '3519', '0:003743:003491:003519:003527', '4', null, '木垒哈萨克自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3528', 'mainland', '3519', '0:003743:003491:003519:003528', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3529', 'mainland', '3491', '0:003743:003491:003529', '3', '6527', '博尔塔拉蒙古自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3530', 'mainland', '3529', '0:003743:003491:003529:003530', '4', null, '博乐市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3531', 'mainland', '3529', '0:003743:003491:003529:003531', '4', null, '精河县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3532', 'mainland', '3529', '0:003743:003491:003529:003532', '4', null, '温泉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3533', 'mainland', '3529', '0:003743:003491:003529:003533', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3534', 'mainland', '3491', '0:003743:003491:003534', '3', '6528', '巴音郭楞蒙古自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3535', 'mainland', '3534', '0:003743:003491:003534:003535', '4', null, '库尔勒市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3536', 'mainland', '3534', '0:003743:003491:003534:003536', '4', null, '轮台县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3537', 'mainland', '3534', '0:003743:003491:003534:003537', '4', null, '尉犁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3538', 'mainland', '3534', '0:003743:003491:003534:003538', '4', null, '若羌县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3539', 'mainland', '3534', '0:003743:003491:003534:003539', '4', null, '且末县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3540', 'mainland', '3534', '0:003743:003491:003534:003540', '4', null, '焉耆回族自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3541', 'mainland', '3534', '0:003743:003491:003534:003541', '4', null, '和静县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3542', 'mainland', '3534', '0:003743:003491:003534:003542', '4', null, '和硕县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3543', 'mainland', '3534', '0:003743:003491:003534:003543', '4', null, '博湖县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3544', 'mainland', '3534', '0:003743:003491:003534:003544', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3545', 'mainland', '3491', '0:003743:003491:003545', '3', '6529', '阿克苏地区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3546', 'mainland', '3545', '0:003743:003491:003545:003546', '4', null, '阿克苏市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3547', 'mainland', '3545', '0:003743:003491:003545:003547', '4', null, '温宿县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3548', 'mainland', '3545', '0:003743:003491:003545:003548', '4', null, '库车县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3549', 'mainland', '3545', '0:003743:003491:003545:003549', '4', null, '沙雅县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3550', 'mainland', '3545', '0:003743:003491:003545:003550', '4', null, '新和县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3551', 'mainland', '3545', '0:003743:003491:003545:003551', '4', null, '拜城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3552', 'mainland', '3545', '0:003743:003491:003545:003552', '4', null, '乌什县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3553', 'mainland', '3545', '0:003743:003491:003545:003553', '4', null, '阿瓦提县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3554', 'mainland', '3545', '0:003743:003491:003545:003554', '4', null, '柯坪县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3555', 'mainland', '3545', '0:003743:003491:003545:003555', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3556', 'mainland', '3491', '0:003743:003491:003556', '3', '3556', '克孜勒苏柯尔克孜自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3557', 'mainland', '3556', '0:003743:003491:003556:003557', '4', null, '阿图什市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3558', 'mainland', '3556', '0:003743:003491:003556:003558', '4', null, '阿克陶县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3559', 'mainland', '3556', '0:003743:003491:003556:003559', '4', null, '阿合奇县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3560', 'mainland', '3556', '0:003743:003491:003556:003560', '4', null, '乌恰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3561', 'mainland', '3556', '0:003743:003491:003556:003561', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3562', 'mainland', '3491', '0:003743:003491:003562', '3', '6531', '喀什地区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3563', 'mainland', '3562', '0:003743:003491:003562:003563', '4', null, '喀什市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3564', 'mainland', '3562', '0:003743:003491:003562:003564', '4', null, '疏附县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3565', 'mainland', '3562', '0:003743:003491:003562:003565', '4', null, '疏勒县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3566', 'mainland', '3562', '0:003743:003491:003562:003566', '4', null, '英吉沙县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3567', 'mainland', '3562', '0:003743:003491:003562:003567', '4', null, '泽普县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3568', 'mainland', '3562', '0:003743:003491:003562:003568', '4', null, '莎车县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3569', 'mainland', '3562', '0:003743:003491:003562:003569', '4', null, '叶城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3570', 'mainland', '3562', '0:003743:003491:003562:003570', '4', null, '麦盖提县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3571', 'mainland', '3562', '0:003743:003491:003562:003571', '4', null, '岳普湖县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3572', 'mainland', '3562', '0:003743:003491:003562:003572', '4', null, '伽师县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3573', 'mainland', '3562', '0:003743:003491:003562:003573', '4', null, '巴楚县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3574', 'mainland', '3562', '0:003743:003491:003562:003574', '4', null, '塔什库尔干塔吉克自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3575', 'mainland', '3562', '0:003743:003491:003562:003575', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3576', 'mainland', '3491', '0:003743:003491:003576', '3', '6532', '和田地区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3577', 'mainland', '3576', '0:003743:003491:003576:003577', '4', null, '和田市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3578', 'mainland', '3576', '0:003743:003491:003576:003578', '4', null, '和田县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3579', 'mainland', '3576', '0:003743:003491:003576:003579', '4', null, '墨玉县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3580', 'mainland', '3576', '0:003743:003491:003576:003580', '4', null, '皮山县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3581', 'mainland', '3576', '0:003743:003491:003576:003581', '4', null, '洛浦县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3582', 'mainland', '3576', '0:003743:003491:003576:003582', '4', null, '策勒县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3583', 'mainland', '3576', '0:003743:003491:003576:003583', '4', null, '于田县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3584', 'mainland', '3576', '0:003743:003491:003576:003584', '4', null, '民丰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3585', 'mainland', '3576', '0:003743:003491:003576:003585', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3586', 'mainland', '3491', '0:003743:003491:003586', '3', '3586', '伊犁哈萨克自治州', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3587', 'mainland', '3586', '0:003743:003491:003586:003587', '4', null, '伊宁市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3588', 'mainland', '3586', '0:003743:003491:003586:003588', '4', null, '奎屯市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3589', 'mainland', '3586', '0:003743:003491:003586:003589', '4', null, '伊宁县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3590', 'mainland', '3586', '0:003743:003491:003586:003590', '4', null, '察布查尔锡伯自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3591', 'mainland', '3586', '0:003743:003491:003586:003591', '4', null, '霍城县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3592', 'mainland', '3586', '0:003743:003491:003586:003592', '4', null, '巩留县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3593', 'mainland', '3586', '0:003743:003491:003586:003593', '4', null, '新源县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3594', 'mainland', '3586', '0:003743:003491:003586:003594', '4', null, '昭苏县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3595', 'mainland', '3586', '0:003743:003491:003586:003595', '4', null, '特克斯县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3596', 'mainland', '3586', '0:003743:003491:003586:003596', '4', null, '尼勒克县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3597', 'mainland', '3586', '0:003743:003491:003586:003597', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3598', 'mainland', '3491', '0:003743:003491:003598', '3', '6542', '塔城地区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3599', 'mainland', '3598', '0:003743:003491:003598:003599', '4', null, '塔城市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3600', 'mainland', '3598', '0:003743:003491:003598:003600', '4', null, '乌苏市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3601', 'mainland', '3598', '0:003743:003491:003598:003601', '4', null, '额敏县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3602', 'mainland', '3598', '0:003743:003491:003598:003602', '4', null, '沙湾县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3603', 'mainland', '3598', '0:003743:003491:003598:003603', '4', null, '托里县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3604', 'mainland', '3598', '0:003743:003491:003598:003604', '4', null, '裕民县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3605', 'mainland', '3598', '0:003743:003491:003598:003605', '4', null, '和布克赛尔蒙古自治县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3606', 'mainland', '3598', '0:003743:003491:003598:003606', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3607', 'mainland', '3491', '0:003743:003491:003607', '3', '6543', '阿勒泰地区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3608', 'mainland', '3607', '0:003743:003491:003607:003608', '4', null, '阿勒泰市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3609', 'mainland', '3607', '0:003743:003491:003607:003609', '4', null, '布尔津县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3610', 'mainland', '3607', '0:003743:003491:003607:003610', '4', null, '富蕴县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3611', 'mainland', '3607', '0:003743:003491:003607:003611', '4', null, '福海县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3612', 'mainland', '3607', '0:003743:003491:003607:003612', '4', null, '哈巴河县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3613', 'mainland', '3607', '0:003743:003491:003607:003613', '4', null, '青河县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3614', 'mainland', '3607', '0:003743:003491:003607:003614', '4', null, '吉木乃县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3615', 'mainland', '3607', '0:003743:003491:003607:003615', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3616', 'mainland', '3491', '0:003743:003491:003616', '3', '3616', '石河子市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3617', 'mainland', '3491', '0:003743:003491:003617', '3', '3617', '阿拉尔市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3618', 'mainland', '3491', '0:003743:003491:003618', '3', '3618', '图木舒克市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3619', 'mainland', '3491', '0:003743:003491:003619', '3', '3619', '五家渠市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3620', 'mainland', '3743', '0:003743:003620', '2', null, '台湾省', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3621', 'mainland', '3620', '0:003743:003620:003621', '3', '3621', '台北市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3622', 'mainland', '3621', '0:003743:003620:003621:003622', '4', null, '中正区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3623', 'mainland', '3621', '0:003743:003620:003621:003623', '4', null, '大同区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3624', 'mainland', '3621', '0:003743:003620:003621:003624', '4', null, '中山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3625', 'mainland', '3621', '0:003743:003620:003621:003625', '4', null, '松山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3626', 'mainland', '3621', '0:003743:003620:003621:003626', '4', null, '大安区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3627', 'mainland', '3621', '0:003743:003620:003621:003627', '4', null, '万华区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3628', 'mainland', '3621', '0:003743:003620:003621:003628', '4', null, '信义区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3629', 'mainland', '3621', '0:003743:003620:003621:003629', '4', null, '士林区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3630', 'mainland', '3621', '0:003743:003620:003621:003630', '4', null, '北投区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3631', 'mainland', '3621', '0:003743:003620:003621:003631', '4', null, '内湖区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3632', 'mainland', '3621', '0:003743:003620:003621:003632', '4', null, '南港区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3633', 'mainland', '3621', '0:003743:003620:003621:003633', '4', null, '文山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3634', 'mainland', '3621', '0:003743:003620:003621:003634', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3635', 'mainland', '3620', '0:003743:003620:003635', '3', '3635', '高雄市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3636', 'mainland', '3635', '0:003743:003620:003635:003636', '4', null, '新兴区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3637', 'mainland', '3635', '0:003743:003620:003635:003637', '4', null, '前金区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3638', 'mainland', '3635', '0:003743:003620:003635:003638', '4', null, '芩雅区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3639', 'mainland', '3635', '0:003743:003620:003635:003639', '4', null, '盐埕区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3640', 'mainland', '3635', '0:003743:003620:003635:003640', '4', null, '鼓山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3641', 'mainland', '3635', '0:003743:003620:003635:003641', '4', null, '旗津区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3642', 'mainland', '3635', '0:003743:003620:003635:003642', '4', null, '前镇区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3643', 'mainland', '3635', '0:003743:003620:003635:003643', '4', null, '三民区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3644', 'mainland', '3635', '0:003743:003620:003635:003644', '4', null, '左营区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3645', 'mainland', '3635', '0:003743:003620:003635:003645', '4', null, '楠梓区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3646', 'mainland', '3635', '0:003743:003620:003635:003646', '4', null, '小港区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3647', 'mainland', '3635', '0:003743:003620:003635:003647', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3648', 'mainland', '3620', '0:003743:003620:003648', '3', '3648', '台南市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3649', 'mainland', '3648', '0:003743:003620:003648:003649', '4', null, '中西区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3650', 'mainland', '3648', '0:003743:003620:003648:003650', '4', null, '东区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3651', 'mainland', '3648', '0:003743:003620:003648:003651', '4', null, '南区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3652', 'mainland', '3648', '0:003743:003620:003648:003652', '4', null, '北区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3653', 'mainland', '3648', '0:003743:003620:003648:003653', '4', null, '安平区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3654', 'mainland', '3648', '0:003743:003620:003648:003654', '4', null, '安南区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3655', 'mainland', '3648', '0:003743:003620:003648:003655', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3656', 'mainland', '3620', '0:003743:003620:003656', '3', '3656', '台中市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3657', 'mainland', '3656', '0:003743:003620:003656:003657', '4', null, '中区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3658', 'mainland', '3656', '0:003743:003620:003656:003658', '4', null, '东区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3659', 'mainland', '3656', '0:003743:003620:003656:003659', '4', null, '南区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3660', 'mainland', '3656', '0:003743:003620:003656:003660', '4', null, '西区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3661', 'mainland', '3656', '0:003743:003620:003656:003661', '4', null, '北区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3662', 'mainland', '3656', '0:003743:003620:003656:003662', '4', null, '北屯区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3663', 'mainland', '3656', '0:003743:003620:003656:003663', '4', null, '西屯区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3664', 'mainland', '3656', '0:003743:003620:003656:003664', '4', null, '南屯区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3665', 'mainland', '3656', '0:003743:003620:003656:003665', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3666', 'mainland', '3620', '0:003743:003620:003666', '3', '3666', '金门县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3667', 'mainland', '3620', '0:003743:003620:003667', '3', '3667', '南投县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3668', 'mainland', '3620', '0:003743:003620:003668', '3', '3668', '基隆市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3669', 'mainland', '3668', '0:003743:003620:003668:003669', '4', null, '仁爱区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3670', 'mainland', '3668', '0:003743:003620:003668:003670', '4', null, '信义区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3671', 'mainland', '3668', '0:003743:003620:003668:003671', '4', null, '中正区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3672', 'mainland', '3668', '0:003743:003620:003668:003672', '4', null, '中山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3673', 'mainland', '3668', '0:003743:003620:003668:003673', '4', null, '安乐区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3674', 'mainland', '3668', '0:003743:003620:003668:003674', '4', null, '暖暖区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3675', 'mainland', '3668', '0:003743:003620:003668:003675', '4', null, '七堵区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3676', 'mainland', '3668', '0:003743:003620:003668:003676', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3677', 'mainland', '3620', '0:003743:003620:003677', '3', '3677', '新竹市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3678', 'mainland', '3677', '0:003743:003620:003677:003678', '4', null, '东区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3679', 'mainland', '3677', '0:003743:003620:003677:003679', '4', null, '北区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3680', 'mainland', '3677', '0:003743:003620:003677:003680', '4', null, '香山区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3681', 'mainland', '3677', '0:003743:003620:003677:003681', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3682', 'mainland', '3620', '0:003743:003620:003682', '3', '3682', '嘉义市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3683', 'mainland', '3682', '0:003743:003620:003682:003683', '4', null, '东区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3684', 'mainland', '3682', '0:003743:003620:003682:003684', '4', null, '西区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3685', 'mainland', '3682', '0:003743:003620:003682:003685', '4', null, '其它区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3686', 'mainland', '3620', '0:003743:003620:003686', '3', '3686', '新北市', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3687', 'mainland', '3620', '0:003743:003620:003687', '3', '3687', '宜兰县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3688', 'mainland', '3620', '0:003743:003620:003688', '3', '3688', '新竹县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3689', 'mainland', '3620', '0:003743:003620:003689', '3', '3689', '桃园县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3690', 'mainland', '3620', '0:003743:003620:003690', '3', '3690', '苗栗县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3691', 'mainland', '3620', '0:003743:003620:003691', '3', '3691', '彰化县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3692', 'mainland', '3620', '0:003743:003620:003692', '3', '3692', '嘉义县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3693', 'mainland', '3620', '0:003743:003620:003693', '3', '3693', '云林县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3694', 'mainland', '3620', '0:003743:003620:003694', '3', '3694', '屏东县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3695', 'mainland', '3620', '0:003743:003620:003695', '3', '3695', '台东县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3696', 'mainland', '3620', '0:003743:003620:003696', '3', '3696', '花莲县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3697', 'mainland', '3620', '0:003743:003620:003697', '3', '3697', '澎湖县', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3698', 'mainland', '3743', '0:003743:003698', '2', null, '香港特别行政区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3699', 'mainland', '3698', '0:003743:003698:003699', '3', '3699', '香港岛', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3700', 'mainland', '3699', '0:003743:003698:003699:003700', '4', null, '中西区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3701', 'mainland', '3699', '0:003743:003698:003699:003701', '4', null, '湾仔', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3702', 'mainland', '3699', '0:003743:003698:003699:003702', '4', null, '东区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3703', 'mainland', '3699', '0:003743:003698:003699:003703', '4', null, '南区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3704', 'mainland', '3698', '0:003743:003698:003704', '3', '3704', '九龙', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3705', 'mainland', '3704', '0:003743:003698:003704:003705', '4', null, '九龙城区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3706', 'mainland', '3704', '0:003743:003698:003704:003706', '4', null, '油尖旺区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3707', 'mainland', '3704', '0:003743:003698:003704:003707', '4', null, '深水埗区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3708', 'mainland', '3704', '0:003743:003698:003704:003708', '4', null, '黄大仙区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3709', 'mainland', '3704', '0:003743:003698:003704:003709', '4', null, '观塘区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3710', 'mainland', '3698', '0:003743:003698:003710', '3', '3710', '新界', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3711', 'mainland', '3710', '0:003743:003698:003710:003711', '4', null, '北区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3712', 'mainland', '3710', '0:003743:003698:003710:003712', '4', null, '大埔区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3713', 'mainland', '3710', '0:003743:003698:003710:003713', '4', null, '沙田区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3714', 'mainland', '3710', '0:003743:003698:003710:003714', '4', null, '西贡区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3715', 'mainland', '3710', '0:003743:003698:003710:003715', '4', null, '元朗区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3716', 'mainland', '3710', '0:003743:003698:003710:003716', '4', null, '屯门区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3717', 'mainland', '3710', '0:003743:003698:003710:003717', '4', null, '荃湾区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3718', 'mainland', '3710', '0:003743:003698:003710:003718', '4', null, '葵青区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3719', 'mainland', '3710', '0:003743:003698:003710:003719', '4', null, '离岛区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3720', 'mainland', '3743', '0:003743:003720', '2', null, '澳门特别行政区', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3721', 'mainland', '3720', '0:003743:003720:003721', '3', '3721', '澳门半岛', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3722', 'mainland', '3720', '0:003743:003720:003722', '3', '3722', '离岛', null, null, null, '0', '1');
INSERT INTO `trend_region` VALUES ('3771', 'mainland', '3770', '0:003769:003770:003771', '3', '3771', '东京市', null, null, null, '1', '1');
INSERT INTO `trend_region` VALUES ('3774', 'mainland', '3770', '0:003769:003770:003774', '3', '3774', '东京3区', null, null, null, '1', '1');

-- ----------------------------
-- Table structure for trend_version
-- ----------------------------
DROP TABLE IF EXISTS `trend_version`;
CREATE TABLE `trend_version` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vname` varchar(10) NOT NULL COMMENT '版本名称，比如：1.21、3.42',
  `filepath` varchar(255) NOT NULL COMMENT '文件路径，即版本下载地址',
  `ctime` datetime NOT NULL COMMENT '创建时间',
  `isdel` tinyint(3) DEFAULT '0' COMMENT '是否删除 0否1是',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='版本管理';

-- ----------------------------
-- Records of trend_version
-- ----------------------------

-- ----------------------------
-- Table structure for user_address
-- ----------------------------
DROP TABLE IF EXISTS `user_address`;
CREATE TABLE `user_address` (
  `useraddressid` int(11) NOT NULL AUTO_INCREMENT COMMENT '收货地址编码',
  `userid` int(11) DEFAULT NULL COMMENT '用户编码',
  `phone` varchar(16) DEFAULT NULL COMMENT '收货人电话',
  `name` varchar(20) DEFAULT NULL COMMENT '收货人姓名',
  `provinceid` int(11) DEFAULT NULL COMMENT '省编码',
  `cityid` int(11) DEFAULT NULL COMMENT '市编码',
  `countryid` int(11) DEFAULT NULL COMMENT '区县编码',
  `address` varchar(200) DEFAULT NULL COMMENT '详细地址',
  `isdel` tinyint(3) NOT NULL DEFAULT '0' COMMENT '是否删除 0否1是',
  `isdefault` tinyint(3) NOT NULL DEFAULT '0' COMMENT '是否默认 0否1是',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`useraddressid`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8 COMMENT='用户收货地址表';

-- ----------------------------
-- Records of user_address
-- ----------------------------

-- ----------------------------
-- Table structure for user_collect
-- ----------------------------
DROP TABLE IF EXISTS `user_collect`;
CREATE TABLE `user_collect` (
  `collectid` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键编码',
  `userid` int(11) DEFAULT NULL COMMENT '用户编码',
  `goodsid` int(11) DEFAULT NULL COMMENT '商品编码',
  `ctime` datetime DEFAULT NULL COMMENT '收藏日期',
  PRIMARY KEY (`collectid`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8 COMMENT='用户收藏商品表';

-- ----------------------------
-- Records of user_collect
-- ----------------------------

-- ----------------------------
-- Table structure for user_info
-- ----------------------------
DROP TABLE IF EXISTS `user_info`;
CREATE TABLE `user_info` (
  `userid` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户编码',
  `phone` varchar(12) DEFAULT NULL COMMENT '手机号码',
  `password` varchar(50) DEFAULT NULL COMMENT '密码',
  `balance` decimal(10,2) DEFAULT '0.00' COMMENT '帐户余额',
  `state` tinyint(3) DEFAULT '0' COMMENT '是否禁用 0否1是',
  `nickname` varchar(20) DEFAULT NULL COMMENT '昵称',
  `headurl` varchar(100) DEFAULT NULL COMMENT '头像',
  `openid` varchar(50) DEFAULT NULL COMMENT '微信普通用户的标识，对当前开发者帐号唯一',
  `unionid` varchar(255) DEFAULT NULL COMMENT '微信用户统一标识。针对一个微信开放平台帐号下的应用，同一用户的unionid是唯一的',
  `token` varchar(40) DEFAULT NULL,
  `ctime` datetime DEFAULT NULL COMMENT '注册时间',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- ----------------------------
-- Records of user_info
-- ----------------------------

-- ----------------------------
-- Table structure for user_info_dk
-- ----------------------------
DROP TABLE IF EXISTS `user_info_dk`;
CREATE TABLE `user_info_dk` (
  `userid` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户编码',
  `phone` varchar(12) DEFAULT NULL COMMENT '手机号码',
  `password` varchar(50) DEFAULT NULL COMMENT '密码',
  `balance` decimal(10,2) DEFAULT '0.00' COMMENT '帐户余额',
  `state` tinyint(3) DEFAULT '0' COMMENT '是否禁用 0否1是',
  `nickname` varchar(20) DEFAULT NULL COMMENT '昵称',
  `headurl` varchar(100) DEFAULT NULL COMMENT '头像',
  `openid` varchar(50) DEFAULT NULL COMMENT '微信普通用户的标识，对当前开发者帐号唯一',
  `unionid` varchar(255) DEFAULT NULL COMMENT '微信用户统一标识。针对一个微信开放平台帐号下的应用，同一用户的unionid是唯一的',
  `token` varchar(40) DEFAULT NULL,
  `ctime` datetime DEFAULT NULL COMMENT '注册时间',
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- ----------------------------
-- Records of user_info_dk
-- ----------------------------

-- ----------------------------
-- Table structure for user_private_letter
-- ----------------------------
DROP TABLE IF EXISTS `user_private_letter`;
CREATE TABLE `user_private_letter` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '私信主键',
  `recipientid` int(11) DEFAULT NULL COMMENT '接收者',
  `senderid` int(11) DEFAULT NULL COMMENT '发送者',
  `content` varchar(255) DEFAULT NULL COMMENT '内容',
  `ctime` datetime DEFAULT NULL COMMENT '发送时间',
  `isdelete` int(2) DEFAULT '0' COMMENT '是否被删除【0否1是】',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COMMENT='用户私信';

-- ----------------------------
-- Records of user_private_letter
-- ----------------------------

-- ----------------------------
-- Table structure for user_private_reply
-- ----------------------------
DROP TABLE IF EXISTS `user_private_reply`;
CREATE TABLE `user_private_reply` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '私信回复主键',
  `letterid` int(11) DEFAULT NULL COMMENT '私信id',
  `recipientid` int(11) DEFAULT NULL COMMENT '接收者',
  `senderid` int(11) DEFAULT NULL COMMENT '发送者',
  `content` varchar(255) DEFAULT NULL COMMENT '内容',
  `ctime` datetime DEFAULT NULL COMMENT '发送时间',
  `isdelete` int(2) DEFAULT '0' COMMENT '是否被删除【0否1是】',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COMMENT='用户私信回复';

-- ----------------------------
-- Records of user_private_reply
-- ----------------------------

-- ----------------------------
-- Table structure for user_routes
-- ----------------------------
DROP TABLE IF EXISTS `user_routes`;
CREATE TABLE `user_routes` (
  `routesid` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户轨迹id',
  `userid` int(11) DEFAULT NULL COMMENT '用户id',
  `lng` varchar(255) DEFAULT NULL COMMENT '经度',
  `lat` varchar(255) DEFAULT NULL COMMENT '纬度',
  `address` varchar(255) DEFAULT NULL COMMENT '地址',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`routesid`)
) ENGINE=InnoDB AUTO_INCREMENT=3121 DEFAULT CHARSET=utf8 COMMENT='用户轨迹';

-- ----------------------------
-- Records of user_routes
-- ----------------------------

-- ----------------------------
-- Table structure for user_routes_rate
-- ----------------------------
DROP TABLE IF EXISTS `user_routes_rate`;
CREATE TABLE `user_routes_rate` (
  `rateid` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户轨迹刷新频率id',
  `rate` int(11) DEFAULT '0' COMMENT '刷新频率',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`rateid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='用户轨迹刷新频率';

-- ----------------------------
-- Records of user_routes_rate
-- ----------------------------

-- ----------------------------
-- Table structure for validatecode_info
-- ----------------------------
DROP TABLE IF EXISTS `validatecode_info`;
CREATE TABLE `validatecode_info` (
  `codeid` int(11) NOT NULL AUTO_INCREMENT COMMENT '验证码编码',
  `userid` int(11) DEFAULT NULL COMMENT '用户编码',
  `phone` varchar(12) DEFAULT NULL COMMENT '手机号',
  `code` int(6) DEFAULT NULL COMMENT '验证码',
  `type` int(2) DEFAULT NULL COMMENT '类型 1注册2找回密码',
  `ctime` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`codeid`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COMMENT='验证码表';

-- ----------------------------
-- Records of validatecode_info
-- ----------------------------
